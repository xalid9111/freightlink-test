import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../repositories/shipment_repository.dart';

/// Bottom-nav "Shipments" tab — real data via
/// ShipmentRepository.fetchMineWithCargo(). RLS (migration 0002) scopes
/// "mine" to shipments where the signed-in user is the carrier or the
/// cargo owner, so this list is correct for either role automatically.
class ShipmentsScreen extends ConsumerWidget {
  const ShipmentsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    final shipmentsAsync = ref.watch(myShipmentsProvider);

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('shipments_placeholder_title'))),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(myShipmentsProvider),
        child: shipmentsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => Center(child: Text(strings.t('home_error_loading'))),
          data: (items) {
            if (items.isEmpty) {
              return LayoutBuilder(
                builder: (context, constraints) => SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: constraints.maxHeight),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.receipt_long_outlined, size: 44, color: Theme.of(context).colorScheme.outline),
                          const SizedBox(height: 12),
                          Text(strings.t('shipments_empty_title')),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) => _ShipmentTile(item: items[i], strings: strings),
            );
          },
        ),
      ),
    );
  }
}

class _ShipmentTile extends ConsumerWidget {
  final ShipmentWithCargo item;
  final AppStrings strings;
  const _ShipmentTile({required this.item, required this.strings});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cargo = item.cargo;
    final shipment = item.shipment;
    final statusKey = 'shipment_status_${shipment.status}';
    final statusLabel = strings.t(statusKey);
    final localeCode = ref.watch(currentLocaleProvider).languageCode;
    final dateFmt = DateFormat('d MMM yyyy', localeCode);

    return Card(
      child: ListTile(
        onTap: cargo == null ? null : () => context.push('/cargo/${cargo.id}'),
        title: cargo == null
            ? Text(shipment.id)
            : Text('${cargo.pickupCountry} → ${cargo.destinationCountry}', style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${strings.t('shipment_agreed_price_label')}: ${shipment.agreedPrice.toStringAsFixed(0)} ${shipment.currency}'),
            if (shipment.pickupTime != null) Text(dateFmt.format(shipment.pickupTime!)),
          ],
        ),
        trailing: Chip(label: Text(statusLabel == statusKey ? shipment.status : statusLabel), visualDensity: VisualDensity.compact),
      ),
    );
  }
}
