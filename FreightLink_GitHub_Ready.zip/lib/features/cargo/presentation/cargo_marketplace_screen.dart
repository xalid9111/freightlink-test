import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../repositories/credits_repository.dart';
import 'providers/cargo_providers.dart';
import 'widgets/cargo_card.dart';
import '../../../core/constants/countries.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/cargo_model.dart';
import 'widgets/live_map.dart';

/// The "Home" tab body (bottom-nav branch 0) — the real, live cargo
/// marketplace, connected to Supabase via marketplaceProvider. No
/// demo/mock data anywhere in this file.
class CargoMarketplaceScreen extends ConsumerWidget {
  const CargoMarketplaceScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final strings = ref.watch(stringsProvider);
    final marketplaceAsync = ref.watch(marketplaceProvider);
    final cargoList = marketplaceAsync.valueOrNull ?? const <CargoModel>[];

    return Scaffold(
      floatingActionButton: user?.role == AppConstants.roleCargoOwner
          ? FloatingActionButton.extended(
              onPressed: () => context.push('/cargo/create'),
              icon: const Icon(Icons.add),
              label: Text(strings.t('home_post_cargo')),
            )
          : null,
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(marketplaceProvider),
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _Hero(strings: strings, cargoList: cargoList, loaded: marketplaceAsync.hasValue)),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(strings.t('home_open_loads'), style: AppFonts.display(size: 22, color: AppColors.text)),
                    const Spacer(),
                    if (marketplaceAsync.hasValue)
                      Text(strings.t('home_results', {'count': '${cargoList.length}'}),
                          style: const TextStyle(fontSize: 12.5, color: AppColors.textSoft)),
                  ],
                ),
              ),
            ),
            ...marketplaceAsync.when<List<Widget>>(
              loading: () => [
                const SliverToBoxAdapter(
                  child: Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator())),
                ),
              ],
              error: (e, _) => [
                SliverToBoxAdapter(
                  child: _ErrorState(
                    message: strings.t('home_error_loading'),
                    retryLabel: strings.t('home_retry'),
                    onRetry: () => ref.invalidate(marketplaceProvider),
                  ),
                ),
              ],
              data: (list) {
                if (list.isEmpty) return [SliverToBoxAdapter(child: _EmptyMarketplace(strings: strings))];
                return [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                    sliver: SliverList.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, i) {
                        final cargo = list[i];
                        return CargoCard(
                          cargo: cargo,
                          strings: strings,
                          onTap: () => context.push('/cargo/${cargo.id}'),
                        );
                      },
                    ),
                  ),
                ];
              },
            ),
          ],
        ),
      ),
    );
  }
}

/// Dark hero: brand row, live-map title, the animated map, REAL stats
/// computed from the open marketplace (no invented numbers), and the
/// most common routes among the open loads.
class _Hero extends ConsumerWidget {
  final AppStrings strings;
  final List<CargoModel> cargoList;
  final bool loaded;
  const _Hero({required this.strings, required this.cargoList, required this.loaded});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final localeCode = ref.watch(currentLocaleProvider).languageCode;

    // Real figures from the loaded list.
    String key(String v) => Countries.find(v)?.code ?? Countries.normalize(v);
    final countries = <String>{};
    final routeCounts = <String, int>{};
    final routeSample = <String, CargoModel>{};
    for (final c in cargoList) {
      final a = key(c.pickupCountry);
      final b = key(c.destinationCountry);
      countries..add(a)..add(b);
      final r = '$a>$b';
      routeCounts[r] = (routeCounts[r] ?? 0) + 1;
      routeSample.putIfAbsent(r, () => c);
    }
    final topRoutes = routeCounts.keys.toList()..sort((x, y) => routeCounts[y]!.compareTo(routeCounts[x]!));

    String stat(int n) => loaded ? '$n' : '—';

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.hero,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(26)),
      ),
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 10, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.show_chart, color: AppColors.accentFill, size: 30),
                const SizedBox(width: 6),
                Text.rich(TextSpan(children: [
                  TextSpan(text: 'Freight', style: AppFonts.display(size: 25, color: AppColors.text)),
                  TextSpan(text: 'Link', style: AppFonts.display(size: 25, color: AppColors.accent)),
                ])),
                const Spacer(),
                const _CreditsBadge(),
                const _ProBadge(),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(width: 7, height: 7, decoration: const BoxDecoration(color: AppColors.accentFill, shape: BoxShape.circle)),
                  const SizedBox(width: 7),
                  Text(strings.t('home_live_map'), style: AppFonts.mono(color: AppColors.accent, letterSpacing: 1.2)),
                ]),
                const SizedBox(height: 4),
                Text.rich(
                  TextSpan(children: [
                    TextSpan(text: '${strings.t('home_hero_1')} '),
                    TextSpan(text: strings.t('home_hero_2'), style: const TextStyle(color: AppColors.accent)),
                    TextSpan(text: ' ${strings.t('home_hero_3')}'),
                  ]),
                  style: AppFonts.display(size: 32, color: AppColors.text, height: 1.0),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: LiveMap()),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(child: _Stat(icon: Icons.local_shipping_outlined, value: stat(cargoList.length), label: strings.t('home_stat_active'))),
                Expanded(child: _Stat(icon: Icons.place_outlined, value: stat(countries.length), label: strings.t('home_stat_countries'))),
                Expanded(child: _Stat(icon: Icons.timeline, value: stat(routeCounts.length), label: strings.t('home_stat_routes'))),
              ],
            ),
          ),
          if (topRoutes.isNotEmpty) ...[
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(strings.t('home_popular_routes'), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSoft)),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 52,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: topRoutes.length > 5 ? 5 : topRoutes.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, i) {
                  final r = topRoutes[i];
                  final sample = routeSample[r]!;
                  final from = Countries.find(sample.pickupCountry);
                  final to = Countries.find(sample.destinationCountry);
                  final label = (from != null && to != null)
                      ? '${from.code} → ${to.code}'
                      : '${Countries.label(sample.pickupCountry, localeCode)} → ${Countries.label(sample.destinationCountry, localeCode)}';
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF141C2B),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.line),
                    ),
                    child: Row(
                      children: [
                        if (from != null) Text(from.flag, style: const TextStyle(fontSize: 18)),
                        if (from != null && to != null)
                          const Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: Text('→', style: TextStyle(color: AppColors.accent))),
                        if (to != null) Text(to.flag, style: const TextStyle(fontSize: 18)),
                        const SizedBox(width: 8),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                            Text(strings.t('home_route_count', {'count': '${routeCounts[r]}'}),
                                style: const TextStyle(fontSize: 10.5, color: AppColors.textSoft)),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _Stat({required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(color: AppColors.cardAlt, borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, size: 18, color: AppColors.accent),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: AppFonts.display(size: 20, color: AppColors.accent, height: 1)),
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppColors.textSoft)),
            ],
          ),
        ),
      ],
    );
  }
}

class _EmptyMarketplace extends StatelessWidget {
  final AppStrings strings;
  const _EmptyMarketplace({required this.strings});

  @override
  Widget build(BuildContext context) {
    return Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 96),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.local_shipping_outlined, size: 48, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 12),
                  Text(strings.t('home_empty_title'), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text(strings.t('home_empty_body'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final String retryLabel;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.retryLabel, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 96),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.error_outline, size: 44, color: Theme.of(context).colorScheme.error),
                  const SizedBox(height: 12),
                  Text(message, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  OutlinedButton(onPressed: onRetry, child: Text(retryLabel)),
                ],
              ),
            ),
    );
  }
}

/// A real (not decorative) read of the carrier's contact-credit
/// balance — see supabase/migrations/0006_monetization.sql and
/// repositories/credits_repository.dart. Shows nothing for a cargo
/// owner (credits are a carrier-side concept); shows nothing if the
/// read fails rather than a confusing "Credits: 0" that could look
/// like a real zero balance.
class _CreditsBadge extends ConsumerWidget {
  const _CreditsBadge();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final strings = ref.watch(stringsProvider);
    if (user == null || user.role != AppConstants.roleCarrier) return const SizedBox.shrink();

    final balanceAsync = ref.watch(creditsBalanceProvider);
    return balanceAsync.when(
      data: (balance) {
        if (balance == null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF141C2B),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.line),
              ),
              child: Text(strings.t('home_credits_label', {'count': '$balance'}),
                  style: AppFonts.mono(size: 12, color: AppColors.text)),
            ),
          ),
        );
      },
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
    );
  }
}

/// Real entry point for the future Pro plan (brief §8), honestly
/// labeled as not-yet-available rather than a fake "Upgrade" button
/// that goes nowhere. subscription_plans already has a 'pro' row with
/// price=NULL (see migration 0006) — this reads whether a purchasable
/// plan exists at all, and only shows the badge once one does.
class _ProBadge extends ConsumerWidget {
  const _ProBadge();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final strings = ref.watch(stringsProvider);
    if (user == null || user.role != AppConstants.roleCarrier) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: ActionChip(
        avatar: const Icon(Icons.bolt, size: 16),
        label: Text(strings.t('home_pro_badge')),
        visualDensity: VisualDensity.compact,
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(strings.t('home_pro_coming_soon'))),
          );
        },
      ),
    );
  }
}
