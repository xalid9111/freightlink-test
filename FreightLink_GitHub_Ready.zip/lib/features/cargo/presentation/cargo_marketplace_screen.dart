import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../repositories/credits_repository.dart';
import 'providers/cargo_providers.dart';
import 'widgets/cargo_card.dart';

/// The "Home" tab body (bottom-nav branch 0) — the real, live cargo
/// marketplace, connected to Supabase via marketplaceProvider. No
/// demo/mock data anywhere in this file.
class CargoMarketplaceScreen extends ConsumerWidget {
  const CargoMarketplaceScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final strings = ref.watch(stringsProvider);
    final marketplaceAsync = ref.watch(marketplaceProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(user == null ? strings.t('home_title_generic') : strings.t('home_greeting', {'name': user.fullName.split(' ').first})),
        actions: const [_CreditsBadge(), _ProBadge(), SizedBox(width: 8)],
      ),
      floatingActionButton: user?.role == AppConstants.roleCargoOwner
          ? FloatingActionButton.extended(
              onPressed: () => context.push('/cargo/create'),
              icon: const Icon(Icons.add),
              label: Text(strings.t('home_post_cargo')),
            )
          : null,
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(marketplaceProvider),
        child: marketplaceAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => _ErrorState(
            message: strings.t('home_error_loading'),
            retryLabel: strings.t('home_retry'),
            onRetry: () => ref.invalidate(marketplaceProvider),
          ),
          data: (cargoList) {
            if (cargoList.isEmpty) {
              return _EmptyMarketplace(strings: strings);
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
              itemCount: cargoList.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final cargo = cargoList[i];
                return CargoCard(
                  cargo: cargo,
                  strings: strings,
                  onTap: () => context.push('/cargo/${cargo.id}'),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _EmptyMarketplace extends StatelessWidget {
  final AppStrings strings;
  const _EmptyMarketplace({required this.strings});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.maxHeight),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.local_shipping_outlined, size: 48, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 12),
                  Text(strings.t('home_empty_title'), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text(strings.t('home_empty_body'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final String retryLabel;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.retryLabel, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.maxHeight),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.error_outline, size: 44, color: Theme.of(context).colorScheme.error),
                  const SizedBox(height: 12),
                  Text(message, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  OutlinedButton(onPressed: onRetry, child: Text(retryLabel)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// A real (not decorative) read of the carrier's contact-credit
/// balance — see supabase/migrations/0006_monetization.sql and
/// repositories/credits_repository.dart. Shows nothing for a cargo
/// owner (credits are a carrier-side concept); shows nothing if the
/// read fails rather than a confusing "Credits: 0" that could look
/// like a real zero balance.
class _CreditsBadge extends ConsumerWidget {
  const _CreditsBadge();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final strings = ref.watch(stringsProvider);
    if (user == null || user.role != AppConstants.roleCarrier) return const SizedBox.shrink();

    final balanceAsync = ref.watch(creditsBalanceProvider);
    return balanceAsync.when(
      data: (balance) {
        if (balance == null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Center(
            child: Chip(
              label: Text(strings.t('home_credits_label', {'count': '$balance'})),
              visualDensity: VisualDensity.compact,
            ),
          ),
        );
      },
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
    );
  }
}

/// Real entry point for the future Pro plan (brief §8), honestly
/// labeled as not-yet-available rather than a fake "Upgrade" button
/// that goes nowhere. subscription_plans already has a 'pro' row with
/// price=NULL (see migration 0006) — this reads whether a purchasable
/// plan exists at all, and only shows the badge once one does.
class _ProBadge extends ConsumerWidget {
  const _ProBadge();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final strings = ref.watch(stringsProvider);
    if (user == null || user.role != AppConstants.roleCarrier) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: ActionChip(
        avatar: const Icon(Icons.bolt, size: 16),
        label: Text(strings.t('home_pro_badge')),
        visualDensity: VisualDensity.compact,
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(strings.t('home_pro_coming_soon'))),
          );
        },
      ),
    );
  }
}
