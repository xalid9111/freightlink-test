import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import 'providers/cargo_providers.dart';
import 'widgets/cargo_card.dart';
import '../../../core/constants/countries.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/cargo_model.dart';
import 'widgets/live_map.dart';
import 'widgets/wheel_feed.dart';
import '../../ads/presentation/ads_providers.dart';
import '../../ads/presentation/sponsored_banner.dart';
import '../../../models/ad_models.dart';
import 'providers/route_filter.dart';
import '../../../core/widgets/country_picker.dart';

/// The "Home" tab body (bottom-nav branch 0) — the real, live cargo
/// marketplace, connected to Supabase via marketplaceProvider. No
/// demo/mock data anywhere in this file.
class CargoMarketplaceScreen extends ConsumerWidget {
  const CargoMarketplaceScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    final marketplaceAsync = ref.watch(marketplaceProvider);
    final cargoList = marketplaceAsync.valueOrNull ?? const <CargoModel>[];
    final filter = ref.watch(routeFilterProvider);
    final ads = ref.watch(liveAdsProvider).valueOrNull ?? const <Ad>[];
    final shown = filter.isActive ? cargoList.where(filter.matches).toList() : cargoList;

    return Scaffold(
      // "Add load" moved to the bottom navigation bar.
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(marketplaceProvider);
          ref.invalidate(liveAdsProvider);
        },
        // Open Loads feed = 3D wheel (scale / veil / tilt by distance from
        // the screen centre, detent haptic, gentle snap).
        child: WheelScope(
          child: CustomScrollView(
          // iOS-style momentum everywhere: long, soft glide and no hard stop.
          physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
          slivers: [
            SliverToBoxAdapter(child: _Hero(strings: strings, cargoList: cargoList, loaded: marketplaceAsync.hasValue)),
            SliverToBoxAdapter(child: _RouteSearch(strings: strings)),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(strings.t('home_open_loads'), style: AppFonts.display(size: 22, color: AppColors.text)),
                    const Spacer(),
                    if (marketplaceAsync.hasValue)
                      Text(strings.t('home_results', {'count': '${shown.length}'}),
                          style: const TextStyle(fontSize: 12.5, color: AppColors.textSoft)),
                  ],
                ),
              ),
            ),
            ...marketplaceAsync.when<List<Widget>>(
              loading: () => [
                const SliverToBoxAdapter(
                  child: Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator())),
                ),
              ],
              error: (e, _) => [
                SliverToBoxAdapter(
                  child: _ErrorState(
                    message: strings.t('home_error_loading'),
                    retryLabel: strings.t('home_retry'),
                    onRetry: () => ref.invalidate(marketplaceProvider),
                  ),
                ),
              ],
              data: (all) {
                final list = filter.isActive ? all.where(filter.matches).toList() : all;
                if (list.isEmpty && filter.isActive) {
                  return [
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(24, 24, 24, 96),
                        child: Column(
                          children: [
                            const Icon(Icons.search_off, size: 40, color: AppColors.textSoft),
                            const SizedBox(height: 10),
                            Text(strings.t('route_no_results'), textAlign: TextAlign.center),
                            const SizedBox(height: 10),
                            OutlinedButton(
                              onPressed: () => ref.read(routeFilterProvider.notifier).state = const RouteFilter(),
                              child: Text(strings.t('route_clear')),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ];
                }
                if (list.isEmpty) return [SliverToBoxAdapter(child: _EmptyMarketplace(strings: strings))];
                return [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                    // 6 loads → ad slot → 6 loads → … (each ad once, then empty
                    // "Reklam əlavə et" slots).
                    sliver: SliverList.builder(
                      itemCount: _feedLength(list.length),
                      itemBuilder: (context, i) {
                        final slot = _feedSlot(i);
                        if (slot.isAd) {
                          // Each live ad is shown once; later slots stay
                          // empty with only "Reklam əlavə et".
                          return WheelItem(
                            index: i,
                            isAd: true,
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(0, 10, 0, 18),
                              child: slot.index < ads.length
                                  ? SponsoredBanner(ad: ads[slot.index], strings: strings)
                                  : AdPlaceholder(strings: strings),
                            ),
                          );
                        }
                        final cargo = list[slot.index];
                        return WheelItem(
                          index: i,
                          isAd: false,
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: CargoCard(
                              cargo: cargo,
                              strings: strings,
                              compact: true,
                              onTap: () => context.push('/cargo/${cargo.id}'),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ];
              },
            ),
          ],
        ),
        ),
      ),
    );
  }
}

/// Dark hero: brand row, live-map title, the animated map, REAL stats
/// computed from the open marketplace (no invented numbers), and the
/// most common routes among the open loads.
class _Hero extends ConsumerWidget {
  final AppStrings strings;
  final List<CargoModel> cargoList;
  final bool loaded;
  const _Hero({required this.strings, required this.cargoList, required this.loaded});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final localeCode = ref.watch(currentLocaleProvider).languageCode;

    // Real figures from the loaded list.
    String key(String v) => Countries.find(v)?.code ?? Countries.normalize(v);
    final countries = <String>{};
    final routeCounts = <String, int>{};
    final routeSample = <String, CargoModel>{};
    for (final c in cargoList) {
      final a = key(c.pickupCountry);
      final b = key(c.destinationCountry);
      countries..add(a)..add(b);
      final r = '$a>$b';
      routeCounts[r] = (routeCounts[r] ?? 0) + 1;
      routeSample.putIfAbsent(r, () => c);
    }
    final topRoutes = routeCounts.keys.toList()..sort((x, y) => routeCounts[y]!.compareTo(routeCounts[x]!));

    String stat(int n) => loaded ? '$n' : '—';

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.hero,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(26)),
      ),
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 10, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.show_chart, color: AppColors.accentFill, size: 30),
                const SizedBox(width: 6),
                Text.rich(TextSpan(children: [
                  TextSpan(text: 'Freight', style: AppFonts.display(size: 25, color: AppColors.text)),
                  TextSpan(text: 'Link', style: AppFonts.display(size: 25, color: AppColors.accent)),
                ])),
                const Spacer(),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(width: 7, height: 7, decoration: const BoxDecoration(color: AppColors.accentFill, shape: BoxShape.circle)),
                  const SizedBox(width: 7),
                  Text(strings.t('home_live_map'), style: AppFonts.mono(color: AppColors.accent, letterSpacing: 1.2)),
                ]),
                const SizedBox(height: 4),
                Text.rich(
                  TextSpan(children: [
                    TextSpan(text: '${strings.t('home_hero_1')} '),
                    TextSpan(text: strings.t('home_hero_2'), style: const TextStyle(color: AppColors.accent)),
                    TextSpan(text: ' ${strings.t('home_hero_3')}'),
                  ]),
                  style: AppFonts.display(size: 32, color: AppColors.text, height: 1.0),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Full width, edge to edge; edges fade into the page colour.
          const LiveMap(),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(child: _Stat(icon: Icons.local_shipping_outlined, value: stat(cargoList.length), label: strings.t('home_stat_active'))),
                Expanded(child: _Stat(icon: Icons.place_outlined, value: stat(countries.length), label: strings.t('home_stat_countries'))),
                Expanded(child: _Stat(icon: Icons.timeline, value: stat(routeCounts.length), label: strings.t('home_stat_routes'))),
              ],
            ),
          ),
          if (topRoutes.isNotEmpty) ...[
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(strings.t('home_popular_routes'), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSoft)),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 52,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: topRoutes.length > 5 ? 5 : topRoutes.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, i) {
                  final r = topRoutes[i];
                  final sample = routeSample[r]!;
                  final from = Countries.find(sample.pickupCountry);
                  final to = Countries.find(sample.destinationCountry);
                  final label = (from != null && to != null)
                      ? '${from.code} → ${to.code}'
                      : '${Countries.label(sample.pickupCountry, localeCode)} → ${Countries.label(sample.destinationCountry, localeCode)}';
                  return InkWell(
                    borderRadius: BorderRadius.circular(12),
                    // Tap a popular route to filter the list to it.
                    onTap: (from != null && to != null)
                        ? () => ref.read(routeFilterProvider.notifier).state = RouteFilter(from: from.code, to: to.code)
                        : null,
                    child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF141C2B),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.line),
                    ),
                    child: Row(
                      children: [
                        if (from != null) Text(from.flag, style: const TextStyle(fontSize: 18)),
                        if (from != null && to != null)
                          const Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: Text('→', style: TextStyle(color: AppColors.accent))),
                        if (to != null) Text(to.flag, style: const TextStyle(fontSize: 18)),
                        const SizedBox(width: 8),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                            Text(strings.t('home_route_count', {'count': '${routeCounts[r]}'}),
                                style: const TextStyle(fontSize: 10.5, color: AppColors.textSoft)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _Stat({required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(color: AppColors.cardAlt, borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, size: 18, color: AppColors.accent),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: AppFonts.display(size: 20, color: AppColors.accent, height: 1)),
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppColors.textSoft)),
            ],
          ),
        ),
      ],
    );
  }
}

class _EmptyMarketplace extends StatelessWidget {
  final AppStrings strings;
  const _EmptyMarketplace({required this.strings});

  @override
  Widget build(BuildContext context) {
    return Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 96),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.local_shipping_outlined, size: 48, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 12),
                  Text(strings.t('home_empty_title'), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text(strings.t('home_empty_body'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final String retryLabel;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.retryLabel, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 96),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.error_outline, size: 44, color: Theme.of(context).colorScheme.error),
                  const SizedBox(height: 12),
                  Text(message, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  OutlinedButton(onPressed: onRetry, child: Text(retryLabel)),
                ],
              ),
            ),
    );
  }
}


/// "Find a load by route": FROM → TO country buttons (with ⇅ swap),
/// one-tap "my routes" chips saved on the device, and a star to save the
/// current route. Filters the list below instantly — no scrolling.
class _RouteSearch extends ConsumerWidget {
  final AppStrings strings;
  const _RouteSearch({required this.strings});

  Future<void> _pick(BuildContext context, WidgetRef ref, {required bool isFrom}) async {
    final lang = ref.read(currentLocaleProvider).languageCode;
    final picked = await showModalBottomSheet<Country>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => CountryPickerSheet(languageCode: lang, strings: strings, anyLabel: strings.t('route_any_country')),
    );
    if (picked == null) return;
    final code = identical(picked, anyCountry) || picked.code == anyCountry.code ? null : picked.code;
    final f = ref.read(routeFilterProvider);
    ref.read(routeFilterProvider.notifier).state =
        isFrom ? RouteFilter(from: code, to: f.to) : RouteFilter(from: f.from, to: code);
  }

  String _label(String? code, String lang, String anyText) {
    if (code == null) return anyText;
    final c = Countries.all.where((x) => x.code == code);
    return c.isEmpty ? code : '${c.first.flag} ${c.first.name(lang)}';
  }

  String _short(String key) {
    final f = RouteFilter.fromKey(key);
    if (f == null) return key;
    String part(String? code) {
      if (code == null) return '🌍';
      final c = Countries.all.where((x) => x.code == code);
      return c.isEmpty ? code : '${c.first.flag} ${c.first.code}';
    }

    return '${part(f.from)} → ${part(f.to)}';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(currentLocaleProvider).languageCode;
    final filter = ref.watch(routeFilterProvider);
    final saved = ref.watch(savedRoutesProvider);
    final isSaved = saved.contains(filter.key);

    Widget countryButton({required bool isFrom}) {
      final code = isFrom ? filter.from : filter.to;
      return Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _pick(context, ref, isFrom: isFrom),
          child: Container(
            constraints: const BoxConstraints(minHeight: 52),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.hero,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: code != null ? AppColors.accent : AppColors.line),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(strings.t(isFrom ? 'route_from' : 'route_to'),
                    style: const TextStyle(fontSize: 11, color: AppColors.textSoft)),
                Text(
                  _label(code, lang, strings.t('route_any_country')),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppColors.text),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Icon(Icons.search, size: 18, color: AppColors.accent),
                  const SizedBox(width: 6),
                  Text(strings.t('route_search_title'),
                      style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.text)),
                  const Spacer(),
                  if (filter.isActive)
                    TextButton(
                      onPressed: () => ref.read(routeFilterProvider.notifier).state = const RouteFilter(),
                      child: Text(strings.t('route_clear')),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  countryButton(isFrom: true),
                  IconButton(
                    tooltip: strings.t('route_swap'),
                    onPressed: () => ref.read(routeFilterProvider.notifier).state =
                        RouteFilter(from: filter.to, to: filter.from),
                    icon: const Icon(Icons.swap_horiz, color: AppColors.accent),
                  ),
                  countryButton(isFrom: false),
                ],
              ),
              if (filter.isActive) ...[
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: () {
                      final n = ref.read(savedRoutesProvider.notifier);
                      isSaved ? n.remove(filter.key) : n.add(filter.key);
                    },
                    icon: Icon(isSaved ? Icons.star : Icons.star_border, color: AppColors.accent),
                    label: Text(strings.t(isSaved ? 'route_saved' : 'route_save')),
                  ),
                ),
              ],
              if (saved.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(strings.t('route_my_routes'), style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final k in saved)
                      InputChip(
                        label: Text(_short(k)),
                        selected: k == filter.key,
                        selectedColor: AppColors.accent.withValues(alpha: 0.2),
                        onPressed: () {
                          final f = RouteFilter.fromKey(k);
                          if (f != null) ref.read(routeFilterProvider.notifier).state = f;
                        },
                        onDeleted: () => ref.read(savedRoutesProvider.notifier).remove(k),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// Feed layout helpers: an ad slot after every [_adEvery] loads (only
/// while more loads follow, so the feed never ends on an ad slot).
const _adEvery = 6;

int _feedLength(int loads) {
  if (loads <= _adEvery) return loads;
  return loads + (loads - 1) ~/ _adEvery;
}

({bool isAd, int index}) _feedSlot(int i) {
  const block = _adEvery + 1;
  final group = i ~/ block;
  final pos = i % block;
  if (pos == _adEvery) return (isAd: true, index: group);
  return (isAd: false, index: group * _adEvery + pos);
}
