import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/constants/countries.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/country_picker.dart';
import '../../../models/cargo_model.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import 'providers/cargo_providers.dart';

/// Quick "post a load" form, built for speed on a phone: countries and
/// weight are picked with one tap (chips), only city + price are typed.
/// Everything else is optional and folded under "More details".
/// With [editCargoId] the same form edits an existing load.
class CargoQuickForm extends ConsumerStatefulWidget {
  final String? editCargoId;
  const CargoQuickForm({super.key, this.editCargoId});

  @override
  ConsumerState<CargoQuickForm> createState() => _CargoQuickFormState();
}

class _CargoQuickFormState extends ConsumerState<CargoQuickForm> {
  static const _popularCountries = ['AZ', 'RU', 'TR', 'GE', 'KZ', 'UZ', 'TM', 'IR'];
  static const _tonOptions = [1.0, 3.0, 5.0, 10.0, 15.0, 20.0, 22.0, 25.0, 30.0];
  static const _truckOptions = ['tent', 'ref', 'open', 'container', 'tanker'];

  final _formKey = GlobalKey<FormState>();
  final _fromCityCtrl = TextEditingController();
  final _toCityCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  final _customTonsCtrl = TextEditingController();
  final _cargoTypeCtrl = TextEditingController();
  final _volumeCtrl = TextEditingController();

  String? _fromCode;
  String? _toCode;
  String? _fromRaw; // legacy free-text country when editing an old load
  String? _toRaw;
  double? _tons;
  bool _customTons = false;
  String? _truck;
  DateTime? _pickupDate;

  CargoModel? _original;
  bool _loaded = false;
  bool _submitting = false;
  String? _error;

  bool get _isEdit => widget.editCargoId != null;

  @override
  void dispose() {
    for (final c in [_fromCityCtrl, _toCityCtrl, _priceCtrl, _noteCtrl, _customTonsCtrl, _cargoTypeCtrl, _volumeCtrl]) {
      c.dispose();
    }
    super.dispose();
  }

  void _prefill(CargoModel c) {
    _original = c;
    final from = Countries.find(c.pickupCountry);
    final to = Countries.find(c.destinationCountry);
    _fromCode = from?.code;
    _toCode = to?.code;
    _fromRaw = from == null ? c.pickupCountry : null;
    _toRaw = to == null ? c.destinationCountry : null;
    _fromCityCtrl.text = c.pickupCity;
    _toCityCtrl.text = c.destinationCity;
    _priceCtrl.text = c.offeredPrice.toStringAsFixed(0);
    _noteCtrl.text = c.description ?? '';
    _cargoTypeCtrl.text = c.cargoType ?? '';
    _volumeCtrl.text = c.volumeM3 == null ? '' : c.volumeM3!.toStringAsFixed(0);
    final t = c.weightKg / 1000;
    if (_tonOptions.contains(t)) {
      _tons = t;
    } else {
      _customTons = true;
      _customTonsCtrl.text = t == t.roundToDouble() ? t.toStringAsFixed(0) : t.toStringAsFixed(1);
    }
    _truck = _truckOptions.contains(c.truckType) ? c.truckType : null;
    _pickupDate = c.pickupDate;
    _loaded = true;
  }

  String _countryValue(String? code, String? raw) {
    if (code != null) return Countries.all.firstWhere((c) => c.code == code).en;
    return raw ?? '';
  }

  Future<void> _pickOtherCountry({required bool from}) async {
    final lang = ref.read(currentLocaleProvider).languageCode;
    final strings = ref.read(stringsProvider);
    final picked = await showModalBottomSheet<Country>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => CountryPickerSheet(languageCode: lang, strings: strings),
    );
    if (picked == null) return;
    setState(() {
      if (from) {
        _fromCode = picked.code;
        _fromRaw = null;
      } else {
        _toCode = picked.code;
        _toRaw = null;
      }
    });
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _pickupDate ?? now,
      firstDate: DateTime(now.year, now.month, now.day).subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _pickupDate = picked);
  }

  double? get _weightTons {
    if (_customTons) return double.tryParse(_customTonsCtrl.text.trim().replaceAll(',', '.'));
    return _tons;
  }

  Future<void> _submit() async {
    final strings = ref.read(stringsProvider);
    final fromValue = _countryValue(_fromCode, _fromRaw);
    final toValue = _countryValue(_toCode, _toRaw);
    final tons = _weightTons;
    String? problem;
    if (fromValue.isEmpty || toValue.isEmpty) problem = strings.t('quick_err_countries');
    if (problem == null && (tons == null || tons <= 0)) problem = strings.t('quick_err_weight');
    if (problem == null && _pickupDate == null) problem = strings.t('quick_err_date');
    final formOk = _formKey.currentState!.validate();
    if (problem != null || !formOk) {
      setState(() => _error = problem ?? strings.t('quick_err_fields'));
      return;
    }
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final o = _original;
      // If a route end moved, its saved exact point and distance are stale.
      final pickupChanged = o == null || o.pickupCountry != fromValue || o.pickupCity != _fromCityCtrl.text.trim();
      final destChanged = o == null || o.destinationCountry != toValue || o.destinationCity != _toCityCtrl.text.trim();
      final cargo = CargoModel(
        id: o?.id ?? '',
        ownerId: o?.ownerId ?? user.id,
        companyId: o?.companyId,
        pickupCountry: fromValue,
        pickupCity: _fromCityCtrl.text.trim(),
        pickupAddress: o?.pickupAddress,
        pickupLatitude: pickupChanged ? null : o?.pickupLatitude,
        pickupLongitude: pickupChanged ? null : o?.pickupLongitude,
        destinationCountry: toValue,
        destinationCity: _toCityCtrl.text.trim(),
        destinationAddress: o?.destinationAddress,
        destinationLatitude: destChanged ? null : o?.destinationLatitude,
        destinationLongitude: destChanged ? null : o?.destinationLongitude,
        cargoType: _cargoTypeCtrl.text.trim().isEmpty ? null : _cargoTypeCtrl.text.trim(),
        weightKg: tons! * 1000,
        volumeM3: double.tryParse(_volumeCtrl.text.trim().replaceAll(',', '.')),
        palletCount: o?.palletCount,
        truckType: _truck ?? o?.truckType,
        pickupDate: _pickupDate!,
        deliveryDeadline: o?.deliveryDeadline,
        offeredPrice: double.parse(_priceCtrl.text.trim().replaceAll(',', '.')),
        currency: 'USD', // all prices are in US dollars
        description: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
        distanceKm: (pickupChanged || destChanged) ? null : o?.distanceKm,
        status: o?.status ?? 'new',
      );

      final repo = ref.read(cargoRepositoryProvider);
      String id;
      if (o == null) {
        id = (await repo.create(cargo)).id;
      } else {
        await repo.update(cargo);
        id = o.id;
        ref.invalidate(cargoDetailProvider(id));
      }
      ref.invalidate(marketplaceProvider);
      ref.invalidate(myCargoProvider);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(strings.t(o == null ? 'create_success' : 'quick_saved'))),
      );
      if (o == null) {
        context.pushReplacement('/cargo/$id');
      } else {
        context.pop();
      }
    } on AppException catch (e) {
      setState(() => _error = strings.error(e.code));
    } catch (_) {
      setState(() => _error = strings.t('error_generic'));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(stringsProvider);
    final lang = ref.watch(currentLocaleProvider).languageCode;

    if (_isEdit && !_loaded) {
      final async = ref.watch(cargoDetailProvider(widget.editCargoId!));
      return Scaffold(
        appBar: AppBar(title: Text(strings.t('quick_edit_title'))),
        body: async.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => Center(child: Text(strings.t('error_generic'))),
          data: (c) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted && !_loaded) setState(() => _prefill(c));
            });
            return const Center(child: CircularProgressIndicator());
          },
        ),
      );
    }

    final dateFmt = DateFormat('d MMM yyyy', lang);
    final today = DateTime.now();
    final tomorrow = today.add(const Duration(days: 1));
    bool sameDay(DateTime? a, DateTime b) => a != null && a.year == b.year && a.month == b.month && a.day == b.day;

    return Scaffold(
      appBar: AppBar(title: Text(strings.t(_isEdit ? 'quick_edit_title' : 'create_title'))),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
            children: [
              _Label(strings.t('route_from')),
              _CountryChips(
                codes: _popularCountries,
                selected: _fromCode,
                legacyLabel: _fromRaw,
                lang: lang,
                otherLabel: strings.t('quick_other_country'),
                onSelect: (c) => setState(() {
                  _fromCode = c;
                  _fromRaw = null;
                }),
                onOther: () => _pickOtherCountry(from: true),
              ),
              const SizedBox(height: 8),
              _CityField(controller: _fromCityCtrl, hint: strings.t('quick_city_hint'), strings: strings),

              const SizedBox(height: 18),
              _Label(strings.t('route_to')),
              _CountryChips(
                codes: _popularCountries,
                selected: _toCode,
                legacyLabel: _toRaw,
                lang: lang,
                otherLabel: strings.t('quick_other_country'),
                onSelect: (c) => setState(() {
                  _toCode = c;
                  _toRaw = null;
                }),
                onOther: () => _pickOtherCountry(from: false),
              ),
              const SizedBox(height: 8),
              _CityField(controller: _toCityCtrl, hint: strings.t('quick_city_hint'), strings: strings),

              const SizedBox(height: 18),
              _Label(strings.t('quick_weight')),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final t in _tonOptions)
                    ChoiceChip(
                      label: Text('${t.toStringAsFixed(0)} t'),
                      selected: !_customTons && _tons == t,
                      onSelected: (_) => setState(() {
                        _tons = t;
                        _customTons = false;
                      }),
                    ),
                  ChoiceChip(
                    label: Text(strings.t('quick_other')),
                    selected: _customTons,
                    onSelected: (_) => setState(() => _customTons = true),
                  ),
                ],
              ),
              if (_customTons)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: TextFormField(
                    controller: _customTonsCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: strings.t('quick_weight_tons'), suffixText: 't'),
                  ),
                ),

              const SizedBox(height: 18),
              _Label(strings.t('create_pickup_date')),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ChoiceChip(
                    label: Text(strings.t('quick_today')),
                    selected: sameDay(_pickupDate, today),
                    onSelected: (_) => setState(() => _pickupDate = DateTime(today.year, today.month, today.day)),
                  ),
                  ChoiceChip(
                    label: Text(strings.t('quick_tomorrow')),
                    selected: sameDay(_pickupDate, tomorrow),
                    onSelected: (_) => setState(() => _pickupDate = DateTime(tomorrow.year, tomorrow.month, tomorrow.day)),
                  ),
                  ChoiceChip(
                    avatar: const Icon(Icons.calendar_month, size: 18),
                    label: Text(
                      (_pickupDate != null && !sameDay(_pickupDate, today) && !sameDay(_pickupDate, tomorrow))
                          ? dateFmt.format(_pickupDate!)
                          : strings.t('quick_pick_date'),
                    ),
                    selected: _pickupDate != null && !sameDay(_pickupDate, today) && !sameDay(_pickupDate, tomorrow),
                    onSelected: (_) => _pickDate(),
                  ),
                ],
              ),

              const SizedBox(height: 18),
              _Label(strings.t('create_price')),
              TextFormField(
                controller: _priceCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(suffixText: 'USD'),
                validator: (v) {
                  final p = double.tryParse((v ?? '').trim().replaceAll(',', '.'));
                  return (p == null || p < 0) ? strings.t('field_required') : null;
                },
              ),

              const SizedBox(height: 18),
              _Label(strings.t('quick_note')),
              TextFormField(
                controller: _noteCtrl,
                maxLines: 2,
                maxLength: 200,
                decoration: InputDecoration(hintText: strings.t('quick_note_hint')),
              ),

              // Optional extras, folded away so the form stays short.
              Theme(
                data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: Text(strings.t('quick_more'), style: const TextStyle(fontWeight: FontWeight.w600)),
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: _Label(strings.t('create_truck_type')),
                    ),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final t in _truckOptions)
                          ChoiceChip(
                            label: Text(strings.t('truck_$t')),
                            selected: _truck == t,
                            onSelected: (sel) => setState(() => _truck = sel ? t : null),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _cargoTypeCtrl,
                      decoration: InputDecoration(labelText: strings.t('create_cargo_type')),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _volumeCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(labelText: strings.t('create_volume_m3')),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),

              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!, style: const TextStyle(color: AppColors.danger)),
                ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _submitting ? null : _submit,
                child: _submitting
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(strings.t(_isEdit ? 'quick_save' : 'create_submit')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.textSoft)),
      );
}

class _CityField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final AppStrings strings;
  const _CityField({required this.controller, required this.hint, required this.strings});

  @override
  Widget build(BuildContext context) => TextFormField(
        controller: controller,
        textCapitalization: TextCapitalization.words,
        decoration: InputDecoration(hintText: hint, prefixIcon: const Icon(Icons.location_city_outlined)),
        validator: (v) => (v == null || v.trim().isEmpty) ? strings.t('field_required') : null,
      );
}

/// One-tap country choice: popular countries as flag chips + "Other…".
class _CountryChips extends StatelessWidget {
  final List<String> codes;
  final String? selected;
  final String? legacyLabel;
  final String lang;
  final String otherLabel;
  final ValueChanged<String> onSelect;
  final VoidCallback onOther;
  const _CountryChips({
    required this.codes,
    required this.selected,
    required this.legacyLabel,
    required this.lang,
    required this.otherLabel,
    required this.onSelect,
    required this.onOther,
  });

  @override
  Widget build(BuildContext context) {
    final byCode = {for (final c in Countries.all) c.code: c};
    final extra = (selected != null && !codes.contains(selected)) ? byCode[selected] : null;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final code in codes)
          if (byCode[code] != null)
            ChoiceChip(
              label: Text('${byCode[code]!.flag} ${byCode[code]!.name(lang)}'),
              selected: selected == code,
              onSelected: (_) => onSelect(code),
            ),
        if (extra != null)
          ChoiceChip(label: Text('${extra.flag} ${extra.name(lang)}'), selected: true, onSelected: (_) {}),
        if (legacyLabel != null && legacyLabel!.isNotEmpty)
          ChoiceChip(label: Text(legacyLabel!), selected: true, onSelected: (_) {}),
        ActionChip(avatar: const Icon(Icons.public, size: 18), label: Text(otherLabel), onPressed: onOther),
      ],
    );
  }
}
