import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/constants/countries.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/status_stepper.dart';
import '../../../models/cargo_model.dart';
import '../../../models/offer_model.dart';
import '../../../repositories/credits_repository.dart';
import '../../../repositories/offer_repository.dart';
import '../../../repositories/shipment_repository.dart';
import '../../../services/navigation_service.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../carrier/presentation/providers/carrier_providers.dart';
import '../../chat/presentation/providers/chat_providers.dart';
import 'providers/cargo_providers.dart';

class CargoDetailScreen extends ConsumerWidget {
  final String cargoId;
  const CargoDetailScreen({super.key, required this.cargoId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    final cargoAsync = ref.watch(cargoDetailProvider(cargoId));

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('detail_title'))),
      body: cargoAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text(strings.t('detail_not_found'))),
        data: (cargo) => _DetailBody(cargo: cargo),
      ),
    );
  }
}

class _RouteEnd extends StatelessWidget {
  final String value;
  final String city;
  final String localeCode;
  final bool alignEnd;
  const _RouteEnd({required this.value, required this.city, required this.localeCode, required this.alignEnd});

  @override
  Widget build(BuildContext context) {
    final c = Countries.find(value);
    final align = alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    return Column(
      crossAxisAlignment: align,
      children: [
        if (c != null) Text(c.flag, style: const TextStyle(fontSize: 26, height: 1)),
        const SizedBox(height: 4),
        Text(
          (c?.name(localeCode) ?? value).toUpperCase(),
          textAlign: alignEnd ? TextAlign.end : TextAlign.start,
          style: AppFonts.display(size: 24, color: AppColors.text, height: 1.05),
        ),
        Text(city, style: const TextStyle(fontSize: 13, color: AppColors.textSoft)),
      ],
    );
  }
}

class _DetailBody extends ConsumerWidget {
  final CargoModel cargo;
  const _DetailBody({required this.cargo});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final isOwner = user != null && user.id == cargo.ownerId;
    final localeCode = ref.watch(currentLocaleProvider).languageCode;
    final dateFmt = DateFormat('d MMM yyyy', localeCode);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        // Route + price card — same visual language as the marketplace card.
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(child: _RouteEnd(value: cargo.pickupCountry, city: cargo.pickupCity, localeCode: localeCode, alignEnd: false)),
                    Column(
                      children: [
                        if (cargo.distanceKm != null)
                          Text('${cargo.distanceKm!.toStringAsFixed(0)} km', style: AppFonts.mono(color: AppColors.route)),
                        const SizedBox(height: 4),
                        const Icon(Icons.arrow_forward, color: AppColors.route, size: 22),
                      ],
                    ),
                    Expanded(child: _RouteEnd(value: cargo.destinationCountry, city: cargo.destinationCity, localeCode: localeCode, alignEnd: true)),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(height: 1),
                const SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(cargo.offeredPrice.toStringAsFixed(0), style: AppFonts.display(size: 36, color: AppColors.text, height: 1)),
                    const SizedBox(width: 6),
                    Text(cargo.currency, style: const TextStyle(fontSize: 13, color: AppColors.textSoft)),
                    const Spacer(),
                    Text(strings.t('detail_offered_price'), style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InfoRow(strings.t('detail_weight_label'), '${cargo.weightKg.toStringAsFixed(0)} kg'),
                if (cargo.volumeM3 != null) _InfoRow(strings.t('detail_volume_label'), '${cargo.volumeM3} m³'),
                if (cargo.palletCount != null) _InfoRow(strings.t('detail_pallets_label'), '${cargo.palletCount}'),
                if (cargo.truckType != null) _InfoRow(strings.t('detail_truck_type_label'), cargo.truckType!),
                _InfoRow(strings.t('detail_pickup_date_label'), dateFmt.format(cargo.pickupDate)),
                if (cargo.deliveryDeadline != null)
                  _InfoRow(strings.t('detail_delivery_deadline_label'), dateFmt.format(cargo.deliveryDeadline!)),
                _InfoRow(strings.t('detail_status_label'), _statusLabel(strings, cargo.status)),
                if (cargo.description != null && cargo.description!.isNotEmpty)
                  _InfoRow(strings.t('detail_description_label'), cargo.description!),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(strings.t('detail_progress_title'), style: AppFonts.mono(color: AppColors.textSoft, letterSpacing: 1)),
                const SizedBox(height: 12),
                StatusStepper(status: cargo.status, strings: strings),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        _NavigationButtons(cargo: cargo, strings: strings),

        if (!isOwner) ...[
          const SizedBox(height: 16),
          _ContactUnlockSection(cargo: cargo, strings: strings),
          const SizedBox(height: 16),
          _MessageOwnerButton(cargo: cargo, strings: strings),
          const SizedBox(height: 16),
          _CarrierOfferSection(cargo: cargo, strings: strings),
        ],

        if (isOwner) ...[
          const SizedBox(height: 16),
          _OffersReceivedSection(cargo: cargo, strings: strings),
        ],
      ],
    );
  }

  String _statusLabel(AppStrings strings, String status) {
    // cargo.status uses the same vocabulary as shipments
    // (new/carrier_found/.../completed/cancelled — see migration
    // 0001), hence shipment_status_* keys here, not offer_status_*
    // (which is a different, offer-specific vocabulary).
    final key = 'shipment_status_$status';
    final label = strings.t(key);
    return label == key ? status : label;
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 130, child: Text(label, style: Theme.of(context).textTheme.bodySmall)),
          Expanded(child: Text(value, style: Theme.of(context).textTheme.bodyMedium)),
        ],
      ),
    );
  }
}

/// External maps hand-off (brief §10) — the one real, wired use of
/// NavigationService. Only shown when the cargo actually has
/// coordinates (optional fields on the create form); otherwise an
/// honest "not available" note instead of a dead button.
class _NavigationButtons extends ConsumerWidget {
  final CargoModel cargo;
  final AppStrings strings;
  const _NavigationButtons({required this.cargo, required this.strings});

  Future<void> _showAppPicker(BuildContext context, WidgetRef ref, {required double lat, required double lng, required String label}) async {
    final apps = navigationService.availableApps();
    final chosen = await showModalBottomSheet<NavApp>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(padding: const EdgeInsets.all(16), child: Text(strings.t('nav_sheet_title'), style: Theme.of(context).textTheme.titleMedium)),
            for (final app in apps)
              ListTile(
                title: Text(_appLabel(app)),
                onTap: () => Navigator.of(context).pop(app),
              ),
            ListTile(title: Text(strings.t('nav_sheet_cancel')), onTap: () => Navigator.of(context).pop()),
          ],
        ),
      ),
    );
    if (chosen == null) return;
    await navigationService.startNavigation(chosen, lat: lat, lng: lng, label: label);
  }

  String _appLabel(NavApp app) => switch (app) {
        NavApp.googleMaps => strings.t('nav_sheet_google'),
        NavApp.appleMaps => strings.t('nav_sheet_apple'),
        NavApp.waze => strings.t('nav_sheet_waze'),
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasPickup = cargo.pickupLatitude != null && cargo.pickupLongitude != null;
    final hasDest = cargo.destinationLatitude != null && cargo.destinationLongitude != null;
    if (!hasPickup && !hasDest) {
      return Text(strings.t('detail_no_coordinates'), style: Theme.of(context).textTheme.bodySmall);
    }
    return Wrap(
      spacing: 10,
      children: [
        if (hasPickup)
          OutlinedButton.icon(
            icon: const Icon(Icons.navigation_outlined),
            label: Text('${strings.t('detail_start_navigation')} — ${cargo.pickupCity}'),
            onPressed: () => _showAppPicker(context, ref, lat: cargo.pickupLatitude!, lng: cargo.pickupLongitude!, label: cargo.pickupCity),
          ),
        if (hasDest)
          OutlinedButton.icon(
            icon: const Icon(Icons.navigation_outlined),
            label: Text('${strings.t('detail_start_navigation')} — ${cargo.destinationCity}'),
            onPressed: () => _showAppPicker(context, ref, lat: cargo.destinationLatitude!, lng: cargo.destinationLongitude!, label: cargo.destinationCity),
          ),
      ],
    );
  }
}

/// Contact-credit gate (brief §11), for anyone viewing cargo who isn't
/// its owner. Real read of unlock status + real spend via the atomic
/// unlock_contact() database function — see CreditsRepository.
class _ContactUnlockSection extends ConsumerWidget {
  final CargoModel cargo;
  final AppStrings strings;
  const _ContactUnlockSection({required this.cargo, required this.strings});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final unlockedAsync = ref.watch(contactUnlockedProvider(cargo.id));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: unlockedAsync.when(
          loading: () => const Center(child: Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator())),
          error: (_, __) => const SizedBox.shrink(),
          data: (unlocked) {
            if (unlocked) {
              return FutureBuilder<Map<String, String?>>(
                future: ref.read(creditsRepositoryProvider).fetchOwnerContact(cargo.ownerId),
                builder: (context, snapshot) {
                  final contact = snapshot.data;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(strings.t('detail_owner_contact_title'), style: Theme.of(context).textTheme.titleSmall),
                      const SizedBox(height: 8),
                      if (contact == null)
                        const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      else ...[
                        if (contact['full_name'] != null) Text(contact['full_name']!),
                        if (contact['phone'] != null) Text(contact['phone']!),
                        if (contact['email'] != null) Text(contact['email']!),
                      ],
                    ],
                  );
                },
              );
            }
            return _UnlockButton(cargo: cargo, strings: strings);
          },
        ),
      ),
    );
  }
}

class _UnlockButton extends ConsumerStatefulWidget {
  final CargoModel cargo;
  final AppStrings strings;
  const _UnlockButton({required this.cargo, required this.strings});

  @override
  ConsumerState<_UnlockButton> createState() => _UnlockButtonState();
}

class _UnlockButtonState extends ConsumerState<_UnlockButton> {
  bool _busy = false;
  String? _error;

  Future<void> _unlock() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(creditsRepositoryProvider).unlockContact(widget.cargo.id);
      ref.invalidate(contactUnlockedProvider(widget.cargo.id));
      ref.invalidate(creditsBalanceProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(widget.strings.t('detail_unlock_success'))));
      }
    } on AppException catch (e) {
      setState(() => _error = widget.strings.error(e.code));
    } catch (_) {
      setState(() => _error = widget.strings.t('error_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.strings.t('detail_owner_contact_title'), style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: _busy ? null : _unlock,
          icon: const Icon(Icons.lock_open),
          label: Text(_busy ? widget.strings.t('detail_unlocking') : widget.strings.t('detail_unlock_button')),
        ),
        if (_error != null) ...[
          const SizedBox(height: 6),
          Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        ],
      ],
    );
  }
}

class _MessageOwnerButton extends ConsumerWidget {
  final CargoModel cargo;
  final AppStrings strings;
  const _MessageOwnerButton({required this.cargo, required this.strings});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return OutlinedButton.icon(
      icon: const Icon(Icons.chat_bubble_outline),
      label: Text(strings.t('detail_message_button')),
      onPressed: () async {
        final user = ref.read(currentUserProvider);
        if (user == null) return;
        final conversation = await ref.read(messageRepositoryProvider).getOrCreateConversation(
              cargoId: cargo.id,
              cargoOwnerId: cargo.ownerId,
              carrierUserId: user.id,
            );
        if (context.mounted) context.push('/messages/${conversation.id}');
      },
    );
  }
}

/// Carrier's own offer on this cargo — submit / update / withdraw.
/// Enforces the one-active-pending-offer rule (migration 0004) by
/// finding the current pending offer (if any) and showing "update /
/// withdraw" instead of a second submit form.
class _CarrierOfferSection extends ConsumerStatefulWidget {
  final CargoModel cargo;
  final AppStrings strings;
  const _CarrierOfferSection({required this.cargo, required this.strings});

  @override
  ConsumerState<_CarrierOfferSection> createState() => _CarrierOfferSectionState();
}

class _CarrierOfferSectionState extends ConsumerState<_CarrierOfferSection> {
  final _priceCtrl = TextEditingController();
  final _messageCtrl = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _priceCtrl.dispose();
    _messageCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitNew(String carrierId) async {
    final price = double.tryParse(_priceCtrl.text.trim());
    if (price == null) {
      setState(() => _error = widget.strings.t('field_invalid_number'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(offerRepositoryProvider).submit(OfferModel(
            id: '',
            cargoId: widget.cargo.id,
            carrierId: carrierId,
            offeredPrice: price,
            currency: widget.cargo.currency,
            message: _messageCtrl.text.trim().isEmpty ? null : _messageCtrl.text.trim(),
          ));
      _invalidateOffers(carrierId);
    } on AppException catch (e) {
      setState(() => _error = widget.strings.error(e.code));
    } catch (_) {
      setState(() => _error = widget.strings.t('error_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _update(String offerId, String carrierId) async {
    final price = double.tryParse(_priceCtrl.text.trim());
    if (price == null) {
      setState(() => _error = widget.strings.t('field_invalid_number'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(offerRepositoryProvider).updatePendingOffer(
            offerId: offerId,
            newOfferedPrice: price,
            newMessage: _messageCtrl.text.trim().isEmpty ? null : _messageCtrl.text.trim(),
          );
      _invalidateOffers(carrierId);
    } on AppException catch (e) {
      setState(() => _error = widget.strings.error(e.code));
    } catch (_) {
      setState(() => _error = widget.strings.t('error_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _withdraw(String offerId, String carrierId) async {
    setState(() => _busy = true);
    try {
      await ref.read(offerRepositoryProvider).withdraw(offerId);
      _invalidateOffers(carrierId);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _invalidateOffers(String carrierId) {
    ref.invalidate(myOfferHistoryProvider(CarrierCargoKey(widget.cargo.id, carrierId)));
    ref.invalidate(offersForCargoProvider(widget.cargo.id));
  }

  @override
  Widget build(BuildContext context) {
    final carrierIdAsync = ref.watch(myCarrierIdProvider);
    return carrierIdAsync.when(
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
      data: (carrierId) {
        if (carrierId == null) return const SizedBox.shrink();
        final historyAsync = ref.watch(myOfferHistoryProvider(CarrierCargoKey(widget.cargo.id, carrierId)));

        return historyAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const SizedBox.shrink(),
          data: (history) {
            final pending = history.where((o) => o.status == 'pending').toList();
            final hasPending = pending.isNotEmpty;
            if (hasPending && _priceCtrl.text.isEmpty) {
              _priceCtrl.text = pending.first.offeredPrice.toStringAsFixed(0);
            }

            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.strings.t('detail_your_offer_title'), style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _priceCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(labelText: widget.strings.t('detail_offer_price_label'), border: const OutlineInputBorder()),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _messageCtrl,
                      decoration: InputDecoration(labelText: widget.strings.t('detail_offer_message_label'), border: const OutlineInputBorder()),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 8),
                      Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                    ],
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      children: [
                        FilledButton(
                          onPressed: _busy
                              ? null
                              : () => hasPending ? _update(pending.first.id, carrierId) : _submitNew(carrierId),
                          child: Text(hasPending ? widget.strings.t('detail_update_offer') : widget.strings.t('detail_submit_offer')),
                        ),
                        if (hasPending)
                          OutlinedButton(
                            onPressed: _busy ? null : () => _withdraw(pending.first.id, carrierId),
                            child: Text(widget.strings.t('detail_withdraw_offer')),
                          ),
                      ],
                    ),
                    if (history.isNotEmpty) ...[
                      const Divider(height: 24),
                      ...history.map((o) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Text(
                              '${o.offeredPrice.toStringAsFixed(0)} ${o.currency} — ${widget.strings.t('offer_status_${o.status}')}',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          )),
                    ],
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

/// Cargo owner's view: every offer received, with accept/reject.
/// Accepting an offer also creates the shipment (ShipmentRepository) —
/// the acceptance test's "owner responds" step needs the offer to
/// actually move the workflow forward, not just flip a status flag.
class _OffersReceivedSection extends ConsumerStatefulWidget {
  final CargoModel cargo;
  final AppStrings strings;
  const _OffersReceivedSection({required this.cargo, required this.strings});

  @override
  ConsumerState<_OffersReceivedSection> createState() => _OffersReceivedSectionState();
}

class _OffersReceivedSectionState extends ConsumerState<_OffersReceivedSection> {
  final Set<String> _busyOfferIds = {};
  String? _error;

  Future<void> _respond(OfferModel offer, String status) async {
    setState(() {
      _busyOfferIds.add(offer.id);
      _error = null;
    });
    try {
      await ref.read(offerRepositoryProvider).respond(offerId: offer.id, status: status);
      if (status == 'accepted') {
        await ref.read(shipmentRepositoryProvider).createFromAcceptedOffer(
              cargoId: widget.cargo.id,
              carrierId: offer.carrierId,
              acceptedOfferId: offer.id,
              agreedPrice: offer.offeredPrice,
            );
        // Close the deal on this cargo: competing pending offers are
        // rejected and the cargo leaves the open marketplace
        // ('agreed' — the marketplace lists status 'new' only).
        await ref.read(offerRepositoryProvider).rejectOtherPending(
              cargoId: widget.cargo.id,
              acceptedOfferId: offer.id,
            );
        await ref.read(shipmentRepositoryProvider).setCargoStatus(cargoId: widget.cargo.id, status: 'agreed');
        ref.invalidate(marketplaceProvider);
        ref.invalidate(myShipmentsProvider);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(widget.strings.t('detail_offer_accepted_note'))),
          );
        }
      }
      ref.invalidate(offersForCargoProvider(widget.cargo.id));
      ref.invalidate(cargoDetailProvider(widget.cargo.id));
    } on AppException catch (e) {
      setState(() => _error = widget.strings.error(e.code));
    } catch (_) {
      setState(() => _error = widget.strings.t('error_generic'));
    } finally {
      if (mounted) setState(() => _busyOfferIds.remove(offer.id));
    }
  }

  @override
  Widget build(BuildContext context) {
    final offersAsync = ref.watch(offersForCargoProvider(widget.cargo.id));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.strings.t('detail_offers_received_title'), style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 10),
            if (_error != null) Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ),
            offersAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (_, __) => const SizedBox.shrink(),
              data: (offers) {
                if (offers.isEmpty) return Text(widget.strings.t('detail_no_offers_yet'));
                return Column(
                  children: offers.map((o) {
                    final busy = _busyOfferIds.contains(o.id);
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${o.offeredPrice.toStringAsFixed(0)} ${o.currency}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                Text(widget.strings.t('offer_status_${o.status}'), style: Theme.of(context).textTheme.bodySmall),
                                if (o.message != null) Text(o.message!, style: Theme.of(context).textTheme.bodySmall),
                              ],
                            ),
                          ),
                          if (o.status == 'pending') ...[
                            IconButton(
                              tooltip: widget.strings.t('detail_accept_offer'),
                              icon: const Icon(Icons.check_circle_outline, color: Colors.teal),
                              onPressed: busy ? null : () => _respond(o, 'accepted'),
                            ),
                            IconButton(
                              tooltip: widget.strings.t('detail_reject_offer'),
                              icon: const Icon(Icons.cancel_outlined),
                              onPressed: busy ? null : () => _respond(o, 'rejected'),
                            ),
                          ],
                          if (busy) const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
