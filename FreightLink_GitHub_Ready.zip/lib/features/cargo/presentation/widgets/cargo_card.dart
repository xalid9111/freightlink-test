import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../../../core/localization/app_strings.dart';
import '../../../../core/localization/locale_controller.dart';
import '../../../../models/cargo_model.dart';

/// Real cargo card — not a mock. FROM → TO is the visually dominant
/// element per the product brief; price, cargo type, weight, truck
/// type and pickup date are all shown, all real fields off CargoModel.
class CargoCard extends ConsumerWidget {
  final CargoModel cargo;
  final AppStrings strings;
  final VoidCallback onTap;

  const CargoCard({super.key, required this.cargo, required this.strings, required this.onTap});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Locale-aware date formatting (month names etc.) — not just the
    // button/label text — so a switched language looks consistent
    // everywhere, not just in the parts that are plain strings.
    final localeCode = ref.watch(currentLocaleProvider).languageCode;
    final dateFmt = DateFormat('d MMM', localeCode);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // FROM -> TO: the dominant visual element.
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cargo.pickupCountry.toUpperCase(),
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        Text(cargo.pickupCity, style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6),
                    child: Icon(Icons.arrow_forward, size: 20),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          cargo.destinationCountry.toUpperCase(),
                          textAlign: TextAlign.end,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        Text(cargo.destinationCity, style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Divider(height: 1),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '${cargo.offeredPrice.toStringAsFixed(0)} ${cargo.currency}',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  Text(dateFmt.format(cargo.pickupDate), style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  if (cargo.cargoType != null) _Tag(cargo.cargoType!),
                  _Tag('${cargo.weightKg.toStringAsFixed(0)} kg'),
                  if (cargo.truckType != null) _Tag(cargo.truckType!),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String label;
  const _Tag(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(label, style: Theme.of(context).textTheme.labelSmall),
    );
  }
}
