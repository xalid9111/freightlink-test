import 'dart:math' as math;
import 'dart:ui' show FrameTiming;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'wheel_feed.dart';

/// Home "live world map".
///
/// * Background: a static night-lights world map (assets/images/
///   world_map.jpg) with its edges already faded into the page colour in
///   the image itself — no frame, no runtime gradient cost. Shown full
///   width, edge to edge.
/// * Overlay: a separate transparent layer with light beams. Each beam
///   leaves a city, rises in an arc and lands on another city: bright
///   head, fading tail, faint dashed path, a small flash on arrival. A
///   handful live at once, born and dying at random times.
///
/// Performance: one Ticker drives a ValueNotifier the painter listens to
/// (no widget rebuilds per frame); beams are plain objects recycled from
/// a small pool; no blur filters. It pauses while the feed scrolls, when
/// the map is scrolled out of view and when the tab is hidden (TickerMode).
/// If frames get slow it drops to ~30 fps and fewer beams.
class LiveMap extends StatefulWidget {
  /// Text of the blinking badge in the map's top-right corner.
  final String liveLabel;
  const LiveMap({super.key, this.liveLabel = 'CANLI'});

  @override
  State<LiveMap> createState() => _LiveMapState();
}

/// Image size the positions below refer to (assets/images/world_map.jpg:
/// oval "globe" version, edges faded into the page colour).
const double _imgW = 1400, _imgH = 700;

/// Hubs (pixel position on the map image): spread over every continent
/// — no single centre.
const List<Offset> _hubs = [
  Offset(254, 224), // New York
  Offset(104, 256), // Los Angeles
  Offset(220, 214), // Chicago
  Offset(142, 309), // Mexico City
  Offset(206, 373), // Bogotá
  Offset(321, 490), // São Paulo
  Offset(282, 536), // Buenos Aires
  Offset(558, 174), // London
  Offset(599, 186), // Central Europe
  Offset(539, 223), // Madrid
  Offset(698, 153), // Moscow
  Offset(693, 231), // Istanbul
  Offset(718, 264), // Cairo
  Offset(558, 371), // Lagos
  Offset(773, 426), // Nairobi
  Offset(693, 528), // Johannesburg
  Offset(795, 228), // Baku
  Offset(832, 295), // Dubai
  Offset(820, 244), // Tehran
  Offset(947, 215), // Almaty
  Offset(936, 281), // Delhi
  Offset(924, 327), // Mumbai
  Offset(937, 151), // Novosibirsk
  Offset(1135, 223), // Beijing
  Offset(1159, 269), // Shanghai
  Offset(1225, 253), // Tokyo
  Offset(1133, 312), // Hong Kong
  Offset(1082, 412), // Singapore
  Offset(1103, 448), // Jakarta
  Offset(1247, 570), // Sydney
  Offset(1125, 557), // Perth
];

/// Extra land points used only by the blinking status lights.
const List<Offset> _landPoints = [
  Offset(185, 189),
  Offset(280, 248),
  Offset(193, 451),
  Offset(356, 422),
  Offset(635, 211),
  Offset(760, 194),
  Offset(852, 170),
  Offset(1027, 185),
  Offset(1083, 291),
  Offset(1001, 347),
  Offset(615, 464),
  Offset(743, 357),
  Offset(1177, 516),
  Offset(1217, 543),
  Offset(440, 166),
  Offset(149, 155),
  Offset(862, 337),
  Offset(1198, 329),
  Offset(250, 453),
  Offset(515, 307),
];

const _orange = Color(0xFFFF7A2E);
const _red = Color(0xFFFF4D5E);
const _green = Color(0xFF3DDC84);

/// A small soft status light that fades in and out somewhere on land.
class _Blink {
  Offset pos = Offset.zero;
  Color color = _green;
  double start = 0; // seconds
  double period = 3; // seconds of one fade-in/out
  /// 0..1 brightness at [now] (0 while waiting to start).
  double intensity(double now) {
    final p = (now - start) / period;
    if (p <= 0 || p >= 1) return 0;
    final v = math.sin(math.pi * p);
    return v * v;
  }
}

const _blue = Color(0xFF4AA8FF);

class _Beam {
  late Offset a, b; // in image pixels
  late double lift; // arc height factor
  late Color color;
  late double born; // seconds
  late double travel; // seconds from a to b
  bool alive = false;

  static const double fade = 0.9; // tail fade-out + flash after arrival

  double get end => born + travel + fade;
}

class _LiveMapState extends State<LiveMap> with TickerProviderStateMixin {
  late final Ticker _ticker;
  final ValueNotifier<double> _time = ValueNotifier(0);
  final _rng = math.Random();
  late final List<_Beam> _pool = List.generate(9, (_) => _Beam());
  late final List<_Blink> _blinks = List.generate(15, (i) => _resetBlink(_Blink(), i * 0.25));
  late final AnimationController _badge =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);
  double _nextSpawn = 0.2;
  Duration _last = Duration.zero;

  // adaptive quality
  bool _lite = false;
  final List<double> _frameMs = [];
  bool _skipOdd = false;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
    WheelSignals.scrolling.addListener(_onScrolling);
    SchedulerBinding.instance.addTimingsCallback(_onTimings);
  }

  @override
  void dispose() {
    SchedulerBinding.instance.removeTimingsCallback(_onTimings);
    WheelSignals.scrolling.removeListener(_onScrolling);
    _ticker.dispose();
    _badge.dispose();
    _time.dispose();
    super.dispose();
  }

  /// Pause while the feed scrolls; resume only if the map is in view.
  void _onScrolling() {
    if (!mounted) return;
    if (WheelSignals.scrolling.value) {
      if (_ticker.isActive) _ticker.stop();
    } else if (WheelSignals.offset < 420 && !_ticker.isActive) {
      _last = Duration.zero;
      _ticker.start();
    }
  }

  void _onTimings(List<FrameTiming> timings) {
    for (final t in timings) {
      _frameMs.add((t.buildDuration + t.rasterDuration).inMicroseconds / 1000.0);
    }
    if (_frameMs.length < 30) return;
    final avg = _frameMs.reduce((a, b) => a + b) / _frameMs.length;
    _frameMs.clear();
    if (avg > 20) {
      _lite = true;
    } else if (avg < 9) {
      _lite = false;
    }
  }

  void _onTick(Duration elapsed) {
    // Ticker restarts from zero after a pause: keep our own clock.
    final dt = _last == Duration.zero ? 0.016 : (elapsed - _last).inMicroseconds / 1e6;
    _last = elapsed;
    if (_lite) {
      _skipOdd = !_skipOdd;
      if (_skipOdd) return; // ~30 fps on slow devices
    }
    final now = _time.value + dt.clamp(0, 0.1);
    for (final b in _pool) {
      if (b.alive && now > b.end) b.alive = false;
    }
    for (final b in _blinks) {
      if (now >= b.start + b.period) _resetBlink(b, now + _rng.nextDouble() * 1.2);
    }
    final maxAlive = _lite ? 4 : 7;
    if (now >= _nextSpawn && _pool.where((b) => b.alive).length < maxAlive) {
      _spawn(now);
      _nextSpawn = now + 0.35 + _rng.nextDouble() * 0.9;
    }
    _time.value = now;
  }

  _Blink _resetBlink(_Blink b, double start) {
    final all = _rng.nextBool() ? _hubs : _landPoints;
    b
      ..pos = all[_rng.nextInt(all.length)]
      ..color = _rng.nextBool() ? _red : _green
      ..start = start
      ..period = 2.2 + _rng.nextDouble() * 2.0;
    return b;
  }

  void _spawn(double now) {
    final beam = _pool.firstWhere((b) => !b.alive, orElse: () => _pool.first);
    final i = _rng.nextInt(_hubs.length);
    var j = _rng.nextInt(_hubs.length);
    while (j == i || (_hubs[i] - _hubs[j]).distance < 110) {
      j = _rng.nextInt(_hubs.length);
    }
    final dist = (_hubs[i] - _hubs[j]).distance;
    beam
      ..a = _hubs[i]
      ..b = _hubs[j]
      ..lift = 0.32 + _rng.nextDouble() * 0.16
      ..color = _rng.nextBool() ? _orange : _blue
      ..born = now
      ..travel = (1.3 + dist / 410).clamp(1.4, 3.2)
      ..alive = true;
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 2 / 1,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Static background (edges faded into the page colour in the image).
          RepaintBoundary(
            child: Image.asset(
              'assets/images/world_map.jpg',
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
          // Animated transparent layer.
          RepaintBoundary(
            child: IgnorePointer(
              child: CustomPaint(painter: _BeamPainter(_time, _pool, _blinks)),
            ),
          ),
          // "CANLI" badge with a breathing green light, top-right.
          Positioned(
            top: 6,
            right: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _green.withValues(alpha: 0.35)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FadeTransition(
                    opacity: CurvedAnimation(parent: _badge, curve: Curves.easeInOut).drive(Tween(begin: 0.25, end: 1.0)),
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: _green,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: _green.withValues(alpha: 0.7), blurRadius: 6)],
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(widget.liveLabel,
                      style: const TextStyle(color: _green, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BeamPainter extends CustomPainter {
  final ValueNotifier<double> time;
  final List<_Beam> beams;
  final List<_Blink> blinks;
  _BeamPainter(this.time, this.beams, this.blinks) : super(repaint: time);

  static const int _trailSegments = 14;
  static const double _trailLength = 0.45; // share of the path

  @override
  void paint(Canvas canvas, Size size) {
    final now = time.value;
    final sx = size.width / _imgW, sy = size.height / _imgH;
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final fill = Paint()..style = PaintingStyle.fill;

    // Soft red / green status lights fading in and out on land.
    for (final l in blinks) {
      final i = l.intensity(now);
      if (i <= 0.01) continue;
      final p = Offset(l.pos.dx * sx, l.pos.dy * sy);
      fill.color = l.color.withValues(alpha: 0.14 * i);
      canvas.drawCircle(p, 7, fill);
      fill.color = l.color.withValues(alpha: 0.32 * i);
      canvas.drawCircle(p, 4, fill);
      fill.color = l.color.withValues(alpha: 0.95 * i);
      canvas.drawCircle(p, 1.8, fill);
    }

    for (final b in beams) {
      if (!b.alive) continue;
      final a = Offset(b.a.dx * sx, b.a.dy * sy);
      final c = Offset(b.b.dx * sx, b.b.dy * sy);
      final mid = Offset((a.dx + c.dx) / 2, (a.dy + c.dy) / 2);
      final d = (c - a).distance;
      // Control point lifted "up" (towards the top of the screen) — the
      // arc reads as a 3D hop over the globe.
      final ctrl = Offset(mid.dx, mid.dy - d * b.lift - 6);
      Offset at(double t) {
        final u = 1 - t;
        return Offset(
          u * u * a.dx + 2 * u * t * ctrl.dx + t * t * c.dx,
          u * u * a.dy + 2 * u * t * ctrl.dy + t * t * c.dy,
        );
      }

      final age = now - b.born;
      final travelT = (age / b.travel).clamp(0.0, 1.0);
      final head = Curves.easeInOutSine.transform(travelT);
      final after = ((age - b.travel) / _Beam.fade).clamp(0.0, 1.0); // 0..1 after arrival
      final life = 1 - after;

      // Faint dashed full path.
      stroke
        ..strokeWidth = 1
        ..color = b.color.withValues(alpha: 0.24 * life);
      for (var k = 0; k < 24; k += 2) {
        canvas.drawLine(at(k / 24), at((k + 1) / 24), stroke);
      }

      // Origin pulse.
      final pulse = (age / 0.8).clamp(0.0, 1.0);
      stroke
        ..strokeWidth = 1.2
        ..color = b.color.withValues(alpha: 0.5 * (1 - pulse));
      canvas.drawCircle(a, 2 + 7 * pulse, stroke);

      // Tail: from (head - length) to head; after arrival the tail end
      // catches up with the head so the trace disappears completely.
      final tailStart = math.max(0.0, head - _trailLength) + (head - math.max(0.0, head - _trailLength)) * after;
      for (var s = 0; s < _trailSegments; s++) {
        final t0 = tailStart + (head - tailStart) * s / _trailSegments;
        final t1 = tailStart + (head - tailStart) * (s + 1) / _trailSegments;
        final k = (s + 1) / _trailSegments; // 0 tail … 1 head
        stroke
          ..strokeWidth = 1.0 + 2.6 * k
          ..color = b.color.withValues(alpha: (0.06 + 0.9 * math.pow(k, 1.4).toDouble()) * life);
        canvas.drawLine(at(t0), at(t1), stroke);
      }

      // Bright head while travelling.
      if (after == 0) {
        final p = at(head);
        fill.color = b.color.withValues(alpha: 0.28);
        canvas.drawCircle(p, 6, fill);
        fill.color = b.color.withValues(alpha: 0.65);
        canvas.drawCircle(p, 3.8, fill);
        fill.color = Colors.white.withValues(alpha: 0.95);
        canvas.drawCircle(p, 1.9, fill);
      } else {
        // Arrival flash: an expanding ring + a fading core.
        stroke
          ..strokeWidth = 1.5
          ..color = b.color.withValues(alpha: 0.75 * life);
        canvas.drawCircle(c, 3 + 11 * after, stroke);
        fill.color = Colors.white.withValues(alpha: 0.85 * life * life);
        canvas.drawCircle(c, 2.4 * life + 0.6, fill);
      }
    }
  }

  @override
  bool shouldRepaint(_BeamPainter old) => false;
}
