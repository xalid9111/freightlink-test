import 'dart:math' as math;
import 'dart:ui' show FrameTiming;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'wheel_feed.dart';

/// Home "live world map".
///
/// * Background: a static night-lights world map (assets/images/
///   world_map.jpg) with its edges already faded into the page colour in
///   the image itself — no frame, no runtime gradient cost. Shown full
///   width, edge to edge.
/// * Overlay: a separate transparent layer with light beams. Each beam
///   leaves a city, rises in an arc and lands on another city: bright
///   head, fading tail, faint dashed path, a small flash on arrival. A
///   handful live at once, born and dying at random times.
///
/// Performance: one Ticker drives a ValueNotifier the painter listens to
/// (no widget rebuilds per frame); beams are plain objects recycled from
/// a small pool; no blur filters. It pauses while the feed scrolls, when
/// the map is scrolled out of view and when the tab is hidden (TickerMode).
/// If frames get slow it drops to ~30 fps and fewer beams.
class LiveMap extends StatefulWidget {
  const LiveMap({super.key});

  @override
  State<LiveMap> createState() => _LiveMapState();
}

/// Image size the hub positions were measured on.
const double _imgW = 1774, _imgH = 887;

/// Hubs (pixel position on the map image): spread over every continent
/// — no single centre.
const List<Offset> _hubs = [
  Offset(380, 300), // New York
  Offset(165, 330), // Los Angeles
  Offset(330, 285), // Chicago
  Offset(235, 395), // Mexico City
  Offset(330, 470), // Bogotá
  Offset(465, 600), // São Paulo
  Offset(400, 660), // Buenos Aires
  Offset(735, 255), // London
  Offset(780, 270), // Central Europe
  Offset(720, 312), // Madrid
  Offset(885, 232), // Moscow
  Offset(880, 322), // Istanbul
  Offset(905, 357), // Cairo
  Offset(745, 465), // Lagos
  Offset(960, 520), // Nairobi
  Offset(880, 632), // Johannesburg
  Offset(985, 318), // Baku
  Offset(1020, 388), // Dubai
  Offset(1010, 335), // Tehran
  Offset(1150, 300), // Almaty
  Offset(1130, 372), // Delhi
  Offset(1115, 420), // Mumbai
  Offset(1150, 222), // Novosibirsk
  Offset(1380, 300), // Beijing
  Offset(1402, 352), // Shanghai
  Offset(1500, 330), // Tokyo
  Offset(1362, 402), // Hong Kong
  Offset(1300, 510), // Singapore
  Offset(1332, 552), // Jakarta
  Offset(1580, 722), // Sydney
  Offset(1392, 690), // Perth
];

const _orange = Color(0xFFFF7A2E);
const _blue = Color(0xFF4AA8FF);

class _Beam {
  late Offset a, b; // in image pixels
  late double lift; // arc height factor
  late Color color;
  late double born; // seconds
  late double travel; // seconds from a to b
  bool alive = false;

  static const double fade = 0.9; // tail fade-out + flash after arrival

  double get end => born + travel + fade;
}

class _LiveMapState extends State<LiveMap> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final ValueNotifier<double> _time = ValueNotifier(0);
  final _rng = math.Random();
  late final List<_Beam> _pool = List.generate(9, (_) => _Beam());
  double _nextSpawn = 0.2;
  Duration _last = Duration.zero;

  // adaptive quality
  bool _lite = false;
  final List<double> _frameMs = [];
  bool _skipOdd = false;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
    WheelSignals.scrolling.addListener(_onScrolling);
    SchedulerBinding.instance.addTimingsCallback(_onTimings);
  }

  @override
  void dispose() {
    SchedulerBinding.instance.removeTimingsCallback(_onTimings);
    WheelSignals.scrolling.removeListener(_onScrolling);
    _ticker.dispose();
    _time.dispose();
    super.dispose();
  }

  /// Pause while the feed scrolls; resume only if the map is in view.
  void _onScrolling() {
    if (!mounted) return;
    if (WheelSignals.scrolling.value) {
      if (_ticker.isActive) _ticker.stop();
    } else if (WheelSignals.offset < 420 && !_ticker.isActive) {
      _last = Duration.zero;
      _ticker.start();
    }
  }

  void _onTimings(List<FrameTiming> timings) {
    for (final t in timings) {
      _frameMs.add((t.buildDuration + t.rasterDuration).inMicroseconds / 1000.0);
    }
    if (_frameMs.length < 30) return;
    final avg = _frameMs.reduce((a, b) => a + b) / _frameMs.length;
    _frameMs.clear();
    if (avg > 20) {
      _lite = true;
    } else if (avg < 9) {
      _lite = false;
    }
  }

  void _onTick(Duration elapsed) {
    // Ticker restarts from zero after a pause: keep our own clock.
    final dt = _last == Duration.zero ? 0.016 : (elapsed - _last).inMicroseconds / 1e6;
    _last = elapsed;
    if (_lite) {
      _skipOdd = !_skipOdd;
      if (_skipOdd) return; // ~30 fps on slow devices
    }
    final now = _time.value + dt.clamp(0, 0.1);
    for (final b in _pool) {
      if (b.alive && now > b.end) b.alive = false;
    }
    final maxAlive = _lite ? 4 : 7;
    if (now >= _nextSpawn && _pool.where((b) => b.alive).length < maxAlive) {
      _spawn(now);
      _nextSpawn = now + 0.35 + _rng.nextDouble() * 0.9;
    }
    _time.value = now;
  }

  void _spawn(double now) {
    final beam = _pool.firstWhere((b) => !b.alive, orElse: () => _pool.first);
    final i = _rng.nextInt(_hubs.length);
    var j = _rng.nextInt(_hubs.length);
    while (j == i || (_hubs[i] - _hubs[j]).distance < 140) {
      j = _rng.nextInt(_hubs.length);
    }
    final dist = (_hubs[i] - _hubs[j]).distance;
    beam
      ..a = _hubs[i]
      ..b = _hubs[j]
      ..lift = 0.32 + _rng.nextDouble() * 0.16
      ..color = _rng.nextBool() ? _orange : _blue
      ..born = now
      ..travel = (1.3 + dist / 520).clamp(1.4, 3.2)
      ..alive = true;
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 2 / 1,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Static background (edges faded into the page colour in the image).
          RepaintBoundary(
            child: Image.asset(
              'assets/images/world_map.jpg',
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
          // Animated transparent layer.
          RepaintBoundary(
            child: IgnorePointer(
              child: CustomPaint(painter: _BeamPainter(_time, _pool)),
            ),
          ),
        ],
      ),
    );
  }
}

class _BeamPainter extends CustomPainter {
  final ValueNotifier<double> time;
  final List<_Beam> beams;
  _BeamPainter(this.time, this.beams) : super(repaint: time);

  static const int _trailSegments = 14;
  static const double _trailLength = 0.45; // share of the path

  @override
  void paint(Canvas canvas, Size size) {
    final now = time.value;
    final sx = size.width / _imgW, sy = size.height / _imgH;
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final fill = Paint()..style = PaintingStyle.fill;

    for (final b in beams) {
      if (!b.alive) continue;
      final a = Offset(b.a.dx * sx, b.a.dy * sy);
      final c = Offset(b.b.dx * sx, b.b.dy * sy);
      final mid = Offset((a.dx + c.dx) / 2, (a.dy + c.dy) / 2);
      final d = (c - a).distance;
      // Control point lifted "up" (towards the top of the screen) — the
      // arc reads as a 3D hop over the globe.
      final ctrl = Offset(mid.dx, mid.dy - d * b.lift - 6);
      Offset at(double t) {
        final u = 1 - t;
        return Offset(
          u * u * a.dx + 2 * u * t * ctrl.dx + t * t * c.dx,
          u * u * a.dy + 2 * u * t * ctrl.dy + t * t * c.dy,
        );
      }

      final age = now - b.born;
      final travelT = (age / b.travel).clamp(0.0, 1.0);
      final head = Curves.easeInOutSine.transform(travelT);
      final after = ((age - b.travel) / _Beam.fade).clamp(0.0, 1.0); // 0..1 after arrival
      final life = 1 - after;

      // Faint dashed full path.
      stroke
        ..strokeWidth = 1
        ..color = b.color.withValues(alpha: 0.24 * life);
      for (var k = 0; k < 24; k += 2) {
        canvas.drawLine(at(k / 24), at((k + 1) / 24), stroke);
      }

      // Origin pulse.
      final pulse = (age / 0.8).clamp(0.0, 1.0);
      stroke
        ..strokeWidth = 1.2
        ..color = b.color.withValues(alpha: 0.5 * (1 - pulse));
      canvas.drawCircle(a, 2 + 7 * pulse, stroke);

      // Tail: from (head - length) to head; after arrival the tail end
      // catches up with the head so the trace disappears completely.
      final tailStart = math.max(0.0, head - _trailLength) + (head - math.max(0.0, head - _trailLength)) * after;
      for (var s = 0; s < _trailSegments; s++) {
        final t0 = tailStart + (head - tailStart) * s / _trailSegments;
        final t1 = tailStart + (head - tailStart) * (s + 1) / _trailSegments;
        final k = (s + 1) / _trailSegments; // 0 tail … 1 head
        stroke
          ..strokeWidth = 1.0 + 2.6 * k
          ..color = b.color.withValues(alpha: (0.06 + 0.9 * math.pow(k, 1.4).toDouble()) * life);
        canvas.drawLine(at(t0), at(t1), stroke);
      }

      // Bright head while travelling.
      if (after == 0) {
        final p = at(head);
        fill.color = b.color.withValues(alpha: 0.28);
        canvas.drawCircle(p, 6, fill);
        fill.color = b.color.withValues(alpha: 0.65);
        canvas.drawCircle(p, 3.8, fill);
        fill.color = Colors.white.withValues(alpha: 0.95);
        canvas.drawCircle(p, 1.9, fill);
      } else {
        // Arrival flash: an expanding ring + a fading core.
        stroke
          ..strokeWidth = 1.5
          ..color = b.color.withValues(alpha: 0.75 * life);
        canvas.drawCircle(c, 3 + 11 * after, stroke);
        fill.color = Colors.white.withValues(alpha: 0.85 * life * life);
        canvas.drawCircle(c, 2.4 * life + 0.6, fill);
      }
    }
  }

  @override
  bool shouldRepaint(_BeamPainter old) => false;
}
