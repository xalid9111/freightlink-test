import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';

/// The home screen's "live map": the night-lights world illustration
/// (assets/images/world_map.jpg) with an animated overlay showing a
/// DECENTRALIZED mesh of freight flows between many countries — no
/// single hub, every node drawn with the same weight, flows running
/// east→west, west→east and north→south. Purely decorative; the real
/// numbers are shown next to it (see CargoMarketplaceScreen).
///
/// Flows: TR→AZ, AZ→CN, CN→TR, RU→IR, IR→CN, DE→TR, PL→GE, GE→RU, CN→DE, TR→GE, US→GB, BR→ZA, IN→AE, KR→RU, SG→AU, KZ→PL, ES→EG, ID→IN.
///
/// All coordinates are in the image's own 1253×585 pixel space
/// and are scaled to whatever size the widget gets.
class LiveMap extends StatefulWidget {
  const LiveMap({super.key});

  @override
  State<LiveMap> createState() => _LiveMapState();
}

class _LiveMapState extends State<LiveMap> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    // One long loop drives every effect (each derives its own phase), so
    // there is a single ticker regardless of how many lights are drawn.
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: AspectRatio(
        aspectRatio: 1253 / 585,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/world_map.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const ColoredBox(color: AppColors.hero),
            ),
            RepaintBoundary(
              child: AnimatedBuilder(
                animation: _ctrl,
                builder: (context, _) => CustomPaint(painter: _MapOverlayPainter(_ctrl.value)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Route {
  final Offset from;
  final Offset control;
  final Offset to;
  final bool orange;
  const _Route(this.from, this.control, this.to, this.orange);
}

class _MapOverlayPainter extends CustomPainter {
  final double t; // 0..1 over the 12 s loop
  _MapOverlayPainter(this.t);

  static const double _w = 1253;
  static const double _h = 585;

  static const _routes = <_Route>[
    _Route(Offset(600, 185), Offset(643.2, 167.8), Offset(685, 188), true),
    _Route(Offset(685, 188), Offset(836.0, 141.9), Offset(972, 222), false),
    _Route(Offset(972, 222), Offset(794.1, 121.7), Offset(600, 185), true),
    _Route(Offset(918, 82), Offset(763.3, 104.0), Offset(675, 233), false),
    _Route(Offset(675, 233), Offset(821.1, 162.2), Offset(972, 222), true),
    _Route(Offset(425, 130), Offset(524.6, 119.0), Offset(600, 185), false),
    _Route(Offset(505, 170), Offset(580.4, 138.0), Offset(655, 172), true),
    _Route(Offset(655, 172), Offset(766.7, 69.1), Offset(918, 82), false),
    _Route(Offset(972, 222), Offset(718.7, 55.7), Offset(425, 130), true),
    _Route(Offset(600, 185), Offset(624.6, 166.4), Offset(655, 172), false),
    _Route(Offset(12, 192), Offset(156.4, 105.2), Offset(318, 153), true),
    _Route(Offset(222, 388), Offset(377.4, 380.5), Offset(488, 490), false),
    _Route(Offset(805, 275), Offset(750.8, 262.5), Offset(705, 294), true),
    _Route(Offset(1100, 262), Offset(1048.6, 132.0), Offset(918, 82), false),
    _Route(Offset(985, 385), Offset(1094.4, 412.6), Offset(1148, 512), true),
    _Route(Offset(782, 153), Offset(639.8, 100.6), Offset(505, 170), false),
    _Route(Offset(322, 218), Offset(424.9, 219.9), Offset(493, 297), true),
    _Route(Offset(1075, 420), Offset(971.9, 288.1), Offset(805, 275), false),
  ];

  /// Route endpoints — all drawn identically (no dominant country).
  static const _nodes = <Offset>[
    Offset(705, 294),
    Offset(1148, 512),
    Offset(685, 188),
    Offset(222, 388),
    Offset(972, 222),
    Offset(425, 130),
    Offset(493, 297),
    Offset(322, 218),
    Offset(318, 153),
    Offset(655, 172),
    Offset(1075, 420),
    Offset(805, 275),
    Offset(675, 233),
    Offset(1100, 262),
    Offset(782, 153),
    Offset(505, 170),
    Offset(918, 82),
    Offset(985, 385),
    Offset(600, 185),
    Offset(12, 192),
    Offset(488, 490),
  ];

  /// Phase in 0..1 of a cycle lasting [seconds], shifted by [offset] s.
  double _phase(double seconds, double offset) {
    final s = t * 12 + offset;
    return (s % seconds) / seconds;
  }

  Offset _bezier(Offset a, Offset c, Offset b, double u) {
    final v = 1 - u;
    return a * (v * v) + c * (2 * v * u) + b * (u * u);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final sx = size.width / _w;
    final sy = size.height / _h;
    final scale = (sx + sy) / 2;
    Offset p(Offset o) => Offset(o.dx * sx, o.dy * sy);

    // Comets: a short bright streak travelling from -> to on each route.
    for (var i = 0; i < _routes.length; i++) {
      final r = _routes[i];
      final u = _phase(3.6, i * 0.37);
      const tail = 0.12;
      const steps = 8;
      final path = Path();
      for (var k = 0; k <= steps; k++) {
        final uu = (u - tail + tail * k / steps).clamp(0.0, 1.0);
        final pt = p(_bezier(r.from, r.control, r.to, uu));
        if (k == 0) {
          path.moveTo(pt.dx, pt.dy);
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      final fade = u < 0.85 ? 1.0 : (1 - (u - 0.85) / 0.15);
      final color = r.orange ? const Color(0xFFFFE1CF) : const Color(0xFFCFE8FF);
      canvas.drawPath(
        path,
        Paint()
          ..color = color.withValues(alpha: 0.9 * fade)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4 * scale
          ..strokeCap = StrokeCap.round
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2.5 * scale),
      );
    }

    // Equal-weight nodes: an expanding ring + a softly blinking core.
    for (var i = 0; i < _nodes.length; i++) {
      final c = p(_nodes[i]);
      final ph = _phase(2.6, i * 0.41);
      final ring = i.isEven ? AppColors.accent : AppColors.blue;
      final core = i.isEven ? const Color(0xFFFFD3BF) : const Color(0xFFCFE8FF);
      canvas.drawCircle(c, 8 * scale * (0.5 + 2.2 * ph), Paint()..color = ring.withValues(alpha: 0.75 * (1 - ph)));
      final blink = 0.4 + 0.6 * (1 - (2 * ph - 1).abs());
      canvas.drawCircle(c, 5 * scale, Paint()..color = core.withValues(alpha: blink));
    }
  }

  @override
  bool shouldRepaint(_MapOverlayPainter old) => old.t != t;
}
