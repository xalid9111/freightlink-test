import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/carrier_repository_impl.dart';
import '../../domain/carrier_repository.dart';

final carrierRepositoryProvider = Provider<CarrierRepository>((ref) => CarrierRepositoryImpl());

/// Watched wherever a screen needs to know "is the signed-in user a
/// carrier, and what's their carrier row id" — e.g. deciding whether to
/// show the offer-submission form vs. the offers-received list on
/// cargo detail. Re-evaluates automatically when auth state changes
/// (depends indirectly via CarrierRepository reading the live session).
final myCarrierIdProvider = FutureProvider<String?>((ref) {
  return ref.watch(carrierRepositoryProvider).fetchMyCarrierId();
});
