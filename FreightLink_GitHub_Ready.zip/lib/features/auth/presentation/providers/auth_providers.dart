import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/auth_repository_impl.dart';
import '../../domain/app_user.dart';
import '../../domain/auth_repository.dart';

/// Single instance for the app's lifetime — repositories are cheap
/// wrappers around the (also-singleton) Supabase client, so a plain
/// Provider (not a family/factory) is correct here.
final authRepositoryProvider = Provider<AuthRepository>((ref) => AuthRepositoryImpl());

/// The stream every auth-aware widget/router should watch. `null` means
/// signed out. This is intentionally the ONLY place `authStateChanges()`
/// is subscribed to — Riverpod shares one subscription across every
/// listener, so screens/router don't each open their own stream.
final authStateProvider = StreamProvider<AppUser?>((ref) {
  return ref.watch(authRepositoryProvider).authStateChanges();
});

/// Convenience sync accessor for widgets that just need "who is logged
/// in right now" without handling AsyncValue's loading/error states
/// themselves (e.g. an AppBar greeting).
final currentUserProvider = Provider<AppUser?>((ref) {
  // .valueOrNull (not .asData?.value, which is older/possibly-deprecated
  // API in recent riverpod versions) — returns the last known value
  // during loading/error too, which is exactly "who is logged in right
  // now" semantics for a sync accessor like this.
  return ref.watch(authStateProvider).valueOrNull;
});
