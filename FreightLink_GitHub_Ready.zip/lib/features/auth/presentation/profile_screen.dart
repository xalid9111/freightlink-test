import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/localization/localization_service.dart';
import 'providers/auth_providers.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  String _roleLabel(AppStrings strings, String role) => switch (role) {
        AppConstants.roleCargoOwner => strings.t('role_label_cargo_owner'),
        AppConstants.roleCarrier => strings.t('role_label_carrier'),
        AppConstants.roleDriver => strings.t('role_label_driver'),
        AppConstants.roleAdmin => strings.t('role_label_admin'),
        _ => role,
      };

  // Shown next to each language option so a person can recognize their
  // language even before they've switched to it — this label is
  // deliberately NOT translated (it's each language's own native name).
  String _languageName(Locale l) => switch (l.languageCode) {
        'az' => 'Azərbaycanca',
        'tr' => 'Türkçe',
        'ru' => 'Русский',
        'en' => 'English',
        _ => l.languageCode,
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(authStateProvider);
    final strings = ref.watch(stringsProvider);
    final currentLocale = ref.watch(currentLocaleProvider);

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('profile_title'))),
      body: userAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text(strings.error(null))),
        data: (user) {
          if (user == null) {
            return Center(child: Text(strings.t('profile_not_logged_in')));
          }
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              CircleAvatar(
                radius: 36,
                child: Text(
                  user.fullName.isNotEmpty ? user.fullName[0].toUpperCase() : '?',
                  style: const TextStyle(fontSize: 28),
                ),
              ),
              const SizedBox(height: 16),
              Text(user.fullName, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
              Text(_roleLabel(strings, user.role), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 20),
              Card(
                child: Column(
                  children: [
                    ListTile(leading: const Icon(Icons.email_outlined), title: Text(user.email)),
                    if (user.phone != null)
                      ListTile(leading: const Icon(Icons.phone_outlined), title: Text(user.phone!)),
                    ListTile(
                      leading: Icon(
                        user.isVerified ? Icons.verified : Icons.hourglass_empty,
                        color: user.isVerified ? Colors.teal : Colors.orange,
                      ),
                      title: Text(user.isVerified ? strings.t('profile_verified') : strings.t('profile_unverified')),
                      subtitle: user.isVerified ? null : Text(strings.t('profile_unverified_note')),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(strings.t('profile_language_label'), style: Theme.of(context).textTheme.titleSmall),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: LocalizationService.supportedLocales.map((l) {
                          final selected = l.languageCode == currentLocale.languageCode;
                          return ChoiceChip(
                            label: Text(_languageName(l)),
                            selected: selected,
                            onSelected: (_) => ref.read(currentLocaleProvider.notifier).setLocale(l),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              OutlinedButton.icon(
                onPressed: () => ref.read(authRepositoryProvider).signOut(),
                icon: const Icon(Icons.logout),
                label: Text(strings.t('profile_signout')),
              ),
            ],
          );
        },
      ),
    );
  }
}
