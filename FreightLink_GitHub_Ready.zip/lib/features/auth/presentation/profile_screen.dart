import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/localization/localization_service.dart';
import '../../../core/feedback/wheel_feedback.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../repositories/profile_repository.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'providers/auth_providers.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  String _roleLabel(AppStrings strings, String role) => switch (role) {
        AppConstants.roleCargoOwner => strings.t('role_label_cargo_owner'),
        AppConstants.roleCarrier => strings.t('role_label_carrier'),
        AppConstants.roleDriver => strings.t('role_label_driver'),
        AppConstants.roleAdmin => strings.t('role_label_admin'),
        _ => role,
      };

  // Shown next to each language option so a person can recognize their
  // language even before they've switched to it — this label is
  // deliberately NOT translated (it's each language's own native name).
  String _languageName(Locale l) => switch (l.languageCode) {
        'az' => 'Azərbaycanca',
        'tr' => 'Türkçe',
        'ru' => 'Русский',
        'en' => 'English',
        _ => l.languageCode,
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(authStateProvider);
    final strings = ref.watch(stringsProvider);
    final currentLocale = ref.watch(currentLocaleProvider);

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('profile_title'))),
      body: userAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text(strings.error(null))),
        data: (user) {
          if (user == null) {
            return Center(child: Text(strings.t('profile_not_logged_in')));
          }
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _ProfileHeader(userId: user.id, fallbackName: user.fullName, strings: strings),
              Text(_roleLabel(strings, user.role), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 20),
              Card(
                child: Column(
                  children: [
                    ListTile(leading: const Icon(Icons.email_outlined), title: Text(user.email)),
                    _PhoneTile(userId: user.id, fallbackPhone: user.phone, strings: strings),
                    ListTile(
                      leading: Icon(
                        user.isVerified ? Icons.verified : Icons.hourglass_empty,
                        color: user.isVerified ? Colors.teal : Colors.orange,
                      ),
                      title: Text(user.isVerified ? strings.t('profile_verified') : strings.t('profile_unverified')),
                      subtitle: user.isVerified ? null : Text(strings.t('profile_unverified_note')),
                    ),
                  ],
                ),
              ),
              if (user.role == AppConstants.roleAdmin) ...[
                const SizedBox(height: 20),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.admin_panel_settings_outlined, color: AppColors.accent),
                    title: Text(strings.t('admin_panel_title')),
                    subtitle: Text(strings.t('admin_panel_subtitle')),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.go('/admin'),
                  ),
                ),
              ],
              // Feed wheel feedback (Open Loads): tick sound + haptic.
              const SizedBox(height: 20),
              Consumer(builder: (context, ref, _) {
                final w = ref.watch(wheelSettingsProvider);
                final c = ref.read(wheelSettingsProvider.notifier);
                return Card(
                  child: Column(
                    children: [
                      SwitchListTile(
                        secondary: const Icon(Icons.volume_up_outlined),
                        title: Text(strings.t('settings_wheel_sound')),
                        subtitle: Text(strings.t('settings_wheel_sound_note')),
                        value: w.sound,
                        onChanged: c.setSound,
                      ),
                      SwitchListTile(
                        secondary: const Icon(Icons.vibration),
                        title: Text(strings.t('settings_wheel_haptic')),
                        subtitle: Text(strings.t('settings_wheel_haptic_note')),
                        value: w.haptic,
                        onChanged: c.setHaptic,
                      ),
                    ],
                  ),
                );
              }),
              // Advertising — for every role (cargo owners and carriers alike).
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.campaign_outlined, color: AppColors.accent),
                  title: Text(strings.t('ad_profile_button')),
                  subtitle: Text(strings.t('ad_profile_subtitle')),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => context.push('/ads'),
                ),
              ),
              ...[ // My loads — every role can post loads
                const SizedBox(height: 20),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.inventory_2_outlined, color: AppColors.accent),
                    title: Text(strings.t('my_cargo_title')),
                    subtitle: Text(strings.t('my_cargo_subtitle')),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.push('/my-cargo'),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(strings.t('profile_language_label'), style: Theme.of(context).textTheme.titleSmall),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: LocalizationService.supportedLocales.map((l) {
                          final selected = l.languageCode == currentLocale.languageCode;
                          return ChoiceChip(
                            label: Text(_languageName(l)),
                            selected: selected,
                            onSelected: (_) => ref.read(currentLocaleProvider.notifier).setLocale(l),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              OutlinedButton.icon(
                onPressed: () => ref.read(authRepositoryProvider).signOut(),
                icon: const Icon(Icons.logout),
                label: Text(strings.t('profile_signout')),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Photo (tap to change), name with verified tick, early-member badge.
class _ProfileHeader extends ConsumerStatefulWidget {
  final String userId;
  final String fallbackName;
  final AppStrings strings;
  const _ProfileHeader({required this.userId, required this.fallbackName, required this.strings});

  @override
  ConsumerState<_ProfileHeader> createState() => _ProfileHeaderState();
}

class _ProfileHeaderState extends ConsumerState<_ProfileHeader> {
  bool _uploading = false;

  Future<void> _changePhoto() async {
    final strings = widget.strings;
    try {
      final file = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 85,
      );
      if (file == null) return;
      setState(() => _uploading = true);
      final bytes = await file.readAsBytes();
      await ref.read(profileRepositoryProvider).uploadAvatar(bytes, contentType: file.mimeType);
      ref.invalidate(publicProfileProvider(widget.userId));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(strings.t('profile_photo_error'))));
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  /// Change the display name (company or person) others see.
  Future<void> _editName(String current) async {
    final strings = widget.strings;
    final ctrl = TextEditingController(text: current);
    final newName = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(strings.t('profile_name_edit')),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLength: 80,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(labelText: strings.t('profile_name_label')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text(strings.t('common_cancel'))),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(ctrl.text), child: Text(strings.t('profile_phone_save'))),
        ],
      ),
    );
    if (newName == null || newName.trim().length < 2 || newName.trim() == current) return;
    try {
      await ref.read(profileRepositoryProvider).updateName(newName);
      ref.invalidate(publicProfileProvider(widget.userId));
      ref.invalidate(authStateProvider);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(strings.t('profile_name_saved'))));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(strings.t('error_generic'))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = widget.strings;
    final profile = ref.watch(publicProfileProvider(widget.userId)).valueOrNull;
    final name = (profile?.fullName.isNotEmpty ?? false) ? profile!.fullName : widget.fallbackName;
    final initials = profile?.initials ?? (name.isNotEmpty ? name[0].toUpperCase() : '?');

    return Column(
      children: [
        Center(
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: _uploading ? null : _changePhoto,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                UserAvatar(imageUrl: profile?.avatarUrl, initials: initials, radius: 44),
                Positioned(
                  right: -2,
                  bottom: -2,
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: AppColors.accentFill,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.background, width: 2),
                    ),
                    child: _uploading
                        ? const Padding(
                            padding: EdgeInsets.all(7),
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.photo_camera, size: 16, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        TextButton(
          onPressed: _uploading ? null : _changePhoto,
          child: Text(strings.t('profile_change_photo')),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              child: Text(name, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
            ),
            if (profile?.isVerified == true) ...[
              const SizedBox(width: 6),
              const VerifiedTick(size: 20),
            ],
            IconButton(
              tooltip: strings.t('profile_name_edit'),
              onPressed: () => _editName(name),
              icon: const Icon(Icons.edit_outlined, size: 20, color: AppColors.accent),
            ),
          ],
        ),
        if (profile?.isEarlyMember == true) ...[
          const SizedBox(height: 6),
          Center(child: EarlyMemberChip(label: strings.t('badge_early_member'))),
        ],
        const SizedBox(height: 4),
      ],
    );
  }
}

/// Phone number row with "add / change". Other users call this number
/// (phone or WhatsApp) from chat and cargo screens.
class _PhoneTile extends ConsumerWidget {
  final String userId;
  final String? fallbackPhone;
  final AppStrings strings;
  const _PhoneTile({required this.userId, required this.fallbackPhone, required this.strings});

  Future<void> _edit(BuildContext context, WidgetRef ref) async {
    String? phone;
    bool valid = false;
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        String? error;
        bool saving = false;
        return StatefulBuilder(
          builder: (ctx, setLocal) => AlertDialog(
            title: Text(strings.t('profile_phone_title')),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(strings.t('profile_phone_hint'), style: const TextStyle(color: AppColors.textSoft, fontSize: 13)),
                const SizedBox(height: 12),
                IntlPhoneField(
                  initialCountryCode: 'AZ',
                  decoration: InputDecoration(labelText: strings.t('profile_phone_label')),
                  onChanged: (p) {
                    phone = p.completeNumber;
                    try {
                      valid = p.isValidNumber();
                    } catch (_) {
                      valid = false;
                    }
                  },
                ),
                if (error != null)
                  Text(error!, style: const TextStyle(color: AppColors.danger, fontSize: 13)),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: Text(strings.t('common_cancel'))),
              FilledButton(
                onPressed: saving
                    ? null
                    : () async {
                        if (phone == null || !valid) {
                          setLocal(() => error = strings.t('profile_phone_invalid'));
                          return;
                        }
                        setLocal(() {
                          saving = true;
                          error = null;
                        });
                        try {
                          await ref.read(profileRepositoryProvider).updatePhone(phone!);
                          if (ctx.mounted) Navigator.of(ctx).pop(true);
                        } on PhoneTakenException {
                          setLocal(() {
                            saving = false;
                            error = strings.t('profile_phone_taken');
                          });
                        } catch (_) {
                          setLocal(() {
                            saving = false;
                            error = strings.t('error_generic');
                          });
                        }
                      },
                child: Text(strings.t('profile_phone_save')),
              ),
            ],
          ),
        );
      },
    );
    if (saved == true) ref.invalidate(publicProfileProvider(userId));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(publicProfileProvider(userId)).valueOrNull;
    final phone = profile?.phone ?? fallbackPhone;
    final has = phone != null && phone.isNotEmpty;
    return ListTile(
      leading: const Icon(Icons.phone_outlined),
      title: Text(has ? phone : strings.t('profile_phone_missing'),
          style: TextStyle(color: has ? AppColors.text : AppColors.accent)),
      subtitle: has ? null : Text(strings.t('profile_phone_missing_note')),
      trailing: TextButton(
        onPressed: () => _edit(context, ref),
        child: Text(strings.t(has ? 'profile_phone_change' : 'profile_phone_add')),
      ),
    );
  }
}
