import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/constants/countries.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/ad_models.dart';
import '../data/ads_repository.dart';
import 'ad_creative_view.dart';
import 'ads_providers.dart';
import 'advertise_screen.dart' show adMoney, adSectionHeader;

/// "Reklam yarat": template → texts → colour → destination → targeting →
/// 5 / 15 / 30 days → start date → total → confirm. No image upload.
class AdCreateScreen extends ConsumerStatefulWidget {
  const AdCreateScreen({super.key});

  @override
  ConsumerState<AdCreateScreen> createState() => _AdCreateScreenState();
}

class _AdCreateScreenState extends ConsumerState<AdCreateScreen> {
  AdTemplate? _tpl;
  final Map<String, TextEditingController> _texts = {};
  String? _color;
  String _destination = 'profile';
  final _url = TextEditingController();
  final _routeFrom = TextEditingController();
  final _routeTo = TextEditingController();
  final _note = TextEditingController();
  final Set<String> _countries = {};
  int? _days;
  DateTime? _start;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in _texts.values) {
      c.dispose();
    }
    _url.dispose();
    _routeFrom.dispose();
    _routeTo.dispose();
    _note.dispose();
    super.dispose();
  }

  void _pickTemplate(AdTemplate t) {
    if (_tpl?.id == t.id) return;
    // Keep what was typed in fields that exist in the new template too.
    final old = {for (final e in _texts.entries) e.key: e.value.text};
    final olds = _texts.values.toList();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final c in olds) {
        c.dispose();
      }
    });
    _texts.clear();
    for (final f in t.fields) {
      _texts[f.key] = TextEditingController(text: old[f.key] ?? f.defaultText)..addListener(() => setState(() {}));
    }
    setState(() {
      _tpl = t;
      _color = t.colors.isEmpty ? '#FFFFFF' : t.colors.first;
    });
  }

  Map<String, String> get _textValues => {for (final e in _texts.entries) e.key: e.value.text.trim()};

  /// Active, priced package for each allowed duration.
  Map<int, AdPackage> _durations(List<AdPackage> packages) {
    final out = <int, AdPackage>{};
    final sorted = [...packages]..sort((a, b) => a.sort.compareTo(b.sort));
    for (final p in sorted) {
      if (const [5, 15, 30].contains(p.days) && p.isActive && p.price > 0) out.putIfAbsent(p.days, () => p);
    }
    return out;
  }

  Future<void> _pickStart() async {
    final today = DateUtils.dateOnly(DateTime.now());
    final d = await showDatePicker(
      context: context,
      initialDate: _start ?? today,
      firstDate: today,
      lastDate: today.add(const Duration(days: 90)),
    );
    if (d != null) setState(() => _start = d);
  }

  String? _validate(AppStrings s, Map<int, AdPackage> durations) {
    final t = _tpl;
    if (t == null) return s.t('adv_err_template');
    if (_textValues.values.every((v) => v.isEmpty)) return s.t('adv_err_text');
    for (final f in t.fields) {
      if ((_textValues[f.key] ?? '').length > f.max) return s.t('adv_err_text_long', {'field': f.label, 'n': '${f.max}'});
    }
    if (_destination == 'external') {
      final uri = Uri.tryParse(_url.text.trim());
      if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) return s.t('ad_external_url_invalid');
    }
    if (_days == null || !durations.containsKey(_days)) return s.t('adv_err_duration');
    if (_start == null) return s.t('adv_err_start');
    return null;
  }

  Future<void> _submit(AppStrings s, Map<int, AdPackage> durations, String lang) async {
    final err = _validate(s, durations);
    if (err != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
      return;
    }
    final pkg = durations[_days]!;
    final fmt = DateFormat('d MMM yyyy', lang);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('adv_confirm_title')),
        content: Text(s.t('adv_confirm_body', {
          'amount': adMoney(pkg.price, pkg.currency),
          'days': '${pkg.days}',
          'start': fmt.format(_start!),
        })),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('common_cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('adv_confirm_ok'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      final order = await ref.read(adsRepositoryProvider).createOrderFromTemplate(
            templateId: _tpl!.id,
            texts: _textValues,
            color: _color!,
            days: pkg.days,
            startsOn: _start!,
            destinationType: _destination,
            destinationUrl: _destination == 'external' ? _url.text.trim() : null,
            targetCountries: _countries.toList(),
            routeFrom: _routeFrom.text.trim(),
            routeTo: _routeTo.text.trim(),
            note: _note.text.trim(),
          );
      ref.invalidate(myAdOrdersProvider);
      if (mounted) context.pushReplacement('/ad-order/${order.id}');
    } catch (e) {
      if (!mounted) return;
      final raw = e.toString();
      final key = [
        'package_not_found',
        'template_not_found',
        'invalid_start_date',
        'invalid_external_url',
        'text_too_long',
        'text_required',
        'account_blocked',
      ].firstWhere(raw.contains, orElse: () => '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(key.isEmpty ? s.t('ad_action_failed') : s.t('adv_err_$key'))),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(stringsProvider);
    final lang = ref.watch(currentLocaleProvider).languageCode;
    final templates = ref.watch(adTemplatesProvider);
    final durations = _durations(ref.watch(adPackagesProvider).valueOrNull ?? const []);
    final fmt = DateFormat('d MMM yyyy', lang);
    final pkg = _days == null ? null : durations[_days];

    Widget section(int n, String key) => Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 8),
          child: Text('$n. ${s.t(key)}'.toUpperCase(), style: adSectionHeader),
        );

    return Scaffold(
      appBar: AppBar(title: Text(s.t('adv_create'))),
      body: templates.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(s.t('home_error_loading'))),
        data: (list) {
          if (list.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(s.t('adv_no_templates'), textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSoft)),
              ),
            );
          }
          if (_tpl == null) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted && _tpl == null) _pickTemplate(list.first);
            });
          }
          final t = _tpl;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
            children: [
              // Live preview — exactly what will appear on the home page.
              if (t != null) ...[
                Text(s.t('adv_preview').toUpperCase(), style: adSectionHeader),
                const SizedBox(height: 8),
                AdCreativeView(
                  creative: AdCreative(imageUrl: t.imageUrl, fields: t.fields, texts: _textValues, color: _color ?? '#FFFFFF'),
                  radius: BorderRadius.circular(14),
                  showPlaceholders: true,
                ),
              ],
              section(1, 'adv_step_template'),
              SizedBox(
                height: 92,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, i) {
                    final x = list[i];
                    final sel = x.id == t?.id;
                    return GestureDetector(
                      onTap: () => _pickTemplate(x),
                      child: Container(
                        width: 220,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: sel ? AppColors.accent : AppColors.line, width: sel ? 2 : 1),
                        ),
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            AdCreativeView(creative: x.preview(), radius: BorderRadius.circular(8)),
                            const SizedBox(height: 4),
                            Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              if (t != null) ...[
                section(2, 'adv_step_text'),
                for (final f in t.fields)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: TextField(
                      controller: _texts[f.key],
                      maxLength: f.max,
                      decoration: InputDecoration(labelText: f.label),
                    ),
                  ),
                section(3, 'adv_step_color'),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final c in t.colors)
                      GestureDetector(
                        onTap: () => setState(() => _color = c),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Color(adColorValue(c)),
                            shape: BoxShape.circle,
                            border: Border.all(color: _color == c ? AppColors.accent : AppColors.line, width: _color == c ? 3 : 1),
                          ),
                          child: _color == c ? const Icon(Icons.check, size: 18, color: Colors.black54) : null,
                        ),
                      ),
                  ],
                ),
              ],
              section(4, 'ad_destination'),
              SegmentedButton<String>(
                segments: [
                  ButtonSegment(value: 'profile', label: Text(s.t('ad_destination_profile')), icon: const Icon(Icons.person_outline)),
                  ButtonSegment(value: 'external', label: Text(s.t('ad_destination_external')), icon: const Icon(Icons.open_in_new)),
                ],
                selected: {_destination},
                onSelectionChanged: (v) => setState(() => _destination = v.first),
              ),
              if (_destination == 'external') ...[
                const SizedBox(height: 8),
                TextField(
                  controller: _url,
                  keyboardType: TextInputType.url,
                  decoration: InputDecoration(labelText: s.t('ad_external_url'), hintText: 'https://example.com'),
                ),
              ],
              section(5, 'ad_targeting'),
              Text(s.t('ad_target_countries'), style: const TextStyle(color: AppColors.textSoft, fontSize: 13)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final c in Countries.all)
                    FilterChip(
                      visualDensity: VisualDensity.compact,
                      label: Text('${c.flag} ${c.name(lang)}', style: const TextStyle(fontSize: 12.5)),
                      selected: _countries.contains(c.code),
                      onSelected: (v) => setState(() => v ? _countries.add(c.code) : _countries.remove(c.code)),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: TextField(controller: _routeFrom, decoration: InputDecoration(labelText: s.t('ad_route_from')))),
                  const SizedBox(width: 10),
                  Expanded(child: TextField(controller: _routeTo, decoration: InputDecoration(labelText: s.t('ad_route_to')))),
                ],
              ),
              section(6, 'adv_step_duration'),
              if (durations.isEmpty)
                Text(s.t('adv_no_prices'), style: const TextStyle(color: AppColors.textSoft))
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final d in const [5, 15, 30])
                      ChoiceChip(
                        label: Text(durations[d] == null
                            ? s.t('ad_days', {'n': '$d'})
                            : '${s.t('ad_days', {'n': '$d'})} · ${adMoney(durations[d]!.price, durations[d]!.currency)}'),
                        selected: _days == d,
                        onSelected: durations[d] == null ? null : (_) => setState(() => _days = d),
                      ),
                  ],
                ),
              section(7, 'adv_step_start'),
              OutlinedButton.icon(
                onPressed: _pickStart,
                icon: const Icon(Icons.event),
                label: Text(_start == null ? s.t('adv_pick_start') : fmt.format(_start!)),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _note,
                maxLines: 2,
                decoration: InputDecoration(labelText: s.t('ad_note_label')),
              ),
            ],
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          decoration: const BoxDecoration(color: AppColors.hero, border: Border(top: BorderSide(color: AppColors.line))),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.t('adv_total'), style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
                    Text(
                      (pkg != null && _start != null) ? adMoney(pkg.price, pkg.currency) : '—',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    if (pkg != null && _start != null)
                      Text(
                        '${fmt.format(_start!)} – ${fmt.format(_start!.add(Duration(days: pkg.days)))}',
                        style: const TextStyle(fontSize: 11.5, color: AppColors.textSoft),
                      ),
                  ],
                ),
              ),
              FilledButton(
                onPressed: _busy ? null : () => _submit(s, durations, lang),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14)),
                child: _busy
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(s.t('adv_confirm_ok')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
