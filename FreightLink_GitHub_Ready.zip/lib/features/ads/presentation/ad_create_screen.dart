import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../core/constants/countries.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/ad_models.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../data/ads_repository.dart';
import 'ad_creative_view.dart';
import 'ads_providers.dart';
import 'advertise_screen.dart' show adMoney, adSectionHeader;

/// "Reklam yarat" (and "Redaktə et" for an own order): pick a background →
/// company / activity / phone → logo → font, size, colour per line → (new
/// orders) destination, targeting, 5/15/30 days, start date → confirm.
/// Positions are fixed by the standard 1200×400 layout.
class AdCreateScreen extends ConsumerStatefulWidget {
  final String? initialTemplateId;
  /// Edit an existing own order instead of creating a new one.
  final String? editOrderId;
  const AdCreateScreen({super.key, this.initialTemplateId, this.editOrderId});

  @override
  ConsumerState<AdCreateScreen> createState() => _AdCreateScreenState();
}

const _lineKeys = ['company', 'activity', 'phone'];

class _AdCreateScreenState extends ConsumerState<AdCreateScreen> {
  AdTemplate? _tpl;
  final _company = TextEditingController();
  final _activity = TextEditingController();
  final _phone = TextEditingController();
  final Map<String, AdTextStyle> _style = {for (final k in _lineKeys) k: AdTextStyle.defaults(k)};
  String _styleLine = 'company';
  String? _logoUrl;
  String _logoBg = 'dark';
  bool _logoUploading = false;

  String _destination = 'profile';
  final _url = TextEditingController();
  final _routeFrom = TextEditingController();
  final _routeTo = TextEditingController();
  final _note = TextEditingController();
  final Set<String> _countries = {};
  int? _days;
  DateTime? _start;
  bool _busy = false;
  bool _loadedOrder = false;

  bool get _editing => widget.editOrderId != null;

  @override
  void initState() {
    super.initState();
    for (final c in [_company, _activity, _phone]) {
      c.addListener(() => setState(() {}));
    }
  }

  @override
  void dispose() {
    for (final c in [_company, _activity, _phone, _url, _routeFrom, _routeTo, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  Map<String, String> get _texts => {
        'company': _company.text.trim(),
        'activity': _activity.text.trim(),
        'phone': _phone.text.trim(),
      };

  void _loadOrder(AdOrder o, List<AdTemplate> list) {
    final c = o.creative;
    if (c != null && c.isStandard) {
      _company.text = c.texts['company'] ?? '';
      _activity.text = c.texts['activity'] ?? '';
      _phone.text = c.texts['phone'] ?? '';
      for (final k in _lineKeys) {
        _style[k] = c.styleOf(k);
      }
      _logoUrl = c.logoUrl;
      _logoBg = c.logoBg;
    }
    for (final t in list) {
      if (t.id == o.templateId) _tpl = t;
    }
    _tpl ??= list.first;
  }

  Future<void> _pickLogo(AppStrings s) async {
    final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1000, maxHeight: 1000);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    final name = f.name.toLowerCase();
    final ext = name.endsWith('.png') ? 'png' : (name.endsWith('.webp') ? 'webp' : (name.endsWith('.jpg') || name.endsWith('.jpeg') ? 'jpg' : ''));
    if (ext.isEmpty) {
      _toast(s.t('adv_logo_type'));
      return;
    }
    if (bytes.length > 2 * 1024 * 1024) {
      _toast(s.t('adv_logo_size'));
      return;
    }
    // Must really be an image (not just a renamed file).
    try {
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      frame.image.dispose();
    } catch (_) {
      _toast(s.t('adv_logo_type'));
      return;
    }
    final uid = ref.read(currentUserIdProvider);
    if (uid == null || !mounted) return;
    setState(() => _logoUploading = true);
    try {
      final url = await ref.read(adsRepositoryProvider).uploadLogo(bytes, ext, uid);
      if (mounted) setState(() => _logoUrl = url);
    } catch (_) {
      _toast(s.t('adv_logo_failed'));
    } finally {
      if (mounted) setState(() => _logoUploading = false);
    }
  }

  void _toast(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  Map<int, AdPackage> _durations(List<AdPackage> packages) {
    final out = <int, AdPackage>{};
    final sorted = [...packages]..sort((a, b) => a.sort.compareTo(b.sort));
    for (final p in sorted) {
      if (const [5, 15, 30].contains(p.days) && p.isActive && p.price > 0) out.putIfAbsent(p.days, () => p);
    }
    return out;
  }

  Future<void> _pickStart() async {
    final today = DateUtils.dateOnly(DateTime.now());
    final d = await showDatePicker(
      context: context,
      initialDate: _start ?? today,
      firstDate: today,
      lastDate: today.add(const Duration(days: 90)),
    );
    if (d != null) setState(() => _start = d);
  }

  String? _validate(AppStrings s, Map<int, AdPackage> durations) {
    if (_tpl == null) return s.t('adv_err_template');
    if (_company.text.trim().isEmpty) return s.t('adv_err_company');
    final phone = _phone.text.trim();
    if (phone.isNotEmpty && !RegExp(r'^[+0-9 ()\-]{5,25}$').hasMatch(phone)) return s.t('adv_err_invalid_phone');
    if (_editing) return null;
    if (_destination == 'external') {
      final uri = Uri.tryParse(_url.text.trim());
      if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) return s.t('ad_external_url_invalid');
    }
    if (_days == null || !durations.containsKey(_days)) return s.t('adv_err_duration');
    if (_start == null) return s.t('adv_err_start');
    return null;
  }

  String _errKey(Object e) {
    final raw = e.toString();
    return [
      'package_not_found',
      'template_not_found',
      'invalid_start_date',
      'invalid_external_url',
      'text_too_long',
      'text_required',
      'account_blocked',
      'invalid_logo',
      'invalid_phone',
      'ordering_disabled',
      'order_locked',
    ].firstWhere(raw.contains, orElse: () => '');
  }

  Future<void> _submit(AppStrings s, Map<int, AdPackage> durations, String lang) async {
    final err = _validate(s, durations);
    if (err != null) {
      _toast(err);
      return;
    }
    final repo = ref.read(adsRepositoryProvider);
    if (_editing) {
      setState(() => _busy = true);
      try {
        final o = await repo.updateOrderV2(
          orderId: widget.editOrderId!,
          templateId: _tpl!.id,
          texts: _texts,
          style: _style,
          logoUrl: _logoUrl,
          logoBg: _logoBg,
        );
        if (!mounted) return;
        ref.invalidate(myAdOrdersProvider);
        _toast(s.t(o.receiptPath != null ? 'adv_saved_review' : 'adv_saved'));
        if (mounted) context.pop();
      } catch (e) {
        final k = _errKey(e);
        _toast(k.isEmpty ? s.t('ad_action_failed') : s.t('adv_err_$k'));
      } finally {
        if (mounted) setState(() => _busy = false);
      }
      return;
    }
    final pkg = durations[_days]!;
    final fmt = DateFormat('d MMM yyyy', lang);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('adv_confirm_title')),
        content: Text(s.t('adv_confirm_body', {
          'amount': adMoney(pkg.price, pkg.currency),
          'days': '${pkg.days}',
          'start': fmt.format(_start!),
        })),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('common_cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('adv_confirm_ok'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      final order = await repo.createOrderV2(
        templateId: _tpl!.id,
        texts: _texts,
        style: _style,
        logoUrl: _logoUrl,
        logoBg: _logoBg,
        days: pkg.days,
        startsOn: _start!,
        destinationType: _destination,
        destinationUrl: _destination == 'external' ? _url.text.trim() : null,
        targetCountries: _countries.toList(),
        routeFrom: _routeFrom.text.trim(),
        routeTo: _routeTo.text.trim(),
        note: _note.text.trim(),
      );
      if (!mounted) return;
      ref.invalidate(myAdOrdersProvider);
      if (mounted) context.pushReplacement('/ad-order/${order.id}');
    } catch (e) {
      final k = _errKey(e);
      _toast(k.isEmpty ? s.t('ad_action_failed') : s.t('adv_err_$k'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(stringsProvider);
    final lang = ref.watch(currentLocaleProvider).languageCode;
    final templates = ref.watch(adTemplatesProvider);
    final durations = _durations(ref.watch(adPackagesProvider).valueOrNull ?? const []);
    final fmt = DateFormat('d MMM yyyy', lang);
    final pkg = _days == null ? null : durations[_days];
    final editOrder = _editing ? ref.watch(myAdOrderProvider(widget.editOrderId!)).valueOrNull : null;

    Widget section(int n, String key) => Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 8),
          child: Text('$n. ${s.t(key)}'.toUpperCase(), style: adSectionHeader),
        );

    return Scaffold(
      appBar: AppBar(title: Text(s.t(_editing ? 'adv_edit_title' : 'adv_create'))),
      body: templates.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(s.t('home_error_loading'))),
        data: (list) {
          if (list.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(s.t('adv_no_templates'), textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSoft)),
              ),
            );
          }
          if (_editing && !_loadedOrder && editOrder != null) {
            _loadedOrder = true;
            // Filling the text fields notifies listeners → do it after this frame.
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) setState(() => _loadOrder(editOrder, list));
            });
          } else if (!_editing && _tpl == null) {
            AdTemplate first = list.first;
            for (final x in list) {
              if (x.id == widget.initialTemplateId) first = x;
            }
            _tpl = first;
          }
          final t = _tpl;
          if (t == null) {
            final orders = _editing ? ref.watch(myAdOrdersProvider) : null;
            if (orders != null && orders.hasValue && editOrder == null) {
              return Center(child: Text(s.t('adv_order_missing')));
            }
            return const Center(child: CircularProgressIndicator());
          }
          final preview = AdCreative(
            version: 2,
            imageUrl: t.imageUrl,
            texts: _texts,
            style: Map.of(_style),
            logoUrl: _logoUrl,
            logoBg: _logoBg,
          );
          final st = _style[_styleLine]!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
            children: [
              Text(s.t('adv_preview').toUpperCase(), style: adSectionHeader),
              const SizedBox(height: 8),
              AdCreativeView(creative: preview, radius: BorderRadius.circular(14), showPlaceholders: true),
              if (_editing && editOrder?.receiptPath != null) ...[
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: AppColors.blue.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
                  child: Text(s.t('adv_edit_review_note'), style: const TextStyle(color: AppColors.blue, fontSize: 12.5)),
                ),
              ],
              section(1, 'adv_step_background'),
              SizedBox(
                height: 104,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, i) {
                    final x = list[i];
                    final sel = x.id == t.id;
                    return GestureDetector(
                      onTap: () => setState(() => _tpl = x),
                      child: Container(
                        width: 220,
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: sel ? AppColors.accent : AppColors.line, width: sel ? 2 : 1),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            AdCreativeView(creative: x.sample(), radius: BorderRadius.circular(8)),
                            const SizedBox(height: 4),
                            Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              section(2, 'adv_step_texts'),
              TextField(
                controller: _company,
                maxLength: AdStandardLayout.maxLen['company'],
                textCapitalization: TextCapitalization.characters,
                decoration: InputDecoration(labelText: s.t('adv_company'), hintText: 'DELTA-GEO'),
              ),
              TextField(
                controller: _activity,
                maxLength: AdStandardLayout.maxLen['activity'],
                decoration: InputDecoration(labelText: s.t('adv_activity'), hintText: 'Logistics'),
              ),
              TextField(
                controller: _phone,
                maxLength: AdStandardLayout.maxLen['phone'],
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(labelText: s.t('adv_phone'), hintText: '+994 00 000 00 00', prefixIcon: const Icon(Icons.phone_in_talk, size: 18)),
              ),
              section(3, 'adv_step_logo'),
              Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: _logoUploading ? null : () => _pickLogo(s),
                    icon: _logoUploading
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.add_photo_alternate_outlined),
                    label: Text(s.t(_logoUrl == null ? 'adv_logo_add' : 'adv_logo_change')),
                  ),
                  if (_logoUrl != null)
                    TextButton(onPressed: () => setState(() => _logoUrl = null), child: Text(s.t('adv_logo_remove'))),
                ],
              ),
              const SizedBox(height: 4),
              Text(s.t('adv_logo_rules'), style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: [
                  ButtonSegment(value: 'dark', label: Text(s.t('adv_logo_bg_dark'))),
                  ButtonSegment(value: 'light', label: Text(s.t('adv_logo_bg_light'))),
                  ButtonSegment(value: 'none', label: Text(s.t('adv_logo_bg_none'))),
                ],
                selected: {_logoBg},
                onSelectionChanged: (v) => setState(() => _logoBg = v.first),
              ),
              section(4, 'adv_step_style'),
              SegmentedButton<String>(
                segments: [
                  ButtonSegment(value: 'company', label: Text(s.t('adv_company_short'))),
                  ButtonSegment(value: 'activity', label: Text(s.t('adv_activity_short'))),
                  ButtonSegment(value: 'phone', label: Text(s.t('adv_phone'))),
                ],
                selected: {_styleLine},
                onSelectionChanged: (v) => setState(() => _styleLine = v.first),
              ),
              const SizedBox(height: 10),
              Text(s.t('adv_font'), style: const TextStyle(fontSize: 12.5, color: AppColors.textSoft)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final f in AdStandardLayout.fonts)
                    ChoiceChip(
                      label: Text('Əa Şş', style: adFontStyle(f, const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
                      tooltip: f,
                      selected: st.font == f,
                      onSelected: (_) => setState(() => _style[_styleLine] = st.copyWith(font: f)),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  SizedBox(width: 72, child: Text(s.t('adv_size'), style: const TextStyle(fontSize: 12.5, color: AppColors.textSoft))),
                  Expanded(
                    child: Slider(
                      value: st.size,
                      min: 0.6,
                      max: 1.0,
                      divisions: 8,
                      label: '${(st.size * 100).round()}%',
                      onChanged: (v) => setState(() => _style[_styleLine] = st.copyWith(size: v)),
                    ),
                  ),
                  SizedBox(width: 44, child: Text('${(st.size * 100).round()}%', style: const TextStyle(fontSize: 12))),
                ],
              ),
              Text(s.t('adv_color'), style: const TextStyle(fontSize: 12.5, color: AppColors.textSoft)),
              const SizedBox(height: 6),
              _ColorPicker(
                value: st.color,
                onChanged: (c) => setState(() => _style[_styleLine] = st.copyWith(color: c)),
              ),
              const SizedBox(height: 4),
              Text(s.t('adv_shadow_note'), style: const TextStyle(fontSize: 11.5, color: AppColors.textSoft)),
              if (!_editing) ...[
                section(5, 'ad_destination'),
                SegmentedButton<String>(
                  segments: [
                    ButtonSegment(value: 'profile', label: Text(s.t('ad_destination_profile')), icon: const Icon(Icons.person_outline)),
                    ButtonSegment(value: 'external', label: Text(s.t('ad_destination_external')), icon: const Icon(Icons.open_in_new)),
                  ],
                  selected: {_destination},
                  onSelectionChanged: (v) => setState(() => _destination = v.first),
                ),
                if (_destination == 'external') ...[
                  const SizedBox(height: 8),
                  TextField(
                    controller: _url,
                    keyboardType: TextInputType.url,
                    decoration: InputDecoration(labelText: s.t('ad_external_url'), hintText: 'https://example.com'),
                  ),
                ],
                section(6, 'ad_targeting'),
                Text(s.t('ad_target_countries'), style: const TextStyle(color: AppColors.textSoft, fontSize: 13)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final c in Countries.all)
                      FilterChip(
                        visualDensity: VisualDensity.compact,
                        label: Text('${c.flag} ${c.name(lang)}', style: const TextStyle(fontSize: 12.5)),
                        selected: _countries.contains(c.code),
                        onSelected: (v) => setState(() => v ? _countries.add(c.code) : _countries.remove(c.code)),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: TextField(controller: _routeFrom, decoration: InputDecoration(labelText: s.t('ad_route_from')))),
                    const SizedBox(width: 10),
                    Expanded(child: TextField(controller: _routeTo, decoration: InputDecoration(labelText: s.t('ad_route_to')))),
                  ],
                ),
                section(7, 'adv_step_duration'),
                if (durations.isEmpty)
                  Text(s.t('adv_no_prices'), style: const TextStyle(color: AppColors.textSoft))
                else
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final d in const [5, 15, 30])
                        ChoiceChip(
                          label: Text(durations[d] == null
                              ? s.t('ad_days', {'n': '$d'})
                              : '${s.t('ad_days', {'n': '$d'})} · ${adMoney(durations[d]!.price, durations[d]!.currency)}'),
                          selected: _days == d,
                          onSelected: durations[d] == null ? null : (_) => setState(() => _days = d),
                        ),
                    ],
                  ),
                section(8, 'adv_step_start'),
                OutlinedButton.icon(
                  onPressed: _pickStart,
                  icon: const Icon(Icons.event),
                  label: Text(_start == null ? s.t('adv_pick_start') : fmt.format(_start!)),
                ),
                const SizedBox(height: 14),
                TextField(controller: _note, maxLines: 2, decoration: InputDecoration(labelText: s.t('ad_note_label'))),
              ],
            ],
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          decoration: const BoxDecoration(color: AppColors.hero, border: Border(top: BorderSide(color: AppColors.line))),
          child: Row(
            children: [
              Expanded(
                child: _editing
                    ? Text(s.t('adv_edit_hint'), style: const TextStyle(fontSize: 12, color: AppColors.textSoft))
                    : Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.t('adv_total'), style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
                          Text(
                            (pkg != null && _start != null) ? adMoney(pkg.price, pkg.currency) : '—',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                          ),
                          if (pkg != null && _start != null)
                            Text('${fmt.format(_start!)} – ${fmt.format(_start!.add(Duration(days: pkg.days)))}',
                                style: const TextStyle(fontSize: 11.5, color: AppColors.textSoft)),
                        ],
                      ),
              ),
              FilledButton(
                onPressed: _busy ? null : () => _submit(s, durations, lang),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14)),
                child: _busy
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(s.t(_editing ? 'adv_save' : 'adv_confirm_ok')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Free colour choice: quick swatches + any colour (hue / lightness).
class _ColorPicker extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  const _ColorPicker({required this.value, required this.onChanged});

  static const _swatches = [
    '#FFFFFF', '#F2F4F7', '#FFCC00', '#FFB020', '#FF6B33', '#E11D48',
    '#4ADE80', '#22C55E', '#3BA3FF', '#1D4ED8', '#A78BFA', '#000000',
  ];

  static String _hex(Color c) {
    String h(double v) => (v * 255).round().clamp(0, 255).toRadixString(16).padLeft(2, '0');
    return '#${h(c.r)}${h(c.g)}${h(c.b)}'.toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final current = Color(adColorValue(value));
    final hsl = HSLColor.fromColor(current);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final c in _swatches)
              GestureDetector(
                onTap: () => onChanged(c),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: Color(adColorValue(c)),
                    shape: BoxShape.circle,
                    border: Border.all(color: value.toUpperCase() == c ? AppColors.accent : AppColors.line, width: value.toUpperCase() == c ? 3 : 1),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 8),
        // Any colour: hue + lightness
        Container(
          height: 14,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            gradient: LinearGradient(colors: [
              for (var h = 0; h <= 360; h += 60) HSLColor.fromAHSL(1, h.toDouble(), 0.85, 0.55).toColor(),
            ]),
          ),
        ),
        Slider(
          value: hsl.hue,
          min: 0,
          max: 360,
          onChanged: (h) => onChanged(_hex(HSLColor.fromAHSL(1, h, hsl.saturation < 0.2 ? 0.85 : hsl.saturation,
              (hsl.lightness < 0.15 || hsl.lightness > 0.9) ? 0.55 : hsl.lightness).toColor())),
        ),
        Row(
          children: [
            const Icon(Icons.brightness_6, size: 16, color: AppColors.textSoft),
            Expanded(
              child: Slider(
                value: hsl.lightness,
                min: 0,
                max: 1,
                onChanged: (l) => onChanged(_hex(hsl.withLightness(l).toColor())),
              ),
            ),
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(color: current, shape: BoxShape.circle, border: Border.all(color: AppColors.line)),
            ),
            const SizedBox(width: 6),
            Text(value.toUpperCase(), style: AppFonts.mono(size: 12, color: AppColors.textSoft)),
          ],
        ),
      ],
    );
  }
}
