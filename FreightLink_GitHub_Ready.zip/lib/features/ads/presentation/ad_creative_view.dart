import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../models/ad_models.dart';

/// Draws a template banner (background image + the customer's texts in
/// the chosen colour) at any width, always in the 1350×300 (4.5:1) format.
/// Text positions and sizes are stored relative to a 1350 px wide banner,
/// so the preview, the admin panel and the home feed look identical.
class AdCreativeView extends StatelessWidget {
  final AdCreative creative;
  final BorderRadius? radius;
  /// Highlights empty fields with their label (editor preview).
  final bool showPlaceholders;
  const AdCreativeView({super.key, required this.creative, this.radius, this.showPlaceholders = false});

  @override
  Widget build(BuildContext context) {
    final color = Color(adColorValue(creative.color));
    final child = AspectRatio(
      aspectRatio: AdBannerSpec.ratio,
      child: LayoutBuilder(
        builder: (context, box) {
          final w = box.maxWidth;
          final h = box.maxHeight;
          final scale = w / AdBannerSpec.width;
          return Stack(
            fit: StackFit.expand,
            children: [
              if (creative.imageUrl.isNotEmpty)
                Image.network(
                  creative.imageUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const ColoredBox(color: AppColors.cardAlt),
                  loadingBuilder: (context, child, p) => p == null ? child : const ColoredBox(color: AppColors.cardAlt),
                )
              else
                const ColoredBox(color: AppColors.cardAlt),
              if (creative.logo != null && (creative.logoUrl != null || showPlaceholders))
                Positioned(
                  left: creative.logo!.x * w,
                  top: creative.logo!.y * h,
                  width: math.max(0.0, math.min(creative.logo!.w * w, w - creative.logo!.x * w)),
                  height: math.max(0.0, math.min(creative.logo!.h * h, h - creative.logo!.y * h)),
                  child: creative.logoUrl != null
                      ? Image.network(creative.logoUrl!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox())
                      : Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.25),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.white54),
                          ),
                          child: FittedBox(
                            child: Padding(
                              padding: const EdgeInsets.all(4),
                              child: Text('LOGO', style: TextStyle(color: Colors.white.withValues(alpha: 0.8), fontWeight: FontWeight.w800)),
                            ),
                          ),
                        ),
                ),
              for (final f in creative.fields)
                Builder(builder: (_) {
                  final raw = (creative.texts[f.key] ?? '').trim();
                  final placeholder = raw.isEmpty && showPlaceholders;
                  final text = raw.isEmpty ? (showPlaceholders ? f.label : '') : raw;
                  if (text.isEmpty) return const SizedBox.shrink();
                  return Positioned(
                    left: f.x * w,
                    top: f.y * h,
                    width: math.max(0.0, math.min(f.w * w, w - f.x * w)),
                    child: Text(
                      text,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: switch (f.align) {
                        'center' => TextAlign.center,
                        'right' => TextAlign.right,
                        _ => TextAlign.left,
                      },
                      style: TextStyle(
                        color: placeholder ? color.withValues(alpha: 0.45) : color,
                        fontSize: (f.size * scale).clamp(6.0, 200.0).toDouble(),
                        height: 1.1,
                        fontWeight: f.bold ? FontWeight.w800 : FontWeight.w500,
                        shadows: const [Shadow(color: Color(0x66000000), blurRadius: 3, offset: Offset(0, 1))],
                      ),
                    ),
                  );
                }),
            ],
          );
        },
      ),
    );
    if (radius == null) return child;
    return ClipRRect(borderRadius: radius!, child: child);
  }
}
