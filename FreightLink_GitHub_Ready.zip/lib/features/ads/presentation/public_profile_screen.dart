import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/presence/online_users.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../repositories/profile_page_repository.dart';
import '../../../repositories/profile_repository.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../cargo/presentation/widgets/cargo_card.dart';
import '../../chat/data/group_repository.dart';
import '../../chat/presentation/providers/chat_providers.dart';
import '../../chat/presentation/widgets/call_options.dart';
import 'ads_providers.dart';
import 'profile_catalog.dart';

/// A user's / company's FreightLink page, laid out like WhatsApp's
/// "business info": cover photo, round logo, name + verified tick, four
/// quick buttons (call · message · catalog · share), the catalog of their
/// work with short captions, about / hours / address, their services and
/// open loads. Every role has one. The owner edits it from here.
class PublicProfileScreen extends ConsumerStatefulWidget {
  final String userId;
  const PublicProfileScreen({super.key, required this.userId});

  @override
  ConsumerState<PublicProfileScreen> createState() => _PublicProfileScreenState();
}

class _PublicProfileScreenState extends ConsumerState<PublicProfileScreen> {
  bool _opening = false;

  Future<void> _message() async {
    final strings = ref.read(stringsProvider);
    setState(() => _opening = true);
    try {
      final conv = await ref.read(groupRepositoryProvider).openDirect(widget.userId);
      ref.invalidate(conversationByIdProvider(conv.id));
      if (mounted) context.push('/chat/${conv.id}');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(strings.t('chat_open_failed'))));
      }
    } finally {
      if (mounted) setState(() => _opening = false);
    }
  }

  /// Link to this profile (the web app uses #/ routes).
  String _shareLink() => '${Uri.base.origin}${Uri.base.path}#/user/${widget.userId}';

  Future<void> _share(AppStrings s) async {
    await Clipboard.setData(ClipboardData(text: _shareLink()));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('profile_link_copied'))));
  }

  Future<void> _changeCover(AppStrings s) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final file = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, maxHeight: 900, imageQuality: 82);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      await ref.read(profilePageRepositoryProvider).uploadCover(bytes, contentType: file.mimeType);
      ref.invalidate(profileDetailsProvider(widget.userId));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(s.t('profile_photo_error'))));
    }
  }

  Future<void> _editInfo(AppStrings s, ProfileDetails? d) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.card,
      builder: (_) => _EditInfoSheet(s: s, details: d),
    );
    if (saved == true) ref.invalidate(profileDetailsProvider(widget.userId));
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(stringsProvider);
    final me = ref.watch(currentUserIdProvider);
    final profileAsync = ref.watch(publicProfileProvider(widget.userId));
    final p = profileAsync.valueOrNull;
    final online = ref.watch(isUserOnlineProvider(widget.userId));
    final details = ref.watch(profileDetailsProvider(widget.userId)).valueOrNull;
    final catalog = ref.watch(profileCatalogProvider(widget.userId)).valueOrNull ?? const <CatalogItem>[];
    final services = ref.watch(ownedServicesProvider(widget.userId)).valueOrNull ?? const <OwnedService>[];
    final loads = ref.watch(userOpenCargoProvider(widget.userId));
    final isMe = me == widget.userId;
    // Phone only when the server releases it (advertiser, open load, chat…).
    final contactPhone = isMe ? null : ref.watch(userContactProvider(widget.userId)).valueOrNull?.phone?.trim();
    final hasPhone = (contactPhone ?? '').isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('profile_business_info')),
        actions: [
          if (isMe)
            TextButton(onPressed: () => _editInfo(s, details), child: Text(s.t('profile_edit'))),
        ],
      ),
      body: profileAsync.isLoading && p == null
          ? const Center(child: CircularProgressIndicator())
          : p == null
              ? Center(child: Text(s.t('profile_not_found')))
              : RefreshIndicator(
                  onRefresh: () async {
                    ref.invalidate(publicProfileProvider(widget.userId));
                    ref.invalidate(profileDetailsProvider(widget.userId));
                    ref.invalidate(profileCatalogProvider(widget.userId));
                  },
                  child: ListView(
                    padding: const EdgeInsets.only(bottom: 40),
                    children: [
                      // Cover + round logo overlapping it.
                      SizedBox(
                        height: 236,
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Positioned(
                              left: 0,
                              right: 0,
                              top: 0,
                              height: 170,
                              child: (details?.coverUrl ?? '').isNotEmpty
                                  ? Image.network(details!.coverUrl!, fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => const _CoverPlaceholder())
                                  : const _CoverPlaceholder(),
                            ),
                            if (isMe)
                              Positioned(
                                right: 10,
                                top: 10,
                                child: IconButton.filledTonal(
                                  tooltip: s.t('profile_change_cover'),
                                  onPressed: () => _changeCover(s),
                                  icon: const Icon(Icons.photo_camera_outlined),
                                ),
                              ),
                            Positioned(
                              left: 0,
                              right: 0,
                              top: 100,
                              child: Center(
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: const BoxDecoration(color: AppColors.background, shape: BoxShape.circle),
                                  child: UserAvatar(imageUrl: p.avatarUrl, initials: p.initials, radius: 62, online: online),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Text(
                                p.fullName.isEmpty ? '—' : p.fullName,
                                textAlign: TextAlign.center,
                                style: AppFonts.display(size: 28, color: AppColors.text),
                              ),
                            ),
                            if (p.isVerified) ...[const SizedBox(width: 6), const VerifiedTick(size: 22)],
                          ],
                        ),
                      ),
                      if (p.role != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text('~${s.t('role_label_${p.role}')}',
                              textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSoft, fontSize: 16)),
                        ),
                      const SizedBox(height: 18),
                      // Quick buttons, WhatsApp-style.
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Row(
                          children: [
                            if (!isMe)
                              _ActionTile(
                                icon: Icons.call_outlined,
                                label: s.t('chat_call'),
                                enabled: hasPhone,
                                onTap: hasPhone ? () => showCallOptions(context, s, contactPhone!) : null,
                              ),
                            if (!isMe)
                              _ActionTile(
                                icon: Icons.chat_bubble_outline,
                                label: s.t('detail_message_button'),
                                busy: _opening,
                                onTap: _opening ? null : _message,
                              ),
                            _ActionTile(
                              icon: Icons.storefront_outlined,
                              label: s.t('profile_catalog'),
                              onTap: () => context.push('/user/${widget.userId}/catalog'),
                            ),
                            _ActionTile(
                              icon: Icons.share_outlined,
                              label: s.t('profile_share'),
                              onTap: () => _share(s),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Catalog preview (owner always sees the "add" tile).
                      if (catalog.isNotEmpty || isMe)
                        _Section(
                          title: s.t('profile_catalog'),
                          trailing: catalog.isEmpty
                              ? null
                              : TextButton(
                                  onPressed: () => context.push('/user/${widget.userId}/catalog'),
                                  child: Text('${s.t('catalog_see_all')} ›'),
                                ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (isMe && catalog.isEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: Text(s.t('catalog_empty_me'), style: const TextStyle(color: AppColors.textSoft, fontSize: 13)),
                                ),
                              CatalogGrid(userId: widget.userId, limit: 6),
                            ],
                          ),
                        ),
                      // About / hours / address.
                      if (!(details?.isEmpty ?? true) || isMe)
                        _Section(
                          title: s.t('profile_info'),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if ((details?.about ?? '').isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Text(details!.about!, style: const TextStyle(fontSize: 15, height: 1.35)),
                                ),
                              if ((details?.workHours ?? '').isNotEmpty)
                                _InfoRow(icon: Icons.schedule_outlined, text: details!.workHours!),
                              if ((details?.address ?? '').isNotEmpty)
                                _InfoRow(icon: Icons.place_outlined, text: details!.address!),
                              if (hasPhone) _InfoRow(icon: Icons.call_outlined, text: contactPhone!),
                              if (isMe && (details?.isEmpty ?? true))
                                Text(s.t('profile_info_empty_me'), style: const TextStyle(color: AppColors.textSoft, fontSize: 13)),
                            ],
                          ),
                        ),
                      // Their service(s) → service page.
                      if (services.isNotEmpty)
                        _Section(
                          title: s.t('profile_services'),
                          child: Column(
                            children: [
                              for (final svc in services)
                                ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: const Icon(Icons.home_repair_service_outlined, color: AppColors.accent),
                                  title: Text(svc.name),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () => context.push('/service/${svc.id}'),
                                ),
                            ],
                          ),
                        ),
                      _Section(
                        title: s.t('profile_open_loads'),
                        child: loads.when(
                          loading: () => const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
                          error: (_, __) => Text(s.t('home_error_loading')),
                          data: (list) => list.isEmpty
                              ? Text(s.t('profile_no_open_loads'), style: const TextStyle(color: AppColors.textSoft))
                              : Column(
                                  children: [
                                    for (final c in list)
                                      Padding(
                                        padding: const EdgeInsets.only(bottom: 8),
                                        child: CargoCard(
                                          cargo: c,
                                          strings: s,
                                          compact: true,
                                          onTap: () => context.push('/load/${c.id}'),
                                        ),
                                      ),
                                  ],
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _CoverPlaceholder extends StatelessWidget {
  const _CoverPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0F4C5C), Color(0xFF14323F), AppColors.background],
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool enabled;
  final bool busy;
  const _ActionTile({required this.icon, required this.label, this.onTap, this.enabled = true, this.busy = false});

  @override
  Widget build(BuildContext context) {
    final color = enabled ? AppColors.online : AppColors.textSoft;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Material(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Column(
                children: [
                  busy
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                      : Icon(icon, color: color, size: 26),
                  const SizedBox(height: 6),
                  Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? trailing;
  const _Section({required this.title, required this.child, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 10),
            child,
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: AppColors.textSoft),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 15))),
        ],
      ),
    );
  }
}

/// About / working hours / address editor for my own profile.
class _EditInfoSheet extends ConsumerStatefulWidget {
  final AppStrings s;
  final ProfileDetails? details;
  const _EditInfoSheet({required this.s, required this.details});

  @override
  ConsumerState<_EditInfoSheet> createState() => _EditInfoSheetState();
}

class _EditInfoSheetState extends ConsumerState<_EditInfoSheet> {
  late final _about = TextEditingController(text: widget.details?.about ?? '');
  late final _hours = TextEditingController(text: widget.details?.workHours ?? '');
  late final _address = TextEditingController(text: widget.details?.address ?? '');
  bool _saving = false;

  @override
  void dispose() {
    _about.dispose();
    _hours.dispose();
    _address.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    try {
      await ref.read(profilePageRepositoryProvider).saveDetails(about: _about.text, workHours: _hours.text, address: _address.text);
      nav.pop(true);
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(widget.s.t('error_generic'))));
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    InputDecoration deco(String label, String hint) =>
        InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder());
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(s.t('profile_edit_info'), style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 14),
              TextField(
                controller: _about,
                maxLines: 4,
                maxLength: 500,
                inputFormatters: [LengthLimitingTextInputFormatter(500)],
                decoration: deco(s.t('profile_about'), s.t('profile_about_hint')),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _hours,
                maxLength: 120,
                inputFormatters: [LengthLimitingTextInputFormatter(120)],
                decoration: deco(s.t('profile_work_hours'), s.t('profile_work_hours_hint')),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _address,
                maxLength: 200,
                inputFormatters: [LengthLimitingTextInputFormatter(200)],
                decoration: deco(s.t('profile_address'), s.t('profile_address_hint')),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(s.t('catalog_save')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
