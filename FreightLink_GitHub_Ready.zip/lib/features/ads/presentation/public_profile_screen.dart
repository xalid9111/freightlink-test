import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/localization/locale_controller.dart';
import '../../../core/presence/online_users.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../repositories/profile_repository.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../cargo/presentation/widgets/cargo_card.dart';
import '../../chat/data/group_repository.dart';
import '../../chat/presentation/providers/chat_providers.dart';
import '../../chat/presentation/widgets/call_options.dart';
import 'ads_providers.dart';

/// A user's / company's public FreightLink page (opened from a sponsored
/// banner): name, photo, verified tick, role, call / message buttons and
/// their open loads.
class PublicProfileScreen extends ConsumerStatefulWidget {
  final String userId;
  const PublicProfileScreen({super.key, required this.userId});

  @override
  ConsumerState<PublicProfileScreen> createState() => _PublicProfileScreenState();
}

class _PublicProfileScreenState extends ConsumerState<PublicProfileScreen> {
  bool _opening = false;

  Future<void> _message() async {
    final strings = ref.read(stringsProvider);
    setState(() => _opening = true);
    try {
      final conv = await ref.read(groupRepositoryProvider).openDirect(widget.userId);
      ref.invalidate(conversationByIdProvider(conv.id));
      if (mounted) context.push('/messages/${conv.id}');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(strings.t('chat_open_failed'))));
      }
    } finally {
      if (mounted) setState(() => _opening = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(stringsProvider);
    final me = ref.watch(currentUserIdProvider);
    final profileAsync = ref.watch(publicProfileProvider(widget.userId));
    final p = profileAsync.valueOrNull;
    final online = ref.watch(isUserOnlineProvider(widget.userId));
    final loads = ref.watch(userOpenCargoProvider(widget.userId));
    final isMe = me == widget.userId;

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('profile_public_title'))),
      body: profileAsync.isLoading && p == null
          ? const Center(child: CircularProgressIndicator())
          : p == null
              ? Center(child: Text(strings.t('profile_not_found')))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
                  children: [
                    Center(child: UserAvatar(imageUrl: p.avatarUrl, initials: p.initials, radius: 44, online: online)),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Flexible(
                          child: Text(
                            p.fullName.isEmpty ? '—' : p.fullName,
                            textAlign: TextAlign.center,
                            style: AppFonts.display(size: 26, color: AppColors.text),
                          ),
                        ),
                        if (p.isVerified) ...[const SizedBox(width: 6), const VerifiedTick(size: 20)],
                      ],
                    ),
                    if (p.role != null) ...[
                      const SizedBox(height: 4),
                      Text(strings.t('role_label_${p.role}'),
                          textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSoft)),
                    ],
                    const SizedBox(height: 18),
                    if (!isMe)
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _opening ? null : _message,
                              icon: _opening
                                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                                  : const Icon(Icons.chat_bubble_outline),
                              label: Text(strings.t('detail_message_button')),
                            ),
                          ),
                          if ((p.phone ?? '').trim().isNotEmpty) ...[
                            const SizedBox(width: 10),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => showCallOptions(context, strings, p.phone!.trim()),
                                icon: const Icon(Icons.call_outlined),
                                label: Text(strings.t('chat_call')),
                              ),
                            ),
                          ],
                        ],
                      ),
                    const SizedBox(height: 24),
                    Text(strings.t('profile_open_loads').toUpperCase(),
                        style: const TextStyle(color: AppColors.textSoft, fontSize: 12, letterSpacing: 1.1, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    loads.when(
                      loading: () => const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
                      error: (_, __) => Text(strings.t('home_error_loading')),
                      data: (list) => list.isEmpty
                          ? Text(strings.t('profile_no_open_loads'), style: const TextStyle(color: AppColors.textSoft))
                          : Column(
                              children: [
                                for (final c in list)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: CargoCard(
                                      cargo: c,
                                      strings: strings,
                                      compact: true,
                                      onTap: () => context.push('/cargo/${c.id}'),
                                    ),
                                  ),
                              ],
                            ),
                    ),
                  ],
                ),
    );
  }
}
