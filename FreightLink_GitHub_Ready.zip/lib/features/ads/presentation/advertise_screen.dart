import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/ad_models.dart';
import '../data/ads_repository.dart';
import 'ads_providers.dart';

/// "Reklam ver": choose a package → order → pay → report the payment →
/// the admin checks it, approves and publishes the banner. Below: my
/// orders with their status.
class AdvertiseScreen extends ConsumerStatefulWidget {
  const AdvertiseScreen({super.key});

  @override
  ConsumerState<AdvertiseScreen> createState() => _AdvertiseScreenState();
}

class _AdvertiseScreenState extends ConsumerState<AdvertiseScreen> {
  String? _packageId;
  final _noteCtrl = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _noteCtrl.dispose();
    super.dispose();
  }

  void _toast(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _order(AppStrings s) async {
    final id = _packageId;
    if (id == null) {
      _toast(s.t('ad_pick_package'));
      return;
    }
    setState(() => _busy = true);
    try {
      await ref.read(adsRepositoryProvider).createOrder(id, _noteCtrl.text.trim());
      _noteCtrl.clear();
      setState(() => _packageId = null);
      _toast(s.t('ad_order_created'));
    } catch (_) {
      _toast(s.t('ad_action_failed'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(stringsProvider);
    final packages = ref.watch(adPackagesProvider);
    final orders = ref.watch(myAdOrdersProvider).valueOrNull ?? const <AdOrder>[];

    return Scaffold(
      appBar: AppBar(title: Text(s.t('ad_title'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
        children: [
          Text(s.t('ad_intro'), style: const TextStyle(color: AppColors.textSoft, height: 1.4)),
          const SizedBox(height: 6),
          Text(s.t('ad_banner_size', {'w': '${AdBannerSpec.width}', 'h': '${AdBannerSpec.height}'}),
              style: const TextStyle(color: AppColors.textSoft, fontSize: 12.5)),
          const SizedBox(height: 16),
          Text(s.t('ad_packages').toUpperCase(), style: _header),
          const SizedBox(height: 8),
          packages.when(
            loading: () => const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
            error: (_, __) => Text(s.t('home_error_loading')),
            data: (list) => list.isEmpty
                ? Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(12)),
                    child: Text(s.t('ad_no_packages'), style: const TextStyle(color: AppColors.textSoft)),
                  )
                : Column(
                    children: [
                      for (final p in list)
                        Card(
                          child: RadioListTile<String>(
                            value: p.id,
                            groupValue: _packageId,
                            onChanged: (v) => setState(() => _packageId = v),
                            title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(s.t('ad_days', {'n': '${p.days}'})),
                            secondary: Text('${_fmtMoney(p.price)} ${p.currency}',
                                style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.w800, fontSize: 16)),
                          ),
                        ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _noteCtrl,
                        maxLines: 3,
                        minLines: 1,
                        decoration: InputDecoration(labelText: s.t('ad_note_label'), hintText: s.t('ad_note_hint')),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _busy ? null : () => _order(s),
                          icon: _busy
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.campaign_outlined),
                          label: Text(s.t('ad_order_button')),
                        ),
                      ),
                    ],
                  ),
          ),
          const SizedBox(height: 26),
          Text(s.t('ad_my_orders').toUpperCase(), style: _header),
          const SizedBox(height: 8),
          if (orders.isEmpty)
            Text(s.t('ad_no_orders'), style: const TextStyle(color: AppColors.textSoft))
          else
            for (final o in orders) _OrderCard(order: o, strings: s),
        ],
      ),
    );
  }
}

const _header = TextStyle(color: AppColors.textSoft, fontSize: 12, letterSpacing: 1.1, fontWeight: FontWeight.w700);

String _fmtMoney(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);

Color _statusColor(String status) => switch (status) {
      'active' => AppColors.online,
      'approved' => AppColors.route,
      'awaiting_approval' => AppColors.blue,
      'pending_payment' => AppColors.accent,
      'rejected' || 'cancelled' => AppColors.danger,
      _ => AppColors.textSoft,
    };

class _OrderCard extends ConsumerStatefulWidget {
  final AdOrder order;
  final AppStrings strings;
  const _OrderCard({required this.order, required this.strings});

  @override
  ConsumerState<_OrderCard> createState() => _OrderCardState();
}

class _OrderCardState extends ConsumerState<_OrderCard> {
  bool _busy = false;

  Future<void> _run(Future<void> Function() job) async {
    final s = widget.strings;
    setState(() => _busy = true);
    try {
      await job();
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ad_action_failed'))));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _reportPayment() async {
    final s = widget.strings;
    final ctrl = TextEditingController();
    final ref0 = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('ad_paid_title')),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(labelText: s.t('ad_payment_ref'), hintText: s.t('ad_payment_ref_hint')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('common_cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: Text(s.t('ad_paid_confirm'))),
        ],
      ),
    );
    ctrl.dispose();
    if (ref0 == null) return;
    await _run(() => ref.read(adsRepositoryProvider).submitPayment(widget.order.id, ref0));
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    final o = widget.order;
    final lang = ref.watch(currentLocaleProvider).languageCode;
    final payInfo = o.status == 'pending_payment' ? ref.watch(adPaymentInfoProvider).valueOrNull : null;
    final color = _statusColor(o.status);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('${o.packageName} · ${_fmtMoney(o.price)} ${o.currency}',
                      style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.text)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                  child: Text(s.t('ad_status_${o.status}'), style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${DateFormat('d MMM yyyy, HH:mm', lang).format(o.createdAt.toLocal())} · ${s.t('ad_days', {'n': '${o.days}'})}',
              style: const TextStyle(color: AppColors.textSoft, fontSize: 12.5),
            ),
            Text('${s.t('ad_payment')}: ${s.t('ad_pay_${o.paymentStatus}')}',
                style: const TextStyle(color: AppColors.textSoft, fontSize: 12.5)),
            if ((o.adminNote ?? '').isNotEmpty) ...[
              const SizedBox(height: 6),
              Text('${s.t('ad_admin_note')}: ${o.adminNote}', style: const TextStyle(color: AppColors.text, fontSize: 13)),
            ],
            if (o.status == 'pending_payment') ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppColors.cardAlt, borderRadius: BorderRadius.circular(10)),
                child: Text(payInfo ?? s.t('ad_payment_info_missing'), style: const TextStyle(fontSize: 13, height: 1.4)),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.icon(
                    onPressed: _busy ? null : _reportPayment,
                    icon: const Icon(Icons.check_circle_outline, size: 18),
                    label: Text(s.t('ad_i_paid')),
                  ),
                  OutlinedButton(
                    onPressed: _busy ? null : () => _run(() => ref.read(adsRepositoryProvider).cancelOrder(o.id)),
                    child: Text(s.t('ad_cancel_order')),
                  ),
                ],
              ),
            ],
            if (o.status == 'awaiting_approval') ...[
              const SizedBox(height: 8),
              Text(s.t('ad_waiting_note'), style: const TextStyle(color: AppColors.blue, fontSize: 13)),
            ],
          ],
        ),
      ),
    );
  }
}
