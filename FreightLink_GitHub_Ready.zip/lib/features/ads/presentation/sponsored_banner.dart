import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/localization/app_strings.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../models/ad_models.dart';
import '../../../repositories/profile_repository.dart';

/// One sponsored slot in the home feed: clearly marked "SPONSORLU",
/// banner in the fixed 3:1 format, advertiser + "View company". Tapping
/// anywhere opens the advertiser's FreightLink profile.
class SponsoredBanner extends ConsumerWidget {
  final Ad ad;
  final AppStrings strings;
  const SponsoredBanner({super.key, required this.ad, required this.strings});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(publicProfileProvider(ad.advertiserId)).valueOrNull;
    void open() => context.push('/user/${ad.advertiserId}');

    return Material(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: open,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.accent.withValues(alpha: 0.35)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Only a small blue tick (verified advertisers) sits in the
              // top-right corner; the advertiser's text is never covered.
              Stack(
                children: [
                  AspectRatio(
                    aspectRatio: AdBannerSpec.ratio,
                    child: Image.network(
                      ad.imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: AppColors.cardAlt,
                        alignment: Alignment.center,
                        child: const Icon(Icons.image_not_supported_outlined, color: AppColors.textSoft),
                      ),
                      loadingBuilder: (context, child, progress) =>
                          progress == null ? child : Container(color: AppColors.cardAlt),
                    ),
                  ),
                  // Blue tick for advertisers verified by FreightLink.
                  if (p?.isVerified == true)
                    Positioned(
                      top: 8,
                      right: 8,
                      child: const Icon(Icons.verified, color: Color(0xFF1D9BF0), size: 28),
                    ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
                child: Row(
                  children: [
                    UserAvatar(imageUrl: p?.avatarUrl, initials: p?.initials ?? '?', radius: 15),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.accent.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(strings.t('ad_sponsored'),
                                    style: AppFonts.mono(size: 9.5, color: AppColors.accent, letterSpacing: 1.1)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  p?.fullName ?? '…',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.text),
                                ),
                              ),
                              if (p?.isVerified == true) ...[const SizedBox(width: 4), const VerifiedTick(size: 15)],
                            ],
                          ),
                          if ((ad.title ?? '').isNotEmpty)
                            Text(ad.title!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
                        ],
                      ),
                    ),
                    TextButton(onPressed: open, child: Text(strings.t('ad_view_company'))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
