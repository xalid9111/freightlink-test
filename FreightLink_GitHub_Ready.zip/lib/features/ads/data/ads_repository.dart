import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/config/supabase_config.dart';
import '../../../models/ad_models.dart';

const _timeout = Duration(seconds: 20);

/// Advertising data (migration 0015). Customers create orders and report
/// payment through server functions; everything that makes an ad visible
/// (approval, image, dates, on/off) is admin-only and checked on the
/// server.
class AdsRepository {
  final SupabaseClient _c = SupabaseConfig.client;

  // ---- everyone ---------------------------------------------------------

  /// Ads to show in the feed right now (RLS already limits other users to
  /// live ads; the extra check hides the viewer's own scheduled ones).
  Future<List<Ad>> liveAds() async {
    final nowIso = DateTime.now().toUtc().toIso8601String();
    final rows = await _c
        .from('ads')
        .select()
        .eq('is_active', true)
        .lte('starts_at', nowIso)
        .gt('ends_at', nowIso)
        .order('created_at')
        .timeout(_timeout);
    return (rows as List).map((r) => Ad.fromJson(Map<String, dynamic>.from(r as Map))).where((a) => a.isLive).toList();
  }

  Future<List<AdPackage>> packages() async {
    final rows = await _c.from('ad_packages').select().eq('is_active', true).order('sort').timeout(_timeout);
    return (rows as List).map((r) => AdPackage.fromJson(Map<String, dynamic>.from(r as Map))).toList();
  }

  Future<String?> paymentInfo() async {
    final res = await _c.rpc('get_ad_payment_info').timeout(_timeout);
    return res is String && res.trim().isNotEmpty ? res : null;
  }

  Future<AdOrder> createOrder(String packageId, String? note) async {
    final row = await _c.rpc('create_ad_order', params: {'p_package': packageId, 'p_note': note}).timeout(_timeout);
    final m = row is List ? row.first : row;
    return AdOrder.fromJson(Map<String, dynamic>.from(m as Map));
  }

  Future<void> submitPayment(String orderId, String? reference) async {
    await _c.rpc('submit_ad_payment', params: {'p_order': orderId, 'p_reference': reference}).timeout(_timeout);
  }

  Future<void> cancelOrder(String orderId) async {
    await _c.rpc('cancel_ad_order', params: {'p_order': orderId}).timeout(_timeout);
  }

  Stream<List<AdOrder>> watchMyOrders(String uid) => _c
      .from('ad_orders')
      .stream(primaryKey: ['id'])
      .eq('advertiser_id', uid)
      .order('created_at', ascending: false)
      .map((rows) => rows.map(AdOrder.fromJson).toList());

  // ---- admin ------------------------------------------------------------

  Stream<List<AdOrder>> watchAllOrders() => _c
      .from('ad_orders')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false)
      .limit(500)
      .map((rows) => rows.map(AdOrder.fromJson).toList());

  Stream<List<Ad>> watchAllAds() => _c
      .from('ads')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false)
      .limit(500)
      .map((rows) => rows.map(Ad.fromJson).toList());

  Future<List<AdPackage>> allPackages() async {
    final rows = await _c.from('ad_packages').select().order('sort').timeout(_timeout);
    return (rows as List).map((r) => AdPackage.fromJson(Map<String, dynamic>.from(r as Map))).toList();
  }

  Future<Map<String, dynamic>> adCounts() async {
    final res = await _c.rpc('admin_ad_counts').timeout(_timeout);
    return res is Map ? Map<String, dynamic>.from(res) : const {};
  }

  Future<void> updateOrder(String orderId, {String? status, String? paymentStatus, String? note}) async {
    await _c.rpc('admin_update_ad_order', params: {
      'p_order': orderId,
      'p_status': status,
      'p_payment_status': paymentStatus,
      'p_note': note,
    }).timeout(_timeout);
  }

  Future<void> saveAd({
    String? adId,
    String? orderId,
    required String advertiserId,
    String? title,
    required String imageUrl,
    required DateTime startsAt,
    required DateTime endsAt,
    required bool active,
  }) async {
    await _c.rpc('admin_save_ad', params: {
      'p_ad': adId,
      'p_order': orderId,
      'p_advertiser': advertiserId,
      'p_title': title,
      'p_image_url': imageUrl,
      'p_starts': startsAt.toUtc().toIso8601String(),
      'p_ends': endsAt.toUtc().toIso8601String(),
      'p_active': active,
    }).timeout(_timeout);
  }

  Future<void> setAdActive(String adId, bool active) async {
    await _c.rpc('admin_set_ad_active', params: {'p_ad': adId, 'p_active': active}).timeout(_timeout);
  }

  Future<void> savePackage(AdPackage p) async {
    await _c.rpc('admin_save_ad_package', params: {
      'p_id': p.id,
      'p_name': p.name,
      'p_days': p.days,
      'p_price': p.price,
      'p_active': p.isActive,
    }).timeout(_timeout);
  }

  Future<void> setPaymentInfo(String text) async {
    await _c.rpc('admin_set_ad_payment_info', params: {'p_text': text}).timeout(_timeout);
  }

  /// Uploads a banner to the public "ads" bucket (admins only) and
  /// returns its public URL.
  Future<String> uploadBanner(Uint8List bytes, String extension) async {
    final ext = extension.toLowerCase() == 'jpeg' ? 'jpg' : extension.toLowerCase();
    final path = 'banners/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await _c.storage
        .from('ads')
        .uploadBinary(path, bytes,
            fileOptions: FileOptions(contentType: ext == 'png' ? 'image/png' : (ext == 'webp' ? 'image/webp' : 'image/jpeg')))
        .timeout(const Duration(minutes: 2));
    return _c.storage.from('ads').getPublicUrl(path);
  }
}

final adsRepositoryProvider = Provider<AdsRepository>((ref) => AdsRepository());
