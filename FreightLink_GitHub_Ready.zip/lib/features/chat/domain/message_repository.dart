import '../../../models/message_model.dart';

abstract class MessageRepository {
  Future<ConversationModel> getOrCreateConversation({
    required String cargoId,
    required String cargoOwnerId,
    required String carrierUserId,
  });

  Future<void> send({
    required String conversationId,
    required String senderId,
    required String receiverId,
    required String message,
  });

  /// Realtime stream of messages in a conversation, backed by Supabase
  /// Realtime (migration 0001 publishes public.messages).
  Stream<List<MessageModel>> watchConversation(String conversationId);

  /// All conversations the signed-in user is part of (RLS already
  /// scopes "part of" — see conversations_participants in migration
  /// 0002), newest first.
  Future<List<ConversationModel>> fetchMyConversations();

  /// Live list of messages addressed to [userId] (used to count unread).
  Stream<List<MessageModel>> watchReceived(String userId);

  /// Marks every unread message in [conversationId] addressed to
  /// [userId] as read (RLS messages_mark_read, migration 0002).
  Future<void> markConversationRead({required String conversationId, required String userId});
}
