import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../core/config/supabase_config.dart';
import '../../../models/message_model.dart';
import '../domain/message_repository.dart';

class MessageRepositoryImpl implements MessageRepository {
  final SupabaseClient _client = SupabaseConfig.client;

  @override
  Future<ConversationModel> getOrCreateConversation({
    required String cargoId,
    required String cargoOwnerId,
    required String carrierUserId,
  }) async {
    final existing = await _client
        .from('conversations')
        .select()
        .eq('cargo_id', cargoId)
        .eq('carrier_user_id', carrierUserId)
        .maybeSingle();
    if (existing != null) return ConversationModel.fromJson(existing);

    final row = await _client.from('conversations').insert({
      'cargo_id': cargoId,
      'cargo_owner_id': cargoOwnerId,
      'carrier_user_id': carrierUserId,
    }).select().single();
    return ConversationModel.fromJson(row);
  }

  @override
  Future<void> send({
    required String conversationId,
    required String senderId,
    required String receiverId,
    required String message,
  }) async {
    await _client.from('messages').insert({
      'conversation_id': conversationId,
      'sender_id': senderId,
      'receiver_id': receiverId,
      'message': message,
    });
  }

  @override
  Stream<List<MessageModel>> watchConversation(String conversationId) {
    return _client
        .from('messages')
        .stream(primaryKey: ['id'])
        .eq('conversation_id', conversationId)
        .order('created_at')
        .map((rows) => rows.map(MessageModel.fromJson).toList());
  }

  @override
  Future<List<ConversationModel>> fetchMyConversations() async {
    final rows = await _client.from('conversations').select().order('created_at', ascending: false);
    return (rows as List).map((r) => ConversationModel.fromJson(r)).toList();
  }

  @override
  Stream<List<MessageModel>> watchReceived(String userId) {
    return _client
        .from('messages')
        .stream(primaryKey: ['id'])
        .eq('receiver_id', userId)
        .map((rows) => rows.map(MessageModel.fromJson).toList());
  }

  @override
  Future<void> markConversationRead({required String conversationId, required String userId}) async {
    await _client
        .from('messages')
        .update({'read_at': DateTime.now().toUtc().toIso8601String()})
        .eq('conversation_id', conversationId)
        .eq('receiver_id', userId)
        .isFilter('read_at', null);
  }

  @override
  Future<void> sendAttachment({
    required String conversationId,
    required String senderId,
    required String receiverId,
    required Uint8List bytes,
    required String type,
    required String fileName,
    String? contentType,
    int? audioDurationMs,
  }) async {
    final safeName = fileName.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final path = '$conversationId/${DateTime.now().millisecondsSinceEpoch}_$safeName';
    await _client.storage.from('chat-files').uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: contentType, upsert: false),
        );
    await _client.from('messages').insert({
      'conversation_id': conversationId,
      'sender_id': senderId,
      'receiver_id': receiverId,
      'attachment_path': path,
      'attachment_type': type,
      'attachment_name': fileName,
      'attachment_size': bytes.length,
      if (audioDurationMs != null) 'audio_duration_ms': audioDurationMs,
    });
  }

  @override
  Future<String> signedUrl(String path) {
    return _client.storage.from('chat-files').createSignedUrl(path, 60 * 60);
  }
}
