import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../models/message_model.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import 'providers/chat_providers.dart';

/// Real-time message thread for one conversation — Supabase Realtime
/// via MessageRepository.watchConversation() (migration 0001 publishes
/// public.messages for exactly this). No polling, no fake delay.
class ConversationThreadScreen extends ConsumerStatefulWidget {
  final String conversationId;
  const ConversationThreadScreen({super.key, required this.conversationId});

  @override
  ConsumerState<ConversationThreadScreen> createState() => _ConversationThreadScreenState();
}

class _ConversationThreadScreenState extends ConsumerState<ConversationThreadScreen> {
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool _sending = false;

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    // The conversation row already carries both participant ids — the
    // receiver is whichever one of the two isn't me. Fetching the
    // conversation list provider's cached data avoids a network round
    // trip just to know who the other participant is.
    final conversations = ref.read(myConversationsProvider).value ?? [];
    final match = conversations.where((c) => c.conversation.id == widget.conversationId);
    if (match.isEmpty) return;
    final conv = match.first.conversation;
    final receiverId = conv.cargoOwnerId == user.id ? conv.carrierUserId : conv.cargoOwnerId;

    setState(() => _sending = true);
    try {
      await ref.read(messageRepositoryProvider).send(
            conversationId: widget.conversationId,
            senderId: user.id,
            receiverId: receiverId,
            message: text,
          );
      _inputCtrl.clear();
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final messagesAsync = ref.watch(conversationMessagesProvider(widget.conversationId));

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('nav_messages'))),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: messagesAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => Center(child: Text(strings.t('home_error_loading'))),
                data: (messages) {
                  if (messages.isEmpty) {
                    return Center(child: Text(strings.t('messages_empty_title')));
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.all(14),
                    itemCount: messages.length,
                    itemBuilder: (context, i) => _MessageBubble(
                      message: messages[i],
                      isMine: user != null && messages[i].senderId == user.id,
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      decoration: InputDecoration(
                        hintText: strings.t('conversation_input_hint'),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final MessageModel message;
  final bool isMine;
  const _MessageBubble({required this.message, required this.isMine});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isMine ? scheme.primary : scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          message.message ?? '',
          style: TextStyle(color: isMine ? scheme.onPrimary : scheme.onSurface),
        ),
      ),
    );
  }
}
