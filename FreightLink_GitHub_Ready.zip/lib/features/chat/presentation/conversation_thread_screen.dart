import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/presence/online_users.dart';
import '../../../core/theme/app_theme.dart';
import '../../../models/message_model.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import 'providers/chat_providers.dart';

/// Real-time message thread for one conversation — Supabase Realtime
/// via MessageRepository.watchConversation() (migration 0001 publishes
/// public.messages for exactly this). No polling, no fake delay.
class ConversationThreadScreen extends ConsumerStatefulWidget {
  final String conversationId;
  const ConversationThreadScreen({super.key, required this.conversationId});

  @override
  ConsumerState<ConversationThreadScreen> createState() => _ConversationThreadScreenState();
}

class _ConversationThreadScreenState extends ConsumerState<ConversationThreadScreen> {
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool _sending = false;

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  static String _initials(String? name) {
    final parts = (name ?? '').trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    final first = String.fromCharCode(parts.first.runes.first);
    final second = parts.length > 1 ? String.fromCharCode(parts[1].runes.first) : '';
    return (first + second).toUpperCase();
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    // The conversation row already carries both participant ids — the
    // receiver is whichever one of the two isn't me. Fetching the
    // conversation list provider's cached data avoids a network round
    // trip just to know who the other participant is.
    final conversations = ref.read(myConversationsProvider).value ?? [];
    final match = conversations.where((c) => c.conversation.id == widget.conversationId);
    if (match.isEmpty) return;
    final conv = match.first.conversation;
    final receiverId = conv.cargoOwnerId == user.id ? conv.carrierUserId : conv.cargoOwnerId;

    setState(() => _sending = true);
    try {
      await ref.read(messageRepositoryProvider).send(
            conversationId: widget.conversationId,
            senderId: user.id,
            receiverId: receiverId,
            message: text,
          );
      _inputCtrl.clear();
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final messagesAsync = ref.watch(conversationMessagesProvider(widget.conversationId));

    // Whenever messages addressed to me are on screen and still unread,
    // mark them read (clears the tab badge, turns the sender's ticks).
    ref.listen<AsyncValue<List<MessageModel>>>(conversationMessagesProvider(widget.conversationId), (_, next) {
      final me = ref.read(currentUserProvider);
      final list = next.valueOrNull;
      if (me == null || list == null) return;
      if (list.any((m) => m.receiverId == me.id && m.readAt == null)) {
        ref.read(messageRepositoryProvider).markConversationRead(conversationId: widget.conversationId, userId: me.id);
      }
    });

    // The other participant: name + live online status in the header.
    final conversations = ref.watch(myConversationsProvider).valueOrNull ?? const <ConversationWithCargo>[];
    final match = conversations.where((c) => c.conversation.id == widget.conversationId);
    String? otherId;
    if (user != null && match.isNotEmpty) {
      final conv = match.first.conversation;
      otherId = conv.cargoOwnerId == user.id ? conv.carrierUserId : conv.cargoOwnerId;
    }
    final otherName = otherId == null ? null : ref.watch(userDisplayNameProvider(otherId)).valueOrNull;
    final otherOnline = otherId != null && ref.watch(isUserOnlineProvider(otherId));

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: otherId == null
            ? Text(strings.t('nav_messages'))
            : Row(
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      CircleAvatar(
                        radius: 19,
                        backgroundColor: AppColors.cardAlt,
                        child: Text(
                          _initials(otherName),
                          style: AppFonts.display(size: 16, color: AppColors.text),
                        ),
                      ),
                      Positioned(
                        right: -1,
                        bottom: -1,
                        child: Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: otherOnline ? AppColors.online : AppColors.textSoft,
                            shape: BoxShape.circle,
                            border: Border.all(color: AppColors.hero, width: 2),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(otherName ?? strings.t('nav_messages'),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.text)),
                        Text(
                          strings.t(otherOnline ? 'chat_online' : 'chat_offline'),
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: otherOnline ? AppColors.online : AppColors.textSoft,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: messagesAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => Center(child: Text(strings.t('home_error_loading'))),
                data: (messages) {
                  if (messages.isEmpty) {
                    return Center(child: Text(strings.t('messages_empty_title')));
                  }
                  // WhatsApp-style: oldest at the top, newest at the
                  // bottom, view anchored to the bottom. Sort here
                  // rather than trusting the stream's order (Supabase
                  // stream .order() defaults to DESCENDING, which is
                  // why the thread used to read upside-down). With
                  // `reverse: true` the list starts at the bottom and
                  // new messages appear there without manual scrolling,
                  // so index 0 = newest.
                  final sorted = [...messages]..sort((a, b) => a.createdAt.compareTo(b.createdAt));
                  return ListView.builder(
                    controller: _scrollCtrl,
                    reverse: true,
                    padding: const EdgeInsets.all(14),
                    itemCount: sorted.length,
                    itemBuilder: (context, i) {
                      final m = sorted[sorted.length - 1 - i];
                      return _MessageBubble(
                        message: m,
                        isMine: user != null && m.senderId == user.id,
                      );
                    },
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      decoration: InputDecoration(
                        hintText: strings.t('conversation_input_hint'),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final MessageModel message;
  final bool isMine;
  const _MessageBubble({required this.message, required this.isMine});

  static String _hhmm(DateTime t) {
    final l = t.toLocal();
    return '${l.hour.toString().padLeft(2, '0')}:${l.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          // Approved design: my messages orange, theirs a dark card with
          // a hairline border; the tail corner points to the sender.
          color: isMine ? AppColors.myBubble : AppColors.card,
          border: isMine ? null : Border.all(color: AppColors.line),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(isMine ? 14 : 4),
            bottomRight: Radius.circular(isMine ? 4 : 14),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              message.message ?? '',
              style: TextStyle(color: isMine ? Colors.white : AppColors.text, fontSize: 14.5),
            ),
            const SizedBox(height: 2),
            // Send time (HH:mm, device local time) and, on my own
            // messages, WhatsApp-style ticks: ✓ sent, ✓✓ read.
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _hhmm(message.createdAt),
                  style: TextStyle(
                    fontSize: 11,
                    color: isMine ? Colors.white.withValues(alpha: 0.75) : AppColors.textSoft,
                  ),
                ),
                if (isMine) ...[
                  const SizedBox(width: 4),
                  Icon(
                    message.readAt != null ? Icons.done_all : Icons.done,
                    size: 14,
                    color: message.readAt != null ? const Color(0xFF9FF3EA) : Colors.white.withValues(alpha: 0.75),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
