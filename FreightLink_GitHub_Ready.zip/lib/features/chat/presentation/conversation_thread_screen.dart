import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/presence/online_users.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../repositories/profile_repository.dart';
import '../../../models/message_model.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import 'package:url_launcher/url_launcher.dart';
import 'providers/chat_providers.dart';
import 'widgets/attachment_view.dart';
import 'widgets/call_options.dart';
import 'widgets/chat_input_bar.dart';
import 'widgets/location_message.dart';

/// Real-time message thread for one conversation — Supabase Realtime
/// via MessageRepository.watchConversation() (migration 0001 publishes
/// public.messages for exactly this). No polling, no fake delay.
class ConversationThreadScreen extends ConsumerStatefulWidget {
  final String conversationId;
  const ConversationThreadScreen({super.key, required this.conversationId});

  @override
  ConsumerState<ConversationThreadScreen> createState() => _ConversationThreadScreenState();
}

class _ConversationThreadScreenState extends ConsumerState<ConversationThreadScreen> {
  final _scrollCtrl = ScrollController();

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  /// "14:05" today, "dünən 22:10" yesterday, otherwise "5 Okt 14:05".
  static String _lastSeen(DateTime t, AppStrings strings) {
    final l = t.toLocal();
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final hm = '${two(l.hour)}:${two(l.minute)}';
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(l.year, l.month, l.day);
    if (day == today) return hm;
    if (day == today.subtract(const Duration(days: 1))) return '${strings.t('chat_yesterday')} $hm';
    return '${two(l.day)}.${two(l.month)} $hm';
  }

  static String _initials(String? name) {
    final parts = (name ?? '').trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    final first = String.fromCharCode(parts.first.runes.first);
    final second = parts.length > 1 ? String.fromCharCode(parts[1].runes.first) : '';
    return (first + second).toUpperCase();
  }

  /// The other participant, from the conversation row itself (fetched by
  /// id — NOT from the conversation list, which can be stale right after
  /// a chat was created; that was why some messages were silently lost).
  Future<({String me, String other})> _participants() async {
    final user = ref.read(currentUserProvider);
    if (user == null) throw StateError('not_signed_in');
    var conv = ref.read(conversationByIdProvider(widget.conversationId)).valueOrNull;
    conv ??= await ref.read(conversationByIdProvider(widget.conversationId).future);
    if (conv == null) throw StateError('conversation_not_found');
    if (user.id != conv.cargoOwnerId && user.id != conv.carrierUserId) {
      throw StateError('not_a_participant');
    }
    return (me: user.id, other: conv.otherParticipant(user.id));
  }

  // Errors are thrown on purpose: ChatInputBar keeps the text and shows
  // "Not sent" instead of failing silently.
  Future<void> _sendText(String text) async {
    final p = await _participants();
    await ref.read(messageRepositoryProvider).send(
          conversationId: widget.conversationId,
          senderId: p.me,
          receiverId: p.other,
          message: text,
        );
  }

  Future<void> _sendAttachment({
    required Uint8List bytes,
    required String type,
    required String fileName,
    String? contentType,
    int? audioDurationMs,
  }) async {
    final p = await _participants();
    await ref.read(messageRepositoryProvider).sendAttachment(
          conversationId: widget.conversationId,
          senderId: p.me,
          receiverId: p.other,
          bytes: bytes,
          type: type,
          fileName: fileName,
          contentType: contentType,
          audioDurationMs: audioDurationMs,
        );
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final messagesAsync = ref.watch(conversationMessagesProvider(widget.conversationId));

    // Whenever messages addressed to me are on screen and still unread,
    // mark them read (clears the tab badge, turns the sender's ticks).
    ref.listen<AsyncValue<List<MessageModel>>>(conversationMessagesProvider(widget.conversationId), (_, next) {
      final me = ref.read(currentUserProvider);
      final list = next.valueOrNull;
      if (me == null || list == null) return;
      if (list.any((m) => m.receiverId == me.id && m.readAt == null)) {
        ref.read(messageRepositoryProvider).markConversationRead(conversationId: widget.conversationId, userId: me.id);
      }
    });

    // The other participant: name + live online status in the header.
    final conv = ref.watch(conversationByIdProvider(widget.conversationId)).valueOrNull;
    final String? otherId = (user != null && conv != null) ? conv.otherParticipant(user.id) : null;
    final otherProfile = otherId == null ? null : ref.watch(publicProfileProvider(otherId)).valueOrNull;
    final otherName = otherProfile?.fullName;
    final otherOnline = otherId != null && ref.watch(isUserOnlineProvider(otherId));

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        actions: [
          if (otherId != null)
            IconButton(
              tooltip: strings.t('chat_call'),
              icon: const Icon(Icons.call_outlined),
              onPressed: () async {
                // The other person's phone is released by the server only
                // when there is a reason (e.g. they have written to you) —
                // RPC get_user_contact, migration 0019. Fetched on tap.
                final messenger = ScaffoldMessenger.of(context);
                String? phone;
                try {
                  phone = (await ref.read(profileRepositoryProvider).contact(otherId)).phone;
                } catch (_) {
                  messenger.showSnackBar(SnackBar(content: Text(strings.t('error_generic'))));
                  return;
                }
                if (!context.mounted) return;
                if (phone == null || phone.trim().isEmpty) {
                  messenger.showSnackBar(SnackBar(content: Text(strings.t('chat_no_phone'))));
                  return;
                }
                showCallOptions(context, strings, phone.trim());
              },
            ),
          const SizedBox(width: 4),
        ],
        title: otherId == null
            ? Text(strings.t('nav_messages'))
            : InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => context.push('/user/$otherId'),
                child: Row(
                  children: [
                    UserAvatar(imageUrl: otherProfile?.avatarUrl, initials: _initials(otherName), online: otherOnline),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(otherName ?? strings.t('nav_messages'),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.text)),
                              ),
                              if (otherProfile?.isVerified == true) ...[
                                const SizedBox(width: 4),
                                const VerifiedTick(),
                              ],
                            ],
                          ),
                          Text(
                            otherOnline
                                ? strings.t('chat_online')
                                : (otherProfile?.lastSeenAt != null
                                    ? strings.t('chat_last_seen', {'time': _lastSeen(otherProfile!.lastSeenAt!, strings)})
                                    : strings.t('chat_offline')),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: otherOnline ? AppColors.online : AppColors.textSoft,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: messagesAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => Center(child: Text(strings.t('home_error_loading'))),
                data: (messages) {
                  if (messages.isEmpty) {
                    return Center(child: Text(strings.t('messages_empty_title')));
                  }
                  // WhatsApp-style: oldest at the top, newest at the
                  // bottom, view anchored to the bottom. Sort here
                  // rather than trusting the stream's order (Supabase
                  // stream .order() defaults to DESCENDING, which is
                  // why the thread used to read upside-down). With
                  // `reverse: true` the list starts at the bottom and
                  // new messages appear there without manual scrolling,
                  // so index 0 = newest.
                  final sorted = [...messages]..sort((a, b) => a.createdAt.compareTo(b.createdAt));
                  return ListView.builder(
                    controller: _scrollCtrl,
                    reverse: true,
                    padding: const EdgeInsets.all(14),
                    itemCount: sorted.length,
                    itemBuilder: (context, i) {
                      final m = sorted[sorted.length - 1 - i];
                      return _MessageBubble(
                        message: m,
                        isMine: user != null && m.senderId == user.id,
                        strings: strings,
                      );
                    },
                  );
                },
              ),
            ),
            ChatInputBar(
              strings: strings,
              onSendText: _sendText,
              onSendAttachment: _sendAttachment,
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final MessageModel message;
  final bool isMine;
  final AppStrings strings;
  const _MessageBubble({required this.message, required this.isMine, required this.strings});

  static bool _isBareLocation(String text) {
    final loc = ChatLocation.parse(text);
    if (loc == null) return false;
    final rest = text.replaceAll(loc.url, '').replaceAll('📍', '').trim();
    return rest.isEmpty;
  }

  static String _hhmm(DateTime t) {
    final l = t.toLocal();
    return '${l.hour.toString().padLeft(2, '0')}:${l.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          // Approved design: my messages orange, theirs a dark card with
          // a hairline border; the tail corner points to the sender.
          color: isMine ? AppColors.myBubble : AppColors.card,
          border: isMine ? null : Border.all(color: AppColors.line),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(isMine ? 14 : 4),
            bottomRight: Radius.circular(isMine ? 4 : 14),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (message.hasAttachment)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: AttachmentView(message: message, isMine: isMine, strings: strings),
              ),
            if (ChatLocation.parse(message.message) case final loc?)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: LocationCard(location: loc, isMine: isMine, strings: strings),
              ),
            // Our own "📍 <link>" messages are fully represented by the
            // card; any other text (incl. pasted links with a caption)
            // is still shown.
            if ((message.message ?? '').isNotEmpty && !_isBareLocation(message.message!))
              Text(
                message.message!,
                style: TextStyle(color: isMine ? Colors.white : AppColors.text, fontSize: 14.5),
              ),
            const SizedBox(height: 2),
            // Send time (HH:mm, device local time) and, on my own
            // messages, WhatsApp-style ticks: ✓ sent, ✓✓ read.
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _hhmm(message.createdAt),
                  style: TextStyle(
                    fontSize: 11,
                    color: isMine ? Colors.white.withValues(alpha: 0.75) : AppColors.textSoft,
                  ),
                ),
                if (isMine) ...[
                  const SizedBox(width: 4),
                  Icon(
                    message.readAt != null ? Icons.done_all : Icons.done,
                    size: 14,
                    color: message.readAt != null ? const Color(0xFF9FF3EA) : Colors.white.withValues(alpha: 0.75),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
