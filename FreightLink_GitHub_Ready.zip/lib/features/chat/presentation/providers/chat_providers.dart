import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../../core/config/supabase_config.dart';
import '../../../../models/cargo_model.dart';
import '../../../../models/message_model.dart';
import '../../data/message_repository_impl.dart';
import '../../domain/message_repository.dart';

final messageRepositoryProvider = Provider<MessageRepository>((ref) => MessageRepositoryImpl());

class ConversationWithCargo {
  final ConversationModel conversation;
  final CargoModel? cargo;
  const ConversationWithCargo({required this.conversation, required this.cargo});
}

/// Same two-query pattern as ShipmentWithCargo (see
/// repositories/shipment_repository.dart) and for the same reason: the
/// conversation list needs the cargo route to be a useful label, and
/// that lives on `cargo`, not `conversations`.
final myConversationsProvider = StreamProvider<List<ConversationWithCargo>>((ref) {
  ref.watch(currentUserIdProvider); // re-subscribe when the signed-in account changes
  final repo = ref.watch(messageRepositoryProvider);
  // Live: a carrier's new chat shows up in the owner's list at once.
  return repo.watchMyConversations().asyncMap((list) async {
    final conversations = [...list]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    if (conversations.isEmpty) return <ConversationWithCargo>[];
    final cargoIds = conversations.map((c) => c.cargoId).whereType<String>().toSet().toList();
    final cargoById = <String, CargoModel>{};
    if (cargoIds.isNotEmpty) {
      final rows = await SupabaseConfig.client.from('cargo').select().inFilter('id', cargoIds);
      for (final row in (rows as List)) {
        cargoById[row['id'] as String] = CargoModel.fromJson(row);
      }
    }
    return conversations
        .map((c) => ConversationWithCargo(conversation: c, cargo: c.cargoId != null ? cargoById[c.cargoId] : null))
        .toList();
  });
});

/// One conversation by id, fetched directly — the chat screen must not
/// depend on the (possibly stale) list to know who it is talking to.
final conversationByIdProvider = FutureProvider.family<ConversationModel?, String>((ref, id) {
  ref.watch(currentUserIdProvider);
  return ref.watch(messageRepositoryProvider).fetchConversation(id);
});

final conversationMessagesProvider = StreamProvider.family<List<MessageModel>, String>((ref, conversationId) {
  ref.watch(currentUserIdProvider); // re-fetch when the signed-in account changes
  return ref.watch(messageRepositoryProvider).watchConversation(conversationId);
});

/// Number of unread messages addressed to the signed-in user, live
/// (drives the badge on the Messages tab). 0 when signed out.
final unreadCountProvider = StreamProvider<int>((ref) {
  final uid = ref.watch(currentUserIdProvider);
  if (uid == null) return Stream.value(0);
  return ref
      .watch(messageRepositoryProvider)
      .watchReceived(uid)
      .map((list) => list.where((m) => m.readAt == null).length);
});

/// Signed (1 h) link for a private chat attachment, cached per path.
final attachmentUrlProvider = FutureProvider.family<String, String>((ref, path) {
  return ref.watch(messageRepositoryProvider).signedUrl(path);
});

/// Unread messages per conversation id (badges on the conversation list).
final unreadByConversationProvider = StreamProvider<Map<String, int>>((ref) {
  final uid = ref.watch(currentUserIdProvider);
  if (uid == null) return Stream.value(const <String, int>{});
  return ref.watch(messageRepositoryProvider).watchReceived(uid).map((list) {
    final counts = <String, int>{};
    for (final m in list) {
      if (m.readAt == null) counts[m.conversationId] = (counts[m.conversationId] ?? 0) + 1;
    }
    return counts;
  });
});
