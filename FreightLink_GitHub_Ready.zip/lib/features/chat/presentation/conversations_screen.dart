import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/constants/countries.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../../core/presence/online_users.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../repositories/profile_repository.dart';
import 'providers/chat_providers.dart';

/// Bottom-nav "Messages" tab — real conversation list via
/// MessageRepository.fetchMyConversations() (RLS-scoped to the
/// signed-in user's own conversations).
class ConversationsScreen extends ConsumerWidget {
  const ConversationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final conversationsAsync = ref.watch(myConversationsProvider);
    final localeCode = ref.watch(currentLocaleProvider).languageCode;
    final unreadByConversation = ref.watch(unreadByConversationProvider).valueOrNull ?? const <String, int>{};

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('messages_placeholder_title'))),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(myConversationsProvider),
        child: conversationsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => Center(child: Text(strings.t('home_error_loading'))),
          data: (items) {
            if (items.isEmpty) {
              return LayoutBuilder(
                builder: (context, constraints) => SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: constraints.maxHeight),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.chat_bubble_outline, size: 44, color: Theme.of(context).colorScheme.outline),
                          const SizedBox(height: 12),
                          Text(strings.t('messages_empty_title')),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (context, i) {
                final item = items[i];
                final cargo = item.cargo;
                final iAmOwner = user != null && user.id == item.conversation.cargoOwnerId;
                final subtitleKey = iAmOwner ? 'conversation_with_carrier' : 'conversation_with_owner';
                final otherId = iAmOwner ? item.conversation.carrierUserId : item.conversation.cargoOwnerId;
                final route = cargo == null
                    ? strings.t(subtitleKey)
                    : '${Countries.label(cargo.pickupCountry, localeCode)} → ${Countries.label(cargo.destinationCountry, localeCode)}';
                return _ConversationTile(
                  otherUserId: otherId,
                  route: route,
                  roleLabel: strings.t(subtitleKey),
                  unread: unreadByConversation[item.conversation.id] ?? 0,
                  onTap: () => context.push('/messages/${item.conversation.id}'),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

/// One conversation: the other party's photo (with online dot), the name
/// they registered with (company or person) + verified tick, the route
/// underneath, and an unread counter.
class _ConversationTile extends ConsumerWidget {
  final String otherUserId;
  final String route;
  final String roleLabel;
  final int unread;
  final VoidCallback onTap;
  const _ConversationTile({
    required this.otherUserId,
    required this.route,
    required this.roleLabel,
    required this.unread,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(publicProfileProvider(otherUserId)).valueOrNull;
    final online = ref.watch(isUserOnlineProvider(otherUserId));
    final name = (profile?.fullName.isNotEmpty ?? false) ? profile!.fullName : roleLabel;

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              UserAvatar(
                imageUrl: profile?.avatarUrl,
                initials: profile?.initials ?? '?',
                radius: 24,
                online: online,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.text),
                          ),
                        ),
                        if (profile?.isVerified == true) ...[
                          const SizedBox(width: 4),
                          const VerifiedTick(),
                        ],
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      route,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13.5, color: AppColors.textSoft),
                    ),
                  ],
                ),
              ),
              if (unread > 0)
                Container(
                  constraints: const BoxConstraints(minWidth: 24),
                  height: 24,
                  padding: const EdgeInsets.symmetric(horizontal: 7),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: AppColors.accentFill, borderRadius: BorderRadius.circular(12)),
                  child: Text(
                    unread > 99 ? '99+' : '$unread',
                    style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
