import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/constants/countries.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import 'providers/chat_providers.dart';

/// Bottom-nav "Messages" tab — real conversation list via
/// MessageRepository.fetchMyConversations() (RLS-scoped to the
/// signed-in user's own conversations).
class ConversationsScreen extends ConsumerWidget {
  const ConversationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final conversationsAsync = ref.watch(myConversationsProvider);
    final localeCode = ref.watch(currentLocaleProvider).languageCode;

    return Scaffold(
      appBar: AppBar(title: Text(strings.t('messages_placeholder_title'))),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(myConversationsProvider),
        child: conversationsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => Center(child: Text(strings.t('home_error_loading'))),
          data: (items) {
            if (items.isEmpty) {
              return LayoutBuilder(
                builder: (context, constraints) => SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: constraints.maxHeight),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.chat_bubble_outline, size: 44, color: Theme.of(context).colorScheme.outline),
                          const SizedBox(height: 12),
                          Text(strings.t('messages_empty_title')),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (context, i) {
                final item = items[i];
                final cargo = item.cargo;
                final iAmOwner = user != null && user.id == item.conversation.cargoOwnerId;
                final subtitleKey = iAmOwner ? 'conversation_with_carrier' : 'conversation_with_owner';
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.chat_bubble_outline)),
                    title: Text(cargo == null ? strings.t(subtitleKey) : '${Countries.label(cargo.pickupCountry, localeCode)} → ${Countries.label(cargo.destinationCountry, localeCode)}'),
                    subtitle: Text(strings.t(subtitleKey)),
                    onTap: () => context.push('/messages/${item.conversation.id}'),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
