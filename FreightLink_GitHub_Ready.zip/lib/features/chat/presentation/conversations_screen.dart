import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/constants/countries.dart';
import '../../auth/presentation/providers/auth_providers.dart';
import '../../../core/presence/online_users.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/user_avatar.dart';
import '../../../models/group_models.dart';
import '../../../repositories/profile_repository.dart';
import '../data/group_repository.dart';
import 'providers/chat_providers.dart';
import 'providers/group_providers.dart';

/// Bottom-nav "Messages" tab: search box on top, then groups and chats
/// (newest activity first). Typing a name filters the list AND shows
/// matching people from the whole platform, so you can start a direct
/// chat with anyone.
class ConversationsScreen extends ConsumerStatefulWidget {
  const ConversationsScreen({super.key});

  @override
  ConsumerState<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _Entry {
  final DateTime time;
  final Widget tile;
  const _Entry(this.time, this.tile);
}

class _ConversationsScreenState extends ConsumerState<ConversationsScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  String? _opening; // user id whose direct chat is being opened

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  bool _matches(String text) => _query.isEmpty || text.toLowerCase().contains(_query.toLowerCase());

  Future<void> _openDirect(UserHit u, AppStrings strings) async {
    if (_opening != null) return;
    setState(() => _opening = u.id);
    try {
      final conv = await ref.read(groupRepositoryProvider).openDirect(u.id);
      ref.invalidate(conversationByIdProvider(conv.id));
      if (mounted) context.push('/messages/${conv.id}');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(strings.t('chat_open_failed'))));
      }
    } finally {
      if (mounted) setState(() => _opening = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(stringsProvider);
    final user = ref.watch(currentUserProvider);
    final conversationsAsync = ref.watch(myConversationsProvider);
    final localeCode = ref.watch(currentLocaleProvider).languageCode;
    final unreadByConversation = ref.watch(unreadByConversationProvider).valueOrNull ?? const <String, int>{};
    final groups = ref.watch(myGroupsProvider).valueOrNull ?? const <ChatGroup>[];
    final groupUnread = ref.watch(groupUnreadProvider);
    final groupActivity = ref.watch(groupLastActivityProvider);

    final entries = <_Entry>[];

    // Groups
    for (final g in groups) {
      if (!_matches(g.name)) continue;
      entries.add(_Entry(
        groupActivity[g.id] ?? g.createdAt,
        _GroupTile(
          group: g,
          unread: groupUnread[g.id] ?? 0,
          label: strings.t('chat_group'),
          onTap: () => context.push('/messages/group/${g.id}'),
        ),
      ));
    }

    // 1-to-1 chats — ONE row per person. Every load has its own chat with
    // that person (plus an optional direct chat); they are grouped here and
    // a tap opens ONE thread with all of them (ConversationThreadScreen).
    final items = conversationsAsync.valueOrNull ?? const <ConversationWithCargo>[];
    final chatPartnerIds = <String>{};
    final byPartner = <String, List<ConversationWithCargo>>{};
    for (final item in items) {
      final otherId = user == null ? item.conversation.carrierUserId : item.conversation.otherParticipant(user.id);
      chatPartnerIds.add(otherId);
      (byPartner[otherId] ??= []).add(item);
    }
    String routeOf(ConversationWithCargo item) {
      final cargo = item.conversation.cargoId == null ? null : item.cargo;
      final iAmOwner = user != null && user.id == item.conversation.cargoOwnerId;
      final subtitleKey = item.conversation.cargoId == null
          ? 'chat_direct'
          : (iAmOwner ? 'conversation_with_carrier' : 'conversation_with_owner');
      return cargo == null
          ? strings.t(subtitleKey)
          : '${Countries.label(cargo.pickupCountry, localeCode)} → ${Countries.label(cargo.destinationCountry, localeCode)}';
    }

    for (final e in byPartner.entries) {
      final otherId = e.key;
      final convs = [...e.value]..sort((a, b) => b.conversation.createdAt.compareTo(a.conversation.createdAt));
      final latest = convs.first;
      final iAmOwner = user != null && user.id == latest.conversation.cargoOwnerId;
      final subtitleKey = latest.conversation.cargoId == null
          ? 'chat_direct'
          : (iAmOwner ? 'conversation_with_carrier' : 'conversation_with_owner');
      final routes = convs.map(routeOf).toList();
      final route = convs.length == 1 ? routes.first : '${routes.first} · ${strings.t('chat_n_chats', {'n': '${convs.length}'})}';
      final name = ref.watch(publicProfileProvider(otherId)).valueOrNull?.fullName ?? '';
      if (!_matches('$name ${routes.join(' ')}')) continue;
      final unread = convs.fold<int>(0, (sum, c) => sum + (unreadByConversation[c.conversation.id] ?? 0));
      entries.add(_Entry(
        latest.conversation.createdAt,
        _ConversationTile(
          otherUserId: otherId,
          route: route,
          roleLabel: strings.t(subtitleKey),
          unread: unread,
          // One thread per person: all load chats + the direct chat together.
          onTap: () => context.push('/messages/with/$otherId'),
        ),
      ));
    }
    entries.sort((a, b) => b.time.compareTo(a.time));

    // People search (whole platform) while typing
    final people = _query.length >= 2 ? ref.watch(userSearchProvider(_query)) : null;

    return Scaffold(
      appBar: AppBar(
        title: Text(strings.t('messages_placeholder_title')),
        actions: [
          IconButton(
            tooltip: strings.t('chat_new_group'),
            icon: const Icon(Icons.group_add_outlined),
            onPressed: () => context.push('/messages/new-group'),
          ),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _query = v.trim()),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                isDense: true,
                prefixIcon: const Icon(Icons.search),
                hintText: strings.t('chat_search_hint'),
                suffixIcon: _query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() => _query = '');
                        },
                      ),
              ),
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(myConversationsProvider);
          ref.invalidate(myGroupsProvider);
        },
        child: conversationsAsync.isLoading && entries.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(14),
                children: [
                  if (conversationsAsync.hasError && entries.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(24),
                      child: Center(child: Text(strings.t('home_error_loading'))),
                    ),
                  if (entries.isEmpty && _query.isEmpty && !conversationsAsync.hasError)
                    Padding(
                      padding: const EdgeInsets.only(top: 80),
                      child: Column(
                        children: [
                          Icon(Icons.chat_bubble_outline, size: 44, color: Theme.of(context).colorScheme.outline),
                          const SizedBox(height: 12),
                          Text(strings.t('messages_empty_title')),
                          const SizedBox(height: 6),
                          Text(strings.t('chat_empty_hint'),
                              textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSoft)),
                        ],
                      ),
                    ),
                  for (final e in entries) Padding(padding: const EdgeInsets.only(bottom: 6), child: e.tile),
                  if (people != null) ...[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(4, 14, 4, 8),
                      child: Text(strings.t('chat_people').toUpperCase(),
                          style: const TextStyle(color: AppColors.textSoft, fontSize: 12, letterSpacing: 1.1, fontWeight: FontWeight.w700)),
                    ),
                    people.when(
                      loading: () => const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
                      error: (_, __) => Text(strings.t('home_error_loading')),
                      data: (list) {
                        final others = list.where((u) => !chatPartnerIds.contains(u.id)).toList();
                        if (others.isEmpty) {
                          return Padding(
                            padding: const EdgeInsets.all(8),
                            child: Text(strings.t('chat_search_nobody'), style: const TextStyle(color: AppColors.textSoft)),
                          );
                        }
                        return Column(
                          children: [
                            for (final u in others)
                              Card(
                                child: ListTile(
                                  leading: UserAvatar(imageUrl: u.avatarUrl, initials: u.initials, online: ref.watch(isUserOnlineProvider(u.id))),
                                  title: Text(u.fullName, maxLines: 1, overflow: TextOverflow.ellipsis),
                                  subtitle: u.role == null ? null : Text(strings.t('role_label_${u.role}')),
                                  trailing: _opening == u.id
                                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                      : const Icon(Icons.chat_bubble_outline, color: AppColors.accent),
                                  onTap: () => _openDirect(u, strings),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                  ],
                ],
              ),
      ),
    );
  }
}

class _UnreadBadge extends StatelessWidget {
  final int count;
  const _UnreadBadge(this.count);

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 24),
      height: 24,
      padding: const EdgeInsets.symmetric(horizontal: 7),
      alignment: Alignment.center,
      decoration: BoxDecoration(color: AppColors.accentFill, borderRadius: BorderRadius.circular(12)),
      child: Text(
        count > 99 ? '99+' : '$count',
        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _GroupTile extends StatelessWidget {
  final ChatGroup group;
  final int unread;
  final String label;
  final VoidCallback onTap;
  const _GroupTile({required this.group, required this.unread, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              const CircleAvatar(
                radius: 24,
                backgroundColor: AppColors.routeSoft,
                child: Icon(Icons.groups_2_outlined, color: AppColors.route),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(group.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.text)),
                    const SizedBox(height: 3),
                    Text(label, style: const TextStyle(fontSize: 13.5, color: AppColors.textSoft)),
                  ],
                ),
              ),
              if (unread > 0) _UnreadBadge(unread),
            ],
          ),
        ),
      ),
    );
  }
}

/// One conversation: the other party's photo (with online dot), the name
/// they registered with (company or person) + verified tick, the route
/// underneath, and an unread counter.
class _ConversationTile extends ConsumerWidget {
  final String otherUserId;
  final String route;
  final String roleLabel;
  final int unread;
  final VoidCallback onTap;
  const _ConversationTile({
    required this.otherUserId,
    required this.route,
    required this.roleLabel,
    required this.unread,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(publicProfileProvider(otherUserId)).valueOrNull;
    final online = ref.watch(isUserOnlineProvider(otherUserId));
    final name = (profile?.fullName.isNotEmpty ?? false) ? profile!.fullName : roleLabel;

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              InkWell(
                customBorder: const CircleBorder(),
                onTap: () => context.push('/user/$otherUserId'),
                child: UserAvatar(
                  imageUrl: profile?.avatarUrl,
                  initials: profile?.initials ?? '?',
                  radius: 24,
                  online: online,
                ),
              ),
              const SizedBox(width: 12),
              // Name / route: tapping opens the chat (the avatar opens the profile).
              Expanded(
                child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.text),
                              ),
                            ),
                            if (profile?.isVerified == true) ...[
                              const SizedBox(width: 4),
                              const VerifiedTick(),
                            ],
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          route,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13.5, color: AppColors.textSoft),
                        ),
                      ],
                    ),
                ),
              ),
              if (unread > 0) _UnreadBadge(unread),
            ],
          ),
        ),
      ),
    );
  }
}
