import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../models/ad_models.dart';
import '../../ads/data/ads_repository.dart';
import '../../ads/presentation/ad_creative_view.dart';
import '../../ads/presentation/ads_providers.dart';
import 'admin_widgets.dart';

/// Centre-crops any picture to 4.5:1 and draws it at exactly 1350×300 (PNG).
Future<Uint8List> cropToAdBanner(ui.Image img) async {
  final w = img.width.toDouble(), h = img.height.toDouble();
  const target = AdBannerSpec.ratio;
  final src = w / h > target
      ? Rect.fromLTWH((w - h * target) / 2, 0, h * target, h)
      : Rect.fromLTWH(0, (h - w / target) / 2, w, w / target);
  final recorder = ui.PictureRecorder();
  final canvas = Canvas(recorder);
  canvas.drawImageRect(img, src, Rect.fromLTWH(0, 0, AdBannerSpec.width.toDouble(), AdBannerSpec.height.toDouble()),
      Paint()..filterQuality = FilterQuality.high);
  final out = await recorder.endRecording().toImage(AdBannerSpec.width, AdBannerSpec.height);
  final data = await out.toByteData(format: ui.ImageByteFormat.png);
  return data!.buffer.asUint8List();
}

/// "Ana səhifə reklamları": one switch for the ads in the home load list.
/// OFF (default): no ads and no empty ad slots. ON: only paid ads inside
/// their dates. Orders and payments are never touched.
class HomeAdsSwitchCard extends ConsumerStatefulWidget {
  const HomeAdsSwitchCard({super.key});

  @override
  ConsumerState<HomeAdsSwitchCard> createState() => _HomeAdsSwitchCardState();
}

class _HomeAdsSwitchCardState extends ConsumerState<HomeAdsSwitchCard> {
  bool _busy = false;

  Future<void> _set(bool on) async {
    final ok = await confirmAction(
      context,
      on ? 'Reklamları aktiv et' : 'Reklamları deaktiv et',
      on
          ? 'Ana səhifədə yalnız ödənişi təsdiqlənmiş və vaxtı çatmış reklamlar görünəcək.'
          : 'Ana səhifədə heç bir reklam və boş reklam sahəsi görünməyəcək. Sifarişlər və ödənişlər dəyişmir.',
    );
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final done = await runAdmin(context, () => ref.read(adsRepositoryProvider).setHomeAdsEnabled(on),
        success: on ? 'Reklamlar aktivdir' : 'Reklamlar deaktivdir');
    if (done) {
      ref.invalidate(homeAdsEnabledProvider);
      ref.invalidate(liveAdsProvider);
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final on = ref.watch(homeAdsEnabledProvider);
    final value = on.valueOrNull ?? false;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
      decoration: BoxDecoration(
        color: value ? AppColors.online.withValues(alpha: 0.10) : AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: value ? AppColors.online.withValues(alpha: 0.5) : AppColors.line),
      ),
      child: Row(
        children: [
          Icon(value ? Icons.campaign : Icons.campaign_outlined, color: value ? AppColors.online : AppColors.textSoft),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Ana səhifə reklamları', style: TextStyle(fontWeight: FontWeight.w700)),
                Text(value ? 'Aktivdir — ödənişli reklamlar yük siyahısında görünür' : 'Deaktivdir — ana səhifədə reklam görünmür',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSoft)),
              ],
            ),
          ),
          if (on.isLoading || _busy)
            const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
          else
            Switch(value: value, onChanged: (v) => _set(v)),
        ],
      ),
    );
  }
}

/// Admin → Reklamlar → Şablonlar.
class AdminTemplatesPanel extends ConsumerWidget {
  const AdminTemplatesPanel({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminAdTemplatesProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Müştəri "Reklam yarat"-da aktiv şablonlardan birini seçir, mətni yazır və rəngi seçir. '
          'Şəkil ölçüsü 1350×300 px. Dəyişiklik artıq verilmiş sifarişlərə təsir etmir.',
          style: TextStyle(color: AppColors.textSoft, fontSize: 12.5, height: 1.35),
        ),
        const SizedBox(height: 10),
        Align(
          alignment: Alignment.centerLeft,
          child: FilledButton.icon(
            onPressed: () => _open(context, ref, null),
            icon: const Icon(Icons.add),
            label: const Text('Şablon əlavə et'),
          ),
        ),
        const SizedBox(height: 12),
        async.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => EmptyNote('Yüklənmədi — 0021 SQL işə salınıb? ($e)'),
          data: (list) => list.isEmpty
              ? const EmptyNote('Hələ şablon yoxdur')
              : Column(
                  children: [
                    for (final t in list)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          clipBehavior: Clip.antiAlias,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              AdCreativeView(creative: t.preview()),
                              ListTile(
                                title: Text(t.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                                subtitle: Text('${t.fields.length} mətn sahəsi · ${t.colors.length} rəng'),
                                trailing: Switch(
                                  value: t.isActive,
                                  onChanged: (v) async {
                                    if (await runAdmin(context, () => ref.read(adsRepositoryProvider).setTemplateActive(t.id, v),
                                        success: v ? 'Şablon aktivdir' : 'Şablon deaktivdir')) {
                                      ref.invalidate(adminAdTemplatesProvider);
                                      ref.invalidate(adTemplatesProvider);
                                    }
                                  },
                                ),
                                onTap: () => _open(context, ref, t),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
        ),
      ],
    );
  }

  Future<void> _open(BuildContext context, WidgetRef ref, AdTemplate? t) async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => AdminTemplateEditor(template: t)));
    if (saved == true) {
      ref.invalidate(adminAdTemplatesProvider);
      ref.invalidate(adTemplatesProvider);
    }
  }
}

/// Create / edit one template: background image, text fields (position,
/// size, length, alignment, bold) and the colours customers may choose.
class AdminTemplateEditor extends ConsumerStatefulWidget {
  final AdTemplate? template;
  const AdminTemplateEditor({super.key, this.template});

  @override
  ConsumerState<AdminTemplateEditor> createState() => _AdminTemplateEditorState();
}

class _AdminTemplateEditorState extends ConsumerState<AdminTemplateEditor> {
  static const _presetColors = ['#FFFFFF', '#000000', '#FFCC00', '#FF6B33', '#3BA3FF', '#4ADE80', '#E11D48', '#1E293B'];

  late final _name = TextEditingController(text: widget.template?.name ?? '');
  late String? _imageUrl = widget.template?.imageUrl;
  late List<AdTemplateField> _fields = List.of(widget.template?.fields ??
      const [
        AdTemplateField(key: 'title', label: 'Başlıq', x: 0.05, y: 0.18, w: 0.6, size: 72, max: 30, bold: true),
        AdTemplateField(key: 'subtitle', label: 'Alt mətn', x: 0.05, y: 0.55, w: 0.6, size: 40, max: 50),
      ]);
  late List<String> _colors = List.of(widget.template?.colors ?? const ['#FFFFFF', '#FFCC00']);
  late bool _active = widget.template?.isActive ?? false;
  int _selected = 0;
  int _previewColor = 0;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    setState(() => _error = null);
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jpg', 'jpeg', 'png', 'webp'], withData: true);
    final f = res?.files.single;
    final bytes = f?.bytes;
    if (f == null || bytes == null) return;
    setState(() => _busy = true);
    try {
      final codec = await ui.instantiateImageCodec(bytes);
      final img = (await codec.getNextFrame()).image;
      if (!mounted) return;
      if (img.width < 600 || img.height < 130) {
        setState(() => _error = 'Şəkil çox kiçikdir: ${img.width}×${img.height}. Ən az 600×130 px.');
        return;
      }
      final exact = img.width == AdBannerSpec.width && img.height == AdBannerSpec.height;
      final upload = exact ? bytes : await cropToAdBanner(img);
      final url = await ref.read(adsRepositoryProvider).uploadTemplateImage(upload, exact ? (f.extension ?? 'jpg') : 'png');
      if (mounted) setState(() => _imageUrl = url);
    } catch (e) {
      if (mounted) setState(() => _error = 'Şəkil yüklənmədi: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _addField() {
    if (_fields.length >= 6) return;
    var n = _fields.length + 1;
    while (_fields.any((f) => f.key == 'text$n')) {
      n++;
    }
    setState(() {
      _fields = [..._fields, AdTemplateField(key: 'text$n', label: 'Mətn $n', x: 0.05, y: 0.4, w: 0.5, size: 40, max: 40)];
      _selected = _fields.length - 1;
    });
  }

  void _update(AdTemplateField f) => setState(() => _fields = [for (var i = 0; i < _fields.length; i++) i == _selected ? f : _fields[i]]);

  Future<void> _addColor() async {
    final c = await askText(context, 'Rəng kodu', hint: '#RRGGBB, məs. #FF6B33');
    if (c == null) return;
    final v = c.trim().toUpperCase();
    if (!RegExp(r'^#[0-9A-F]{6}$').hasMatch(v)) {
      setState(() => _error = 'Rəng #RRGGBB formatında olmalıdır.');
      return;
    }
    if (!_colors.contains(v) && _colors.length < 12) setState(() => _colors = [..._colors, v]);
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _imageUrl == null || _fields.isEmpty || _colors.isEmpty) {
      setState(() => _error = 'Ad, şəkil, ən az 1 mətn sahəsi və 1 rəng lazımdır.');
      return;
    }
    if (_fields.any((f) => f.label.trim().isEmpty)) {
      setState(() => _error = 'Hər mətn sahəsinin adı olmalıdır.');
      return;
    }
    setState(() => _busy = true);
    final ok = await runAdmin(
      context,
      () => ref.read(adsRepositoryProvider).saveTemplate(
            id: widget.template?.id,
            name: _name.text.trim(),
            imageUrl: _imageUrl!,
            fields: _fields,
            colors: _colors,
            active: _active,
            sort: widget.template?.sort ?? 100,
          ),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final f = _fields.isEmpty ? null : _fields[_selected.clamp(0, _fields.length - 1)];
    final preview = AdCreative(
      imageUrl: _imageUrl ?? '',
      fields: _fields,
      texts: {for (final x in _fields) x.key: x.defaultText.isEmpty ? x.label : x.defaultText},
      color: _colors.isEmpty ? '#FFFFFF' : _colors[_previewColor.clamp(0, _colors.length - 1)],
    );

    Widget slider(String label, double value, double min, double max, ValueChanged<double> onChanged, {String? shown}) => Row(
          children: [
            SizedBox(width: 92, child: Text(label, style: const TextStyle(fontSize: 12.5, color: AppColors.textSoft))),
            Expanded(child: Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged)),
            SizedBox(width: 44, child: Text(shown ?? value.toStringAsFixed(2), style: const TextStyle(fontSize: 12))),
          ],
        );

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.template == null ? 'Yeni şablon' : 'Şablon: ${widget.template!.name}'),
        actions: [TextButton(onPressed: _busy ? null : _save, child: const Text('Yadda saxla'))],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 60),
        children: [
          AdCreativeView(creative: preview, radius: BorderRadius.circular(12), showPlaceholders: true),
          const SizedBox(height: 8),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: _busy ? null : _pickImage,
                icon: _busy
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.image_outlined),
                label: Text(_imageUrl == null ? 'Şəkil yüklə (1350×300)' : 'Şəkli dəyiş'),
              ),
              const Spacer(),
              const Text('Aktiv', style: TextStyle(fontSize: 13)),
              Switch(value: _active, onChanged: (v) => setState(() => _active = v)),
            ],
          ),
          TextField(controller: _name, maxLength: 80, decoration: const InputDecoration(labelText: 'Şablonun adı')),
          const SectionTitle('Rənglər (müştəri seçir)'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              for (var i = 0; i < _colors.length; i++)
                GestureDetector(
                  onTap: () => setState(() => _previewColor = i),
                  onLongPress: _colors.length <= 1
                      ? null
                      : () => setState(() {
                            _colors = [..._colors]..removeAt(i);
                            _previewColor = 0;
                          }),
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: Color(adColorValue(_colors[i])),
                      shape: BoxShape.circle,
                      border: Border.all(color: i == _previewColor ? AppColors.accent : AppColors.line, width: i == _previewColor ? 3 : 1),
                    ),
                  ),
                ),
              for (final p in _presetColors.where((c) => !_colors.contains(c)))
                InkWell(
                  onTap: _colors.length >= 12 ? null : () => setState(() => _colors = [..._colors, p]),
                  child: Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      color: Color(adColorValue(p)),
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.line),
                    ),
                    child: const Icon(Icons.add, size: 14, color: Colors.grey),
                  ),
                ),
              IconButton(onPressed: _addColor, tooltip: 'Kodla rəng əlavə et', icon: const Icon(Icons.colorize)),
            ],
          ),
          const Text('Toxun: önizləmədə bax · Basıb saxla: sil · Kiçik dairələr: əlavə et',
              style: TextStyle(fontSize: 11.5, color: AppColors.textSoft)),
          SectionTitle('Mətn sahələri (${_fields.length}/6)',
              trailing: TextButton.icon(onPressed: _fields.length >= 6 ? null : _addField, icon: const Icon(Icons.add), label: const Text('Əlavə et'))),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (var i = 0; i < _fields.length; i++)
                ChoiceChip(label: Text(_fields[i].label.isEmpty ? _fields[i].key : _fields[i].label), selected: i == _selected,
                    onSelected: (_) => setState(() => _selected = i)),
            ],
          ),
          if (f != null) ...[
            const SizedBox(height: 10),
            TextFormField(
              key: ValueKey('label-${f.key}'),
              initialValue: f.label,
              maxLength: 40,
              decoration: const InputDecoration(labelText: 'Sahənin adı (müştəri görür)'),
              onChanged: (v) => _update(f.copyWith(label: v)),
            ),
            TextFormField(
              key: ValueKey('default-${f.key}'),
              initialValue: f.defaultText,
              maxLength: 120,
              decoration: const InputDecoration(labelText: 'Hazır mətn (istəyə bağlı)'),
              onChanged: (v) => _update(f.copyWith(defaultText: v)),
            ),
            slider('Soldan', f.x, 0, 0.95, (v) => _update(f.copyWith(x: v))),
            slider('Yuxarıdan', f.y, 0, 0.95, (v) => _update(f.copyWith(y: v))),
            slider('En', f.w, 0.05, 1, (v) => _update(f.copyWith(w: v))),
            slider('Şrift', f.size, 10, 200, (v) => _update(f.copyWith(size: v)), shown: '${f.size.round()}'),
            slider('Maks. simvol', f.max.toDouble(), 1, 120, (v) => _update(f.copyWith(max: v.round())), shown: '${f.max}'),
            Row(
              children: [
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'left', icon: Icon(Icons.format_align_left)),
                    ButtonSegment(value: 'center', icon: Icon(Icons.format_align_center)),
                    ButtonSegment(value: 'right', icon: Icon(Icons.format_align_right)),
                  ],
                  selected: {f.align},
                  onSelectionChanged: (v) => _update(f.copyWith(align: v.first)),
                ),
                const Spacer(),
                const Text('Qalın', style: TextStyle(fontSize: 13)),
                Switch(value: f.bold, onChanged: (v) => _update(f.copyWith(bold: v))),
              ],
            ),
            if (_fields.length > 1)
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  style: TextButton.styleFrom(foregroundColor: AppColors.danger),
                  onPressed: () => setState(() {
                    _fields = [..._fields]..removeAt(_selected);
                    _selected = 0;
                  }),
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Bu sahəni sil'),
                ),
              ),
          ],
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: AppColors.danger)),
          ],
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : _save, child: const Text('Yadda saxla')),
        ],
      ),
    );
  }
}
