/// Advertising (migration 0015).
class AdPackage {
  final String id;
  final String name;
  final int days;
  final double price;
  final String currency;
  final bool isActive;
  final int sort;

  const AdPackage({
    required this.id,
    required this.name,
    required this.days,
    required this.price,
    required this.currency,
    required this.isActive,
    required this.sort,
  });

  factory AdPackage.fromJson(Map<String, dynamic> j) => AdPackage(
        id: j['id'] as String,
        name: (j['name'] as String?) ?? '',
        days: (j['days'] as num?)?.toInt() ?? 0,
        price: (j['price'] as num?)?.toDouble() ?? 0,
        currency: (j['currency'] as String?) ?? 'USD',
        isActive: j['is_active'] == true,
        sort: (j['sort'] as num?)?.toInt() ?? 0,
      );
}

class AdOrder {
  final String id;
  final String advertiserId;
  final String? packageId;
  final String packageName;
  final int days;
  final double price;
  final String currency;
  /// unpaid | submitted | paid | refunded
  final String paymentStatus;
  /// pending_payment | awaiting_approval | approved | rejected | active | expired | cancelled
  final String status;
  final String? customerNote;
  final String? paymentReference;
  final String? adminNote;
  final DateTime createdAt;

  const AdOrder({
    required this.id,
    required this.advertiserId,
    required this.packageId,
    required this.packageName,
    required this.days,
    required this.price,
    required this.currency,
    required this.paymentStatus,
    required this.status,
    this.customerNote,
    this.paymentReference,
    this.adminNote,
    required this.createdAt,
  });

  factory AdOrder.fromJson(Map<String, dynamic> j) => AdOrder(
        id: j['id'] as String,
        advertiserId: j['advertiser_id'] as String,
        packageId: j['package_id'] as String?,
        packageName: (j['package_name'] as String?) ?? '',
        days: (j['days'] as num?)?.toInt() ?? 0,
        price: (j['price'] as num?)?.toDouble() ?? 0,
        currency: (j['currency'] as String?) ?? 'USD',
        paymentStatus: (j['payment_status'] as String?) ?? 'unpaid',
        status: (j['status'] as String?) ?? 'pending_payment',
        customerNote: j['customer_note'] as String?,
        paymentReference: j['payment_reference'] as String?,
        adminNote: j['admin_note'] as String?,
        createdAt: DateTime.tryParse('${j['created_at']}') ?? DateTime.now(),
      );
}

class Ad {
  final String id;
  final String? orderId;
  final String advertiserId;
  final String? title;
  final String imageUrl;
  final DateTime startsAt;
  final DateTime endsAt;
  final bool isActive;

  const Ad({
    required this.id,
    this.orderId,
    required this.advertiserId,
    this.title,
    required this.imageUrl,
    required this.startsAt,
    required this.endsAt,
    required this.isActive,
  });

  bool get isLive {
    final now = DateTime.now();
    return isActive && !now.isBefore(startsAt) && now.isBefore(endsAt);
  }

  factory Ad.fromJson(Map<String, dynamic> j) => Ad(
        id: j['id'] as String,
        orderId: j['order_id'] as String?,
        advertiserId: j['advertiser_id'] as String,
        title: j['title'] as String?,
        imageUrl: (j['image_url'] as String?) ?? '',
        startsAt: DateTime.tryParse('${j['starts_at']}')?.toLocal() ?? DateTime.now(),
        endsAt: DateTime.tryParse('${j['ends_at']}')?.toLocal() ?? DateTime.now(),
        isActive: j['is_active'] == true,
      );
}

/// Banner format every ad image must have (width : height = 3 : 1).
class AdBannerSpec {
  AdBannerSpec._();
  static const int width = 1200;
  static const int height = 400;
  static const double ratio = width / height;
  static const int minWidth = 900;
  /// Allowed deviation from the exact ratio (5 %).
  static const double tolerance = 0.05;
}
