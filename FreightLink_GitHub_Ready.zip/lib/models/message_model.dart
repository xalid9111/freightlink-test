class ConversationModel {
  final String id;
  final String? cargoId;
  final String? shipmentId;
  final String cargoOwnerId;
  final String carrierUserId;

  const ConversationModel({
    required this.id,
    this.cargoId,
    this.shipmentId,
    required this.cargoOwnerId,
    required this.carrierUserId,
  });

  factory ConversationModel.fromJson(Map<String, dynamic> j) => ConversationModel(
        id: j['id'] as String,
        cargoId: j['cargo_id'] as String?,
        shipmentId: j['shipment_id'] as String?,
        cargoOwnerId: j['cargo_owner_id'] as String,
        carrierUserId: j['carrier_user_id'] as String,
      );
}

class MessageModel {
  final String id;
  final String conversationId;
  final String senderId;
  final String receiverId;
  final String? message;
  final String? attachmentId;
  final DateTime? readAt;
  final DateTime createdAt;

  const MessageModel({
    required this.id,
    required this.conversationId,
    required this.senderId,
    required this.receiverId,
    this.message,
    this.attachmentId,
    this.readAt,
    required this.createdAt,
  });

  factory MessageModel.fromJson(Map<String, dynamic> j) => MessageModel(
        id: j['id'] as String,
        conversationId: j['conversation_id'] as String,
        senderId: j['sender_id'] as String,
        receiverId: j['receiver_id'] as String,
        message: j['message'] as String?,
        attachmentId: j['attachment_id'] as String?,
        readAt: j['read_at'] != null ? DateTime.parse(j['read_at']) : null,
        createdAt: DateTime.parse(j['created_at'] as String),
      );
}
