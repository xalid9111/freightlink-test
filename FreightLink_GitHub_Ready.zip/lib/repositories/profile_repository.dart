import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/config/supabase_config.dart';
import '../features/auth/presentation/providers/auth_providers.dart';

/// What any signed-in user may see about another user (public.users is
/// readable by signed-in users — RLS users_select_all). Fields added by
/// migration 0009 are read defensively, so the app keeps working even
/// before that migration has been run.
class PublicProfile {
  final String id;
  final String fullName;
  final String? phone;
  final String? avatarUrl;
  final DateTime? lastSeenAt;
  final bool isVerified;
  final bool isEarlyMember;

  const PublicProfile({
    required this.id,
    required this.fullName,
    this.phone,
    this.avatarUrl,
    this.lastSeenAt,
    this.isVerified = false,
    this.isEarlyMember = false,
  });

  factory PublicProfile.fromJson(Map<String, dynamic> j) {
    final seen = j['last_seen_at'];
    return PublicProfile(
      id: j['id'] as String,
      fullName: (j['full_name'] as String?) ?? '',
      phone: j['phone'] as String?,
      avatarUrl: j['avatar_url'] as String?,
      lastSeenAt: seen is String ? DateTime.tryParse(seen) : null,
      isVerified: j['is_verified'] == true,
      isEarlyMember: j['is_early_member'] == true,
    );
  }

  /// "XX" style initials for avatar placeholders.
  String get initials {
    final parts = fullName.trim().split(' ').where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    final a = String.fromCharCode(parts.first.runes.first);
    final b = parts.length > 1 ? String.fromCharCode(parts[1].runes.first) : '';
    return (a + b).toUpperCase();
  }
}

class ProfileRepository {
  final SupabaseClient _client = SupabaseConfig.client;

  Future<PublicProfile?> fetch(String userId) async {
    // select('*') rather than a column list: a not-yet-run migration
    // then just means missing keys, not a failed query.
    final row = await _client.from('users').select('*').eq('id', userId).maybeSingle();
    return row == null ? null : PublicProfile.fromJson(row);
  }

  /// Records "now" as the signed-in user's last activity (own row only —
  /// RLS users_update_self). Silently ignored if migration 0009 hasn't
  /// added the column yet.
  Future<void> touchLastSeen() async {
    final uid = _client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      await _client.from('users').update({'last_seen_at': DateTime.now().toUtc().toIso8601String()}).eq('id', uid);
    } catch (_) {}
  }

  /// Renames the signed-in user (company or person name shown to others).
  Future<void> updateName(String name) async {
    final uid = _client.auth.currentUser?.id;
    if (uid == null) throw StateError('not signed in');
    await _client.from('users').update({'full_name': name.trim()}).eq('id', uid);
  }

  /// Saves the signed-in user's phone (E.164, e.g. +994501234567) on
  /// their own row (RLS users_update_self). Throws [PhoneTakenException]
  /// if another account already uses it (users.phone is unique).
  Future<void> updatePhone(String phone) async {
    final uid = _client.auth.currentUser?.id;
    if (uid == null) throw StateError('not signed in');
    try {
      await _client.from('users').update({'phone': phone}).eq('id', uid);
    } on PostgrestException catch (e) {
      if (e.code == '23505') throw const PhoneTakenException();
      rethrow;
    }
  }

  /// Uploads a profile photo to storage bucket "avatars" under the
  /// user's own folder (policy avatars_insert_own, migration 0009) and
  /// stores its public URL on the user row. Returns the new URL.
  Future<String> uploadAvatar(Uint8List bytes, {String? contentType}) async {
    final uid = _client.auth.currentUser?.id;
    if (uid == null) throw StateError('not signed in');
    final path = '$uid/avatar';
    await _client.storage.from('avatars').uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(upsert: true, contentType: contentType ?? 'image/jpeg'),
        );
    // Cache-buster so every client shows the new photo immediately.
    final url = '${_client.storage.from('avatars').getPublicUrl(path)}?v=${DateTime.now().millisecondsSinceEpoch}';
    await _client.from('users').update({'avatar_url': url}).eq('id', uid);
    return url;
  }
}

final profileRepositoryProvider = Provider<ProfileRepository>((ref) => ProfileRepository());

final publicProfileProvider = FutureProvider.family<PublicProfile?, String>((ref, userId) {
  ref.watch(currentUserIdProvider);
  return ref.watch(profileRepositoryProvider).fetch(userId);
});

class PhoneTakenException implements Exception {
  const PhoneTakenException();
}
