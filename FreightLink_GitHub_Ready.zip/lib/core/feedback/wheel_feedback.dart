import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'wheel_feedback_stub.dart' if (dart.library.js_interop) 'wheel_feedback_web.dart' as platform;

/// User choices for the cargo-feed wheel (Profile → Feed settings).
class WheelSettings {
  final bool sound;
  final bool haptic;
  const WheelSettings({this.sound = true, this.haptic = true});
  WheelSettings copyWith({bool? sound, bool? haptic}) =>
      WheelSettings(sound: sound ?? this.sound, haptic: haptic ?? this.haptic);
}

class WheelSettingsController extends StateNotifier<WheelSettings> {
  static const _kSound = 'wheel_sound';
  static const _kHaptic = 'wheel_haptic';

  WheelSettingsController() : super(const WheelSettings()) {
    _restore();
  }

  Future<void> _restore() async {
    try {
      final p = await SharedPreferences.getInstance();
      state = WheelSettings(sound: p.getBool(_kSound) ?? true, haptic: p.getBool(_kHaptic) ?? true);
    } catch (_) {}
    platform.platformEnableSound(state.sound);
  }

  Future<void> setSound(bool on) async {
    state = state.copyWith(sound: on);
    platform.platformEnableSound(on);
    try {
      (await SharedPreferences.getInstance()).setBool(_kSound, on);
    } catch (_) {}
  }

  Future<void> setHaptic(bool on) async {
    state = state.copyWith(haptic: on);
    try {
      (await SharedPreferences.getInstance()).setBool(_kHaptic, on);
    } catch (_) {}
  }
}

final wheelSettingsProvider =
    StateNotifierProvider<WheelSettingsController, WheelSettings>((ref) => WheelSettingsController());

/// One "detent" of the wheel: a short tick and/or a light haptic,
/// depending on the user's settings. Never throws.
void wheelDetent(WheelSettings s, {required bool isAd}) {
  if (s.sound) platform.platformTick(isAd);
  if (s.haptic) platform.platformHaptic(isAd);
}
