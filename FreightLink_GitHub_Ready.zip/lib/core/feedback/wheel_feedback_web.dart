import 'dart:js_interop';

/// Web / PWA implementation. The functions live in web/index.html
/// (flWheelEnable / flWheelTick / flWheelHaptic): the tick is synthesised
/// with Web Audio (no audio file at all, ~25 ms), haptics use
/// navigator.vibrate where available. If the page is an older cached
/// version without them, calls fail silently.
@JS('flWheelEnable')
external void _enable(bool on);

@JS('flWheelTick')
external void _tick(int kind);

@JS('flWheelHaptic')
external void _haptic(int kind);

void platformEnableSound(bool on) {
  try {
    _enable(on);
  } catch (_) {}
}

void platformTick(bool isAd) {
  try {
    _tick(isAd ? 1 : 0);
  } catch (_) {}
}

void platformHaptic(bool isAd) {
  try {
    _haptic(isAd ? 1 : 0);
  } catch (_) {}
}
