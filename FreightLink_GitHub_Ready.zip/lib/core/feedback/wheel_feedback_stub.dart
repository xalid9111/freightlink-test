import 'package:flutter/services.dart';

/// Native (iOS / Android app) implementation: system haptics + the
/// platform's own short click sound. Every call is fire-and-forget and
/// swallows errors — the wheel never depends on it.
void platformEnableSound(bool on) {}

void platformTick(bool isAd) {
  try {
    SystemSound.play(SystemSoundType.click);
  } catch (_) {}
}

void platformHaptic(bool isAd) {
  try {
    if (isAd) {
      HapticFeedback.mediumImpact();
    } else {
      HapticFeedback.selectionClick();
    }
  } catch (_) {}
}
