void playMessageSound() {}

void showMessageNotification(String title, String body) {}
