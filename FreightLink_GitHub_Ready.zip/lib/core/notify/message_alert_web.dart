import 'dart:js_interop';

@JS('flMsgAlert.play')
external void _play();

@JS('flMsgAlert.notify')
external void _notify(JSString title, JSString body);

void playMessageSound() {
  try {
    _play();
  } catch (_) {}
}

void showMessageNotification(String title, String body) {
  try {
    _notify(title.toJS, body.toJS);
  } catch (_) {}
}
