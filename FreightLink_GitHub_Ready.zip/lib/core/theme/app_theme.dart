import 'package:flutter/material.dart';

/// Design tokens: dark navy / white / light gray with a single blue
/// accent, per the product brief. Keep this the only place colors
/// and type scale are defined so screens stay visually consistent.
class AppColors {
  AppColors._();
  static const navy = Color(0xFF10151F);
  static const navySoft = Color(0xFF2B3648);
  static const surface = Color(0xFFF6F7F9);
  static const surfaceAlt = Color(0xFFECEEF2);
  static const line = Color(0xFFDCE0E7);
  static const accentBlue = Color(0xFF1E56B0);
  static const success = Color(0xFF0E7C7B);
  static const danger = Color(0xFFD23B3B);
}

class AppTheme {
  AppTheme._();

  static ThemeData get light {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.surface,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.accentBlue,
        brightness: Brightness.light,
        surface: AppColors.surface,
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: AppColors.line),
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: AppColors.navy,
        elevation: 0,
      ),
    );
  }

  static ThemeData get dark {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.navy,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.accentBlue,
        brightness: Brightness.dark,
      ),
    );
  }
}
