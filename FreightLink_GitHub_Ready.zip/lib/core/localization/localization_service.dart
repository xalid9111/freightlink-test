import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/widgets.dart' show Locale;
import 'app_strings.dart';

/// Loads every supported language's JSON file ONCE at app startup (see
/// main.dart) into memory. After that, reading a translation is a plain
/// synchronous map lookup (via stringsProvider) — no per-screen
/// FutureBuilder/loading-flicker for something this small and static.
class LocalizationService {
  LocalizationService._();

  // Exactly the four languages required by the product spec. (Phase 1
  // originally scaffolded five, including Georgian, for a later brief
  // that asked for it — this list now matches the current, explicit
  // "four languages" requirement. assets/i18n/ka.json was removed
  // since nothing references it anymore.)
  static const List<Locale> supportedLocales = [
    Locale('az'),
    Locale('tr'),
    Locale('ru'),
    Locale('en'),
  ];

  static const Locale fallbackLocale = Locale('az');

  static Future<Map<Locale, AppStrings>> loadAll() async {
    final result = <Locale, AppStrings>{};
    for (final locale in supportedLocales) {
      final raw = await rootBundle.loadString('assets/i18n/${locale.languageCode}.json');
      final decoded = json.decode(raw) as Map<String, dynamic>;
      result[locale] = AppStrings(decoded.map((k, v) => MapEntry(k, v.toString())));
    }
    return result;
  }
}
