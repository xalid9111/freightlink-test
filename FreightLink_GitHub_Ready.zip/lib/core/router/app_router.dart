import 'package:flutter/widgets.dart' show GlobalKey, NavigatorState;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/register_screen.dart';
import '../../features/auth/presentation/role_select_screen.dart';
import '../../features/auth/presentation/profile_screen.dart';
import '../../features/cargo/presentation/cargo_marketplace_screen.dart';
import '../../features/cargo/presentation/cargo_quick_form.dart';
import '../../features/cargo/presentation/my_cargo_screen.dart';
import '../../features/cargo/presentation/cargo_detail_screen.dart';
import '../../features/cargo/presentation/search_screen.dart';
import '../../features/shipment/presentation/shipments_screen.dart';
import '../../features/chat/presentation/conversations_screen.dart';
import '../../features/chat/presentation/conversation_thread_screen.dart';
import '../../features/chat/presentation/group_thread_screen.dart';
import '../../features/chat/presentation/new_group_screen.dart';
import '../../features/admin/presentation/admin_shell.dart';
import '../../features/ads/presentation/advertise_screen.dart';
import '../../features/ads/presentation/public_profile_screen.dart';
import '../config/supabase_config.dart';
import 'go_router_refresh_stream.dart';
import 'main_shell.dart';

/// Phase 1 shipped `appRouter` as a bare top-level GoRouter. Phase 3
/// promoted it to a Riverpod provider for auth-aware redirects. A later
/// pass added the bottom-navigation shell. This pass adds the real
/// screens under each branch: cargo detail (/cargo/:id) nests under
/// the Home branch (keeps the bottom nav visible, which makes sense
/// for a detail view you'll want to back out of quickly); cargo create
/// (/cargo/create) is attached to the root navigator instead, so it
/// opens full-screen without the bottom nav bar — standard go_router
/// pattern for "this route should cover the whole shell", used here
/// because a multi-section form benefits from the extra vertical space
/// and doesn't want stray tab-switching mid-fill-out. A conversation
/// thread (/messages/:id) nests under the Messages branch like cargo
/// detail. Nothing about the shell structure or redirect logic changed.
final _rootNavigatorKey = GlobalKey<NavigatorState>();

final appRouterProvider = Provider<GoRouter>((ref) {
  final authStream = SupabaseConfig.client.auth.onAuthStateChange;

  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/login',
    refreshListenable: GoRouterRefreshStream(authStream),
    redirect: (context, state) {
      final signedIn = SupabaseConfig.client.auth.currentSession != null;
      final loc = state.matchedLocation;
      final onAuthScreen = loc == '/login' || loc == '/role-select' || loc.startsWith('/register');

      // Remember where the user was going (e.g. /admin opened from a
      // bookmark) and send them back there right after login.
      if (!signedIn && !onAuthScreen) {
        return Uri(path: '/login', queryParameters: {'from': state.uri.toString()}).toString();
      }
      if (signedIn && onAuthScreen) {
        final from = state.uri.queryParameters['from'];
        if (from != null && from.length > 1 && from.startsWith('/') && !from.startsWith('/login')) return from;
        return '/cargo';
      }
      return null; // no redirect needed
    },
    routes: [
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: '/role-select',
        builder: (context, state) => const RoleSelectScreen(),
      ),
      GoRoute(
        path: '/register',
        builder: (context, state) {
          final role = state.uri.queryParameters['role'] ?? 'cargo_owner';
          return RegisterScreen(role: role);
        },
      ),
      GoRoute(
        path: '/cargo/create',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const CargoQuickForm(),
      ),
      GoRoute(
        path: '/cargo-edit/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => CargoQuickForm(editCargoId: state.pathParameters['id']!),
      ),
      // Admin Panel — separate full-screen area, outside the bottom-nav
      // shell. Access is enforced on the server (is_admin()).
      GoRoute(
        path: '/admin',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const AdminShell(section: 'dashboard'),
      ),
      GoRoute(
        path: '/admin/:section',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => AdminShell(section: state.pathParameters['section']!),
      ),
      // Full-screen copies of detail/chat pages, opened from pages that
      // themselves sit above the tab shell (My loads, profiles, new group):
      // pushing a tab route from there would land UNDER the current page.
      GoRoute(
        path: '/load/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => CargoDetailScreen(cargoId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: '/chat/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => ConversationThreadScreen(conversationId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: '/chat-group/:gid',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => GroupThreadScreen(groupId: state.pathParameters['gid']!),
      ),
      GoRoute(
        path: '/user/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => PublicProfileScreen(userId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: '/ads',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const AdvertiseScreen(),
      ),
      GoRoute(
        path: '/my-cargo',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const MyCargoScreen(),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(
              path: '/cargo',
              builder: (context, state) => const CargoMarketplaceScreen(),
              routes: [
                GoRoute(
                  path: ':id',
                  builder: (context, state) => CargoDetailScreen(cargoId: state.pathParameters['id']!),
                ),
              ],
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/search', builder: (context, state) => const SearchScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/shipments', builder: (context, state) => const ShipmentsScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: '/messages',
              builder: (context, state) => const ConversationsScreen(),
              routes: [
                // Specific paths first — ':id' would otherwise match them.
                GoRoute(
                  path: 'new-group',
                  parentNavigatorKey: _rootNavigatorKey,
                  builder: (context, state) => const NewGroupScreen(),
                ),
                GoRoute(
                  path: 'group/:gid',
                  builder: (context, state) => GroupThreadScreen(groupId: state.pathParameters['gid']!),
                ),
                GoRoute(
                  path: ':id',
                  builder: (context, state) => ConversationThreadScreen(conversationId: state.pathParameters['id']!),
                ),
              ],
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/profile', builder: (context, state) => const ProfileScreen()),
          ]),
        ],
      ),
    ],
  );
});
