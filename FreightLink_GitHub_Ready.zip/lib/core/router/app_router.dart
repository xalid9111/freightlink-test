import 'package:flutter/widgets.dart' show GlobalKey, NavigatorState;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/register_screen.dart';
import '../../features/auth/presentation/role_select_screen.dart';
import '../../features/auth/presentation/profile_screen.dart';
import '../../features/cargo/presentation/cargo_marketplace_screen.dart';
import '../../features/cargo/presentation/cargo_create_screen.dart';
import '../../features/cargo/presentation/cargo_detail_screen.dart';
import '../../features/cargo/presentation/search_screen.dart';
import '../../features/shipment/presentation/shipments_screen.dart';
import '../../features/chat/presentation/conversations_screen.dart';
import '../../features/chat/presentation/conversation_thread_screen.dart';
import '../config/supabase_config.dart';
import 'go_router_refresh_stream.dart';
import 'main_shell.dart';

/// Phase 1 shipped `appRouter` as a bare top-level GoRouter. Phase 3
/// promoted it to a Riverpod provider for auth-aware redirects. A later
/// pass added the bottom-navigation shell. This pass adds the real
/// screens under each branch: cargo detail (/cargo/:id) nests under
/// the Home branch (keeps the bottom nav visible, which makes sense
/// for a detail view you'll want to back out of quickly); cargo create
/// (/cargo/create) is attached to the root navigator instead, so it
/// opens full-screen without the bottom nav bar — standard go_router
/// pattern for "this route should cover the whole shell", used here
/// because a multi-section form benefits from the extra vertical space
/// and doesn't want stray tab-switching mid-fill-out. A conversation
/// thread (/messages/:id) nests under the Messages branch like cargo
/// detail. Nothing about the shell structure or redirect logic changed.
final _rootNavigatorKey = GlobalKey<NavigatorState>();

final appRouterProvider = Provider<GoRouter>((ref) {
  final authStream = SupabaseConfig.client.auth.onAuthStateChange;

  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/login',
    refreshListenable: GoRouterRefreshStream(authStream),
    redirect: (context, state) {
      final signedIn = SupabaseConfig.client.auth.currentSession != null;
      final loc = state.matchedLocation;
      final onAuthScreen = loc == '/login' || loc == '/role-select' || loc.startsWith('/register');

      if (!signedIn && !onAuthScreen) return '/login';
      if (signedIn && onAuthScreen) return '/cargo';
      return null; // no redirect needed
    },
    routes: [
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: '/role-select',
        builder: (context, state) => const RoleSelectScreen(),
      ),
      GoRoute(
        path: '/register',
        builder: (context, state) {
          final role = state.uri.queryParameters['role'] ?? 'cargo_owner';
          return RegisterScreen(role: role);
        },
      ),
      GoRoute(
        path: '/cargo/create',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const CargoCreateScreen(),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(
              path: '/cargo',
              builder: (context, state) => const CargoMarketplaceScreen(),
              routes: [
                GoRoute(
                  path: ':id',
                  builder: (context, state) => CargoDetailScreen(cargoId: state.pathParameters['id']!),
                ),
              ],
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/search', builder: (context, state) => const SearchScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/shipments', builder: (context, state) => const ShipmentsScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: '/messages',
              builder: (context, state) => const ConversationsScreen(),
              routes: [
                GoRoute(
                  path: ':id',
                  builder: (context, state) => ConversationThreadScreen(conversationId: state.pathParameters['id']!),
                ),
              ],
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/profile', builder: (context, state) => const ProfileScreen()),
          ]),
        ],
      ),
    ],
  );
});
