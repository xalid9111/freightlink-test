import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../localization/locale_controller.dart';
import '../presence/online_users.dart';
import '../../features/chat/presentation/providers/chat_providers.dart';

/// Bottom navigation shell (brief §14): Home/Loads, Search, Shipments,
/// Messages, Profile — wraps the 5 authenticated tab branches. Uses
/// go_router's StatefulShellRoute so each tab keeps its own navigation
/// stack and scroll position when switching away and back, instead of
/// a plain IndexedStack hand-rolled in application code.
class MainShell extends ConsumerWidget {
  final StatefulNavigationShell navigationShell;
  const MainShell({super.key, required this.navigationShell});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    // Keeps this user's online presence active on every authenticated
    // screen (see core/presence/online_users.dart).
    ref.watch(onlineUsersProvider);
    final unread = ref.watch(unreadCountProvider).valueOrNull ?? 0;
    Widget withBadge(Widget icon) => Badge(
          isLabelVisible: unread > 0,
          label: Text(unread > 99 ? '99+' : '$unread'),
          child: icon,
        );
    return ResumeRefresher(
      child: Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: (index) => navigationShell.goBranch(
          index,
          // Tapping the already-selected tab resets that tab's stack to
          // its root instead of doing nothing — standard bottom-nav UX.
          initialLocation: index == navigationShell.currentIndex,
        ),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.local_shipping_outlined), selectedIcon: const Icon(Icons.local_shipping), label: strings.t('nav_home')),
          NavigationDestination(icon: const Icon(Icons.search_outlined), selectedIcon: const Icon(Icons.search), label: strings.t('nav_search')),
          NavigationDestination(icon: const Icon(Icons.receipt_long_outlined), selectedIcon: const Icon(Icons.receipt_long), label: strings.t('nav_shipments')),
          NavigationDestination(icon: withBadge(const Icon(Icons.chat_bubble_outline)), selectedIcon: withBadge(const Icon(Icons.chat_bubble)), label: strings.t('nav_messages')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: strings.t('nav_profile')),
        ],
      ),
    ),
    );
  }
}

/// After the app comes back from the background (iOS suspends Safari /
/// PWA tabs and drops their websocket) or the tab becomes visible again,
/// re-subscribe the chat streams so new messages show without a manual
/// refresh.
class ResumeRefresher extends ConsumerStatefulWidget {
  final Widget child;
  const ResumeRefresher({super.key, required this.child});

  @override
  ConsumerState<ResumeRefresher> createState() => _ResumeRefresherState();
}

class _ResumeRefresherState extends ConsumerState<ResumeRefresher> {
  AppLifecycleListener? _listener;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  void _refresh() {
    final now = DateTime.now();
    if (now.difference(_last) < const Duration(seconds: 2)) return; // show+resume fire together
    _last = now;
    ref.invalidate(myConversationsProvider);
    ref.invalidate(conversationMessagesProvider);
    ref.invalidate(conversationByIdProvider);
    ref.invalidate(unreadCountProvider);
    ref.invalidate(unreadByConversationProvider);
  }

  @override
  void initState() {
    super.initState();
    _listener = AppLifecycleListener(onResume: _refresh, onShow: _refresh);
  }

  @override
  void dispose() {
    _listener?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
