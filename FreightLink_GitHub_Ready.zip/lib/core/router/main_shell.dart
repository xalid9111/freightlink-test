import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../localization/locale_controller.dart';
import '../presence/online_users.dart';
import '../../features/chat/presentation/providers/chat_providers.dart';
import '../../features/chat/presentation/providers/group_providers.dart';
import '../../features/auth/presentation/providers/auth_providers.dart';
import '../../repositories/profile_repository.dart';
import '../theme/app_theme.dart';

/// Bottom navigation shell (brief §14): Home/Loads, Search, Shipments,
/// Messages, Profile — wraps the 5 authenticated tab branches. Uses
/// go_router's StatefulShellRoute so each tab keeps its own navigation
/// stack and scroll position when switching away and back, instead of
/// a plain IndexedStack hand-rolled in application code.
class MainShell extends ConsumerWidget {
  final StatefulNavigationShell navigationShell;
  const MainShell({super.key, required this.navigationShell});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(stringsProvider);
    // Keeps this user's online presence active on every authenticated
    // screen (see core/presence/online_users.dart).
    ref.watch(onlineUsersProvider);
    final unread = (ref.watch(unreadCountProvider).valueOrNull ?? 0) + ref.watch(groupUnreadTotalProvider);
    Widget withBadge(Widget icon) => Badge(
          isLabelVisible: unread > 0,
          label: Text(unread > 99 ? '99+' : '$unread'),
          child: icon,
        );
    // Every role (cargo owner, carrier, driver, admin) may post a load.
    const canPost = true;
    // Bar order: Loads · Add load · Services · Messages · Profile.
    const slots = [0, _addSlot, 5, 3, 4];
    return ResumeRefresher(
      child: Scaffold(
      body: Column(
        children: [
          const _RestrictedBanner(),
          Expanded(child: navigationShell),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        height: 64,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        // Bar slots map to shell branches (0 Loads, 5 Services, 3 Messages,
        // 4 Profile).
        // Search (branch 1) and Orders (branch 2) are hidden from the bar —
        // route search lives on the Loads page. The 2nd slot is an
        // "Add load" action (for every role) that opens the form
        // full-screen instead of switching tab.
        selectedIndex: () {
          final i = slots.indexOf(navigationShell.currentIndex);
          return i < 0 ? 0 : i;
        }(),
        onDestinationSelected: (tab) {
          final branch = slots[tab];
          if (branch == _addSlot) {
            context.push('/cargo/create');
            return;
          }
          navigationShell.goBranch(
            branch,
            // Tapping the already-selected tab resets that tab's stack to
            // its root instead of doing nothing — standard bottom-nav UX.
            initialLocation: branch == navigationShell.currentIndex,
          );
        },
        destinations: [
          NavigationDestination(icon: const Icon(Icons.local_shipping_outlined), selectedIcon: const Icon(Icons.local_shipping), label: strings.t('nav_home')),
          if (canPost)
            NavigationDestination(
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                decoration: BoxDecoration(color: AppColors.accentFill, borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.add, color: Colors.white),
              ),
              label: strings.t('nav_add_cargo'),
            ),
          NavigationDestination(
            icon: const Icon(Icons.home_repair_service_outlined),
            selectedIcon: const Icon(Icons.home_repair_service),
            label: strings.t('nav_services'),
          ),
          NavigationDestination(icon: withBadge(const Icon(Icons.chat_bubble_outline)), selectedIcon: withBadge(const Icon(Icons.chat_bubble)), label: strings.t('nav_messages')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: strings.t('nav_profile')),
        ],
      ),
    ),
    );
  }
}

/// After the app comes back from the background (iOS suspends Safari /
/// PWA tabs and drops their websocket) or the tab becomes visible again,
/// re-subscribe the chat streams so new messages show without a manual
/// refresh.
/// Marker for the "Add load" bar slot (not a shell branch).
const _addSlot = -1;

class ResumeRefresher extends ConsumerStatefulWidget {
  final Widget child;
  const ResumeRefresher({super.key, required this.child});

  @override
  ConsumerState<ResumeRefresher> createState() => _ResumeRefresherState();
}

class _ResumeRefresherState extends ConsumerState<ResumeRefresher> {
  AppLifecycleListener? _listener;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  void _refresh() {
    final now = DateTime.now();
    if (now.difference(_last) < const Duration(seconds: 2)) return; // show+resume fire together
    _last = now;
    ref.invalidate(myConversationsProvider);
    ref.invalidate(conversationMessagesProvider);
    ref.invalidate(conversationByIdProvider);
    ref.invalidate(unreadCountProvider);
    ref.invalidate(unreadByConversationProvider);
  }

  @override
  void initState() {
    super.initState();
    _listener = AppLifecycleListener(onResume: _refresh, onShow: _refresh);
  }

  @override
  void dispose() {
    _listener?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

/// Shown on every tab while an admin has blocked or deactivated this
/// account (migration 0012). The database already refuses new loads,
/// offers and messages; this only explains why.
class _RestrictedBanner extends ConsumerWidget {
  const _RestrictedBanner();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uid = ref.watch(currentUserIdProvider);
    if (uid == null) return const SizedBox.shrink();
    final p = ref.watch(publicProfileProvider(uid)).valueOrNull;
    if (p == null || !p.isRestricted) return const SizedBox.shrink();
    final strings = ref.watch(stringsProvider);
    final lines = <String>[
      p.isActive ? strings.t('account_blocked_banner') : strings.t('account_inactive_banner'),
      if (p.isActive && p.blockedUntil != null)
        strings.t('account_blocked_until', {
          'date': '${p.blockedUntil!.toLocal().day.toString().padLeft(2, '0')}.${p.blockedUntil!.toLocal().month.toString().padLeft(2, '0')}.${p.blockedUntil!.toLocal().year}',
        }),
      if (p.isActive && (p.blockReason ?? '').isNotEmpty) strings.t('account_blocked_reason', {'reason': p.blockReason!}),
    ];
    return Material(
      color: AppColors.urgentBg,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.block, color: AppColors.urgentFg, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(lines.join('\n'), style: const TextStyle(color: AppColors.urgentFg, fontSize: 13, height: 1.35)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
