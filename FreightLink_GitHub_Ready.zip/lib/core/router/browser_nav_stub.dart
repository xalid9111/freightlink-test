bool recentBrowserNavigation() => false;
