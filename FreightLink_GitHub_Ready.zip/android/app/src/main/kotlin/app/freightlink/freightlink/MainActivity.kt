package app.freightlink.freightlink

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
