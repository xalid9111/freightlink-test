# Ads: templates, receipt payments, home-feed switch (0021)

## Flow
1. **Admin → Reklamlar → Şablonlar**: upload a 1350×300 background (any photo is centre-cropped), define 1–6 text fields (position, width, font size, max length, alignment, bold, default text) and the colours customers may pick; activate / deactivate; edit any time (existing orders keep a snapshot).
2. **Customer → Profil → Reklam ver → Reklam yarat**: pick an active template, type the texts, pick a colour (live preview), destination (FreightLink profile or https link), countries / route, 5 / 15 / 30 days, start date → total from the admin's price → confirm.
3. Order gets a number (R-1001…), shows the amount, the order number to write in the transfer, and the bank / card details saved by the admin.
4. Customer uploads a photo of the receipt (private bucket `ad-receipts`) → status "Yoxlanılır". Nothing is marked paid automatically.
5. **Admin** sees order + receipt → "Ödəniş yoxlanıldı — təsdiqlə" creates the ad: starts 00:00 (Baku) on the chosen day (or now if that passed), ends exactly N days later; or "Rədd et" with a reason the customer sees.
6. "Sifarişlərim": Ödəniş gözlənilir → Yoxlanılır → Təsdiqləndi / Rədd edildi → Planlaşdırılıb → Aktivdir → Bitib.
7. **Ana səhifə reklamları** switch (Admin → Reklamlar, top): default OFF — no ads and no empty ad slots. ON — only ads that are on, inside their dates and paid (or admin-made without an order). The switch never changes orders or payments.

## Database (0021, forward-only, re-runnable)
New: `ad_templates`, bucket `ad-receipts` (private, 10 MB), functions `create_ad_order_from_template`, `submit_ad_receipt`, `admin_review_ad_order`, `admin_save_ad_template`, `admin_set_ad_template_active`, `home_ads_enabled`, `admin_set_home_ads_enabled`, `home_feed_ads`, `is_own_ad_order`. New nullable columns on `ad_orders` (order_no, template_id, creative, starts_on, receipt_path, receipt_uploaded_at, reviewed_at, ad_starts_at, ad_ends_at) and `ads.creative`. Packages d5 / d15 / d30 seeded hidden with price 0.

## Tests (disposable PostgreSQL 16)
- 0001–0021 apply; data-preservation check identical; re-run idempotent.
- `60_ads_flow.sql`: 34/34 (template validation, admin-only writes, colour / duration / price / text-length / date / https checks, price from server, snapshot, receipt path ownership, no approval without receipt, receipt ≠ paid, approve → ad with exact N days, reject needs reason, switch default OFF, ON shows only paid + started ads, scheduled / ended hidden, unpaid order's ad hidden, switch OFF keeps orders/payments, other users / blocked users refused, deactivated template hidden but orders keep banners).
- Package 1 / 1B suites 58/58, 54/54; messaging test passed; search_path scenarios passed.
- Flutter: not compiled here (no SDK); statically reviewed; CI builds it.

## Messages list: one row per person
Each load has its own chat with a person (plus an optional direct chat), so the same name could appear several times with an identical route. The list now shows one row per person (latest route + "N söhbət", unread counts summed); tapping it opens a short list of that person's chats when there is more than one. No data is changed.

## 0022 — customer logo + template window
- Admin: separate side-menu item **Reklam şablonları** (also the "Şablonlar" tab in Reklamlar). Template editor has "Bu şablonda loqo yeri olsun" with position / size sliders.
- Customer: entering **Reklam ver** opens the "Şablon seçin" window automatically (also via "Reklam yarat"); choosing a template opens the editor with it; customer types texts, uploads a logo (own folder in the public `ads` bucket), picks a colour.
- Server: `create_ad_order_from_template(..., p_logo_url)` accepts a logo only from the customer's own `ads/requests/<user id>/` folder and only for templates with a logo place; snapshot stores `logo` + `logo_url`. Tests `61_ads_logo.sql` 5/5; all earlier suites still pass.

## 0023 — standard 1200×400 layout (current)
- Fixed coordinates for every template (logo 30,120 160×160; company 220,45 440×85; activity 220,150 440×75; phone 220,250 440×70; visual zone 690,20 490×360). Admin uploads only backgrounds (centre-cropped to 1200×400), names, orders (↑/↓), switches on/off, deletes.
- Customer: background → company / activity / phone → logo (PNG/JPG/WEBP ≤ 2 MB, decoded before upload, own folder only; whole logo inside the circle, circle background dark / light / none) → per line font (Montserrat, Inter, Roboto Condensed, Noto Sans, Noto Serif), size 60–100 %, any colour. Text auto-shrinks to its box (1–2 lines, phone 1). Automatic two-layer shadow + soft left gradient; the same widget draws preview, admin view and feed.
- Editing: until approval; after a receipt the change sends the order back to review (flag shown to admin); approved ads are locked.
- Two independent admin switches, both OFF by default: ads in the load list; "Reklam ver" entry (server also refuses new orders while off). Customers with orders still see them.
- Feed: 6 loads → 1 ad, ads take turns, no empty slot, small "Reklam" badge, 3:1 card never cropped.
- Old 1350×300 templates and ads switched OFF (kept); old ads cannot be re-activated; the free-layout order function is retired.
- Admin: link + dates per ad, pause / resume, views / clicks.
- Tests: `62_ads_v2_flow.sql` 36/36 on 0001–0023 (+ package 1 58/58, 1B 54/54, messaging, idempotency, data preservation); legacy-data run: old ad + template switched off, rows kept, `ads` bucket limited to PNG/JPEG/WEBP. 60/61 (0021/0022 flow) superseded.
- **Flutter build NOT run here** (no Flutter SDK in this environment). Code reviewed statically twice; GitHub Actions ("Deploy Web" + "CI checks") is the build check.
