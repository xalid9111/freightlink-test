# Ads: templates, receipt payments, home-feed switch (0021)

## Flow
1. **Admin → Reklamlar → Şablonlar**: upload a 1350×300 background (any photo is centre-cropped), define 1–6 text fields (position, width, font size, max length, alignment, bold, default text) and the colours customers may pick; activate / deactivate; edit any time (existing orders keep a snapshot).
2. **Customer → Profil → Reklam ver → Reklam yarat**: pick an active template, type the texts, pick a colour (live preview), destination (FreightLink profile or https link), countries / route, 5 / 15 / 30 days, start date → total from the admin's price → confirm.
3. Order gets a number (R-1001…), shows the amount, the order number to write in the transfer, and the bank / card details saved by the admin.
4. Customer uploads a photo of the receipt (private bucket `ad-receipts`) → status "Yoxlanılır". Nothing is marked paid automatically.
5. **Admin** sees order + receipt → "Ödəniş yoxlanıldı — təsdiqlə" creates the ad: starts 00:00 (Baku) on the chosen day (or now if that passed), ends exactly N days later; or "Rədd et" with a reason the customer sees.
6. "Sifarişlərim": Ödəniş gözlənilir → Yoxlanılır → Təsdiqləndi / Rədd edildi → Planlaşdırılıb → Aktivdir → Bitib.
7. **Ana səhifə reklamları** switch (Admin → Reklamlar, top): default OFF — no ads and no empty ad slots. ON — only ads that are on, inside their dates and paid (or admin-made without an order). The switch never changes orders or payments.

## Database (0021, forward-only, re-runnable)
New: `ad_templates`, bucket `ad-receipts` (private, 10 MB), functions `create_ad_order_from_template`, `submit_ad_receipt`, `admin_review_ad_order`, `admin_save_ad_template`, `admin_set_ad_template_active`, `home_ads_enabled`, `admin_set_home_ads_enabled`, `home_feed_ads`, `is_own_ad_order`. New nullable columns on `ad_orders` (order_no, template_id, creative, starts_on, receipt_path, receipt_uploaded_at, reviewed_at, ad_starts_at, ad_ends_at) and `ads.creative`. Packages d5 / d15 / d30 seeded hidden with price 0.

## Tests (disposable PostgreSQL 16)
- 0001–0021 apply; data-preservation check identical; re-run idempotent.
- `60_ads_flow.sql`: 34/34 (template validation, admin-only writes, colour / duration / price / text-length / date / https checks, price from server, snapshot, receipt path ownership, no approval without receipt, receipt ≠ paid, approve → ad with exact N days, reject needs reason, switch default OFF, ON shows only paid + started ads, scheduled / ended hidden, unpaid order's ad hidden, switch OFF keeps orders/payments, other users / blocked users refused, deactivated template hidden but orders keep banners).
- Package 1 / 1B suites 58/58, 54/54; messaging test passed; search_path scenarios passed.
- Flutter: not compiled here (no SDK); statically reviewed; CI builds it.
