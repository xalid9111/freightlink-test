// Checks that all five language files stay in sync (pure Dart, no device).
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

const _langs = ['az', 'tr', 'en', 'ru', 'ka'];

Map<String, dynamic> _load(String lang) =>
    jsonDecode(File('assets/i18n/$lang.json').readAsStringSync()) as Map<String, dynamic>;

void main() {
  test('every language has exactly the same keys', () {
    final base = _load('az').keys.toSet();
    for (final lang in _langs) {
      expect(_load(lang).keys.toSet(), base, reason: '$lang.json key set differs from az.json');
    }
  });

  test('no empty translations', () {
    for (final lang in _langs) {
      _load(lang).forEach((k, v) {
        expect(v is String && v.trim().isNotEmpty, isTrue, reason: '$lang.json: "$k" is empty');
      });
    }
  });

  test('password-management texts exist in all languages', () {
    const keys = [
      'pw_change_title', 'pw_current', 'pw_new', 'pw_confirm', 'pw_show', 'pw_hide', 'pw_submit',
      'pw_forgot', 'pw_reset_title', 'error_pw_wrong_current', 'error_pw_too_short', 'error_pw_network',
    ];
    for (final lang in _langs) {
      final m = _load(lang);
      for (final k in keys) {
        expect(m.containsKey(k), isTrue, reason: '$lang.json is missing $k');
      }
    }
  });
}
