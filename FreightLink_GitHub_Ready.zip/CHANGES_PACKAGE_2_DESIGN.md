# Package 2 — approved "night map" design (includes Package 1)

No database migrations, schema, RLS or Supabase settings were changed.

- Dark-only theme in the approved palette (core/theme/app_theme.dart):
  navy ground, orange accent, teal route color; fonts Big Shoulders
  Display / Inter / JetBrains Mono via google_fonts (new dependency).
- Home: dark hero with brand, credits/PRO, "Loads are moving worldwide"
  title, animated live world map (assets/images/world_map.jpg + overlay
  painter in widgets/live_map.dart), REAL stats computed from the open
  marketplace (active loads, countries, routes) and the most common
  routes. No invented numbers.
- Cargo card redesigned (route block with flags, spec grid, big price).
- Cargo detail: route/price card + delivery-stage stepper.
- Shipments: stepper on every shipment (core/widgets/status_stepper.dart).
- Chat: orange own bubbles, dark card bubbles for the other side.
- Bottom navigation, inputs, buttons, dialogs restyled via the theme.

Known limitation: the map illustration has Azerbaijani region labels
baked into the image; they do not change with the UI language.

## Map revision — global, decentralized network
- New world illustration (Americas → Australia) and a mesh overlay:
  18 flows between 21 countries in all directions (e.g. TR→AZ, AZ→CN,
  CN→TR, RU→IR, IR→CN, DE→TR, PL→GE, GE→RU, CN→DE, TR→GE, US→GB,
  BR→ZA, IN→AE, KR→RU, SG→AU, KZ→PL, ES→EG, ID→IN). No hub: every node
  is drawn with the same size and effect.
