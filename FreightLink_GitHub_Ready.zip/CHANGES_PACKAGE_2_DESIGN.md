# Package 2 — approved "night map" design (includes Package 1)

No database migrations, schema, RLS or Supabase settings were changed.

- Dark-only theme in the approved palette (core/theme/app_theme.dart):
  navy ground, orange accent, teal route color; fonts Big Shoulders
  Display / Inter / JetBrains Mono via google_fonts (new dependency).
- Home: dark hero with brand, credits/PRO, "Loads are moving worldwide"
  title, animated live world map (assets/images/world_map.jpg + overlay
  painter in widgets/live_map.dart), REAL stats computed from the open
  marketplace (active loads, countries, routes) and the most common
  routes. No invented numbers.
- Cargo card redesigned (route block with flags, spec grid, big price).
- Cargo detail: route/price card + delivery-stage stepper.
- Shipments: stepper on every shipment (core/widgets/status_stepper.dart).
- Chat: orange own bubbles, dark card bubbles for the other side.
- Bottom navigation, inputs, buttons, dialogs restyled via the theme.

Known limitation: the map illustration has Azerbaijani region labels
baked into the image; they do not change with the UI language.

## Map revision — global, decentralized network
- New world illustration (Americas → Australia) and a mesh overlay:
  18 flows between 21 countries in all directions (e.g. TR→AZ, AZ→CN,
  CN→TR, RU→IR, IR→CN, DE→TR, PL→GE, GE→RU, CN→DE, TR→GE, US→GB,
  BR→ZA, IN→AE, KR→RU, SG→AU, KZ→PL, ES→EG, ID→IN). No hub: every node
  is drawn with the same size and effect.

## Credits / payments switched off for the launch period (app only)
- Removed the credit balance chip and the PRO badge from the home screen.
- Cargo detail shows the owner's contact (name, tappable phone/email)
  free to every signed-in viewer — no "unlock (1 credit)" step. The data
  comes from public.users, which RLS already allows (users_select_all).
- Database untouched: credit tables, unlock_contact() and subscription
  plans from migration 0006 stay in place, unused, for a later release.

## Chat: online status, read ticks, unread badge (no migration)
- Online/offline in the chat header via Supabase Realtime Presence
  (core/presence/online_users.dart) — in-memory on the Realtime server,
  no table. Active while the user has the app open.
- Read receipts: opening a thread marks incoming messages read
  (messages.read_at + existing RLS policy messages_mark_read);
  own messages show ✓ sent / ✓✓ read.
- Unread count badge on the Messages tab (live stream of messages
  addressed to the user where read_at is null).

## Package 3 — profiles, last seen, badges, PWA polish
- NEW MIGRATION supabase/migrations/0009_profiles_presence_verification.sql
  (safe forward, idempotent): users.avatar_url / last_seen_at /
  is_early_member; trigger guarding role/is_verified/is_early_member
  from self-edit (security fix); users_select_all limited to signed-in
  users (privacy fix); "avatars" storage bucket + own-folder policies.
- Profile photo upload (Profile → tap photo), shown in chat header and
  on the cargo owner contact card.
- "Last seen" in the chat header when the other person is offline
  (heartbeat every 60 s while the app is open).
- Blue verified tick (users.is_verified, set by an admin in the
  dashboard) and "Early member" badge.
- PWA: new route-line app icon (home screen / splash / favicon), theme
  colour #0A1120.
- The app tolerates the migration not being run yet (features simply
  stay hidden), but run it before testing these features.

## Package 4 — chat: call, photos/files, voice messages
- NEW MIGRATION supabase/migrations/0010_chat_attachments.sql (safe
  forward): attachment columns on messages, private "chat-files"
  bucket (20 MB/file) readable/writable only by the conversation's two
  participants, served through 1-hour signed links.
- Chat header: phone button (tel: link to the other user's number).
- Composer (WhatsApp-style): 📎 photo / camera / file; mic button next to
  the text field turns into send when you type; tap mic to record, then
  send or delete. Voice notes play inside the bubble.
- New dependencies: record, audioplayers, http.
- Voice recording targets the web/PWA build (MediaRecorder); native
  builds show a "web only for now" message.
- Call button (chat header and the cargo owner's phone line) now asks:
  "Phone call" (tel:) or "Via WhatsApp" (opens wa.me chat with that
  number — WhatsApp has no public link that starts a call directly).
- Locations in chat (no migration): 📎 → "My location" sends the device
  position as a Google Maps link; any map link pasted into the chat
  (e.g. a location forwarded/copied from WhatsApp, Google Maps, Waze,
  Apple Maps) is shown as a location card. Tapping it offers Google
  Maps, Waze, Sygic and (on iPhone) Apple Maps, or "open link" for short
  links without coordinates. New dependency: geolocator.
- Cargo-detail navigation sheet also offers Sygic, and Apple Maps on
  iPhone Safari/PWA.
- Conversation list shows the other party's registered name (company or
  person), photo, online dot, verified tick, the route underneath, and
  an unread counter per conversation. Cargo cards show the poster's
  name/photo above the route.
- Profile: add/change phone number (country-code picker, validated;
  "already used" message for duplicates). Shown in orange with a hint
  when missing. Registration now requires a phone number. No migration.
- Home: "Find loads by route" panel — From / To country pickers (with
  "any country"), ⇄ swap, instant filtering of the list, ⭐ save route
  → "My routes" one-tap chips (stored on the device). Popular-route
  chips in the hero now filter too. Country picker extracted to
  core/widgets/country_picker.dart (also used by cargo create).
- Fix: the startup-error overlay no longer appears after the app has
  started (iOS Safari's share sheet triggered a harmless cross-origin
  "Script error." that covered the running app).
