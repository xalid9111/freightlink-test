#!/usr/bin/env bash
# =====================================================================
# LOCAL TEST RUNNER — disposable PostgreSQL only. Never point this at
# the production database: it DROPS and recreates the target database
# (and refuses to run unless the database name contains "test").
#
# Usage:
#   PGHOST=/path/to/socket PGPORT=5432 PGUSER=postgres \
#     supabase/tests/local/run_local.sh before   # 0001–0017, reproduce issues
#   ... run_local.sh after                       # 0001–0017 + fixtures, then
#                                                # 0018–0020, all suites,
#                                                # data-preservation and
#                                                # idempotency checks
# =====================================================================
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
MIG="$HERE/../../migrations"
DB="${TEST_DB:-freightlink_test}"
MODE="${1:-after}"
export PGOPTIONS="${PGOPTIONS:-} -c client_min_messages=warning"
PSQL=(psql -X -v ON_ERROR_STOP=1 -q)
NEW=(0018_package1_security.sql 0019_package1b_security.sql 0020_advertiser_campaign_details.sql)

if [[ "$DB" != *test* ]]; then echo "Refusing: TEST_DB must contain 'test'"; exit 2; fi

"${PSQL[@]}" -d postgres -c "drop database if exists $DB" -c "create database $DB"
"${PSQL[@]}" -d "$DB" -f "$HERE/00_supabase_stub.sql" 2>/dev/null

for f in "$MIG"/0*.sql; do
  n="$(basename "$f" | cut -c1-4)"
  [[ "$n" > "0017" ]] && continue
  "${PSQL[@]}" -d "$DB" -f "$f" >/dev/null
done
echo "applied 0001–0017"
"${PSQL[@]}" -d "$DB" -f "$HERE/10_fixtures.sql" >/dev/null
"${PSQL[@]}" -d "$DB" -f "$HERE/15_test_helpers.sql" >/dev/null

if [[ "$MODE" == "before" ]]; then
  "${PSQL[@]}" -d "$DB" -f "$HERE/20_package1_before.sql" >/dev/null
  exit 0
fi

snapshot() {  # $1 = label : row count + md5 of every public table
  "${PSQL[@]}" -d "$DB" -c "
    create table if not exists tests.snap (label text, tbl text, n bigint, h text);
    do \$\$ declare t text; begin
      for t in select tablename from pg_tables where schemaname = 'public' order by 1 loop
        execute format('insert into tests.snap select %L, %L, count(*), md5(coalesce(string_agg(jsonb_strip_nulls(to_jsonb(x) - case when %L = ''ad_orders'' then array[''title'',''image_url'',''destination_type'',''destination_url'',''target_countries'',''route_from'',''route_to'']::text[] when %L = ''ads'' then array[''destination_type'',''destination_url'',''target_countries'',''route_from'',''route_to'']::text[] else array[]::text[] end)::text, ''|'' order by x::text), '''')) from public.%I x', '$1', t, t, t, t);
      end loop; end \$\$;"
}
compare() {  # $1 $2 = labels
  "${PSQL[@]}" -d "$DB" -c "
    do \$\$ declare d text; begin
      select string_agg(coalesce(a.tbl, b.tbl), ', ') into d
      from (select * from tests.snap where label = '$1') a
      full join (select * from tests.snap where label = '$2') b using (tbl)
      where (a.tbl is not null and (a.h is distinct from b.h or a.n is distinct from b.n))
         or (a.tbl is null and b.n > 0);
      if d is not null then raise exception 'DATA CHANGED ($1 -> $2) in: %', d; end if;
      raise warning 'data preservation $1 -> $2: all % public tables identical',
        (select count(*) from tests.snap where label = '$1');
    end \$\$;"
}
apply_new() {
  for m in "${NEW[@]}"; do
    echo "apply $m"
    "${PSQL[@]}" -d "$DB" -1 -f "$MIG/$m"
  done
}
suites() {
  "${PSQL[@]}" -d "$DB" -f "$HERE/30_package1_after.sql" >/dev/null
  "${PSQL[@]}" -d "$DB" -f "$HERE/40_package1b_after.sql" >/dev/null
  PGOPTIONS="-c client_min_messages=notice" "${PSQL[@]}" -d "$DB" -f "$HERE/../messaging_audit_test.sql" 2>&1 \
    | grep -E "ALL MESSAGING|FAILED|ERROR" | sed 's/^/messaging_audit_test: /'
}

snapshot pre
apply_new
snapshot post
compare pre post
suites
echo "re-apply (idempotency)"
apply_new
snapshot post2
compare pre post2
suites
