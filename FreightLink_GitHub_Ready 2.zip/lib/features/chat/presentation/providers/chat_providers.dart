import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../../core/config/supabase_config.dart';
import '../../../../models/cargo_model.dart';
import '../../../../models/message_model.dart';
import '../../data/message_repository_impl.dart';
import '../../domain/message_repository.dart';

final messageRepositoryProvider = Provider<MessageRepository>((ref) => MessageRepositoryImpl());

class ConversationWithCargo {
  final ConversationModel conversation;
  final CargoModel? cargo;
  const ConversationWithCargo({required this.conversation, required this.cargo});
}

/// Same two-query pattern as ShipmentWithCargo (see
/// repositories/shipment_repository.dart) and for the same reason: the
/// conversation list needs the cargo route to be a useful label, and
/// that lives on `cargo`, not `conversations`.
final myConversationsProvider = FutureProvider<List<ConversationWithCargo>>((ref) async {
  ref.watch(currentUserIdProvider); // re-fetch when the signed-in account changes
  final repo = ref.watch(messageRepositoryProvider);
  final conversations = await repo.fetchMyConversations();
  if (conversations.isEmpty) return [];

  final cargoIds = conversations.map((c) => c.cargoId).whereType<String>().toSet().toList();
  final cargoById = <String, CargoModel>{};
  if (cargoIds.isNotEmpty) {
    final rows = await SupabaseConfig.client.from('cargo').select().inFilter('id', cargoIds);
    for (final row in (rows as List)) {
      cargoById[row['id'] as String] = CargoModel.fromJson(row);
    }
  }

  return conversations
      .map((c) => ConversationWithCargo(conversation: c, cargo: c.cargoId != null ? cargoById[c.cargoId] : null))
      .toList();
});

final conversationMessagesProvider = StreamProvider.family<List<MessageModel>, String>((ref, conversationId) {
  ref.watch(currentUserIdProvider); // re-fetch when the signed-in account changes
  return ref.watch(messageRepositoryProvider).watchConversation(conversationId);
});
